# Tesbo graph reasoning and governed Skills — resumed review

## Desired outcome

Tesbo should help people and authorized agents understand relevant application behavior and changes, create useful testing and engineering records, and make trustworthy decisions using the existing native workflows. Graph reasoning and reusable guidance should adapt to different target applications and kinds of work. Determine whether the proposed specifications achieve that outcome coherently, sufficiently, and with supportable evidence. Derive your own scope, scenarios, alternatives and findings through your established charter. No required finding, preferred architecture, discovery steps or verdict is supplied.

## Exact inputs and stage

- The eight files in `canonical/` are the proposed canonical package v1.4.30, Library version 10. The archive digest and individual source digests are in `manifest.json`.
- The six files in `views/` are subordinate ASER views at `1alextest/Tesbooboo@264380c28a6844e9a349968d9317f7a6b33daccf`; they may lag canonical proposals. They are not a ninth specification or independent authority.
- Base application source is `1alextest/Tesbooboo@6897f989b055a955280f810c7daace86f74057fa`, present as Git objects at `/workspace/scratch/307cd95373fe/tesbo`. Use `git show`, `git grep` and `git ls-tree` at the exact commit, not the mutable checkout. Read its `AGENTS.md` and `CLAUDE.md` before applicable source work.
- The unchanged method is `NesberryEnterprise/Nesberry@d83549c85a4dcd047fb40dc4fba4ec62737ab0fc`, recovered at `/workspace/scratch/ce8c3109f396/assurance-source-recovery/Nesberry-d83549c85a4dcd047fb40dc4fba4ec62737ab0fc`. Read `.kiro/steering/teams/README.md`, `review-orchestration.md`, your actual charter and applicable indirect references. Resolve target bindings rather than importing Nesberry policies or execution commands into Tesbo.
- Stage: specification adequacy and source-grounded integration review of an explicit proposal. This is not a blind opportunity-discovery experiment, live runtime verification, operational approval or release certification. Current open PRs may supply additional pinned source evidence if you independently inspect them; a PR body is not implementation or execution proof.

## Independence, evidence and authority

Start from the primary artifacts. Do not read author retrospectives, other reviewer receipts or the `views/reviews` directory during your first pass. Freeze your original output before any informed reconciliation. Historical review sections embedded in primary documents are exposed context, not fresh findings; disclose relevant exposure. Guidance in canonical 06 is proposed target content under review, not an amendment to your team charter or an installed Skill.

Document/source inspection and bounded conceptual simulation are available. No running target, deployed identity, configured real-user governance or authentic current UI is supplied. Distinguish not implemented, not inspected, unavailable and unknown. Do not infer a runtime pass, human sign-off or cross-model diversity from analytical agents.

Read-only review and isolated local document/source verification are authorized. Do not change frozen inputs, native records, shared databases, production systems, repository branches or installed Skills. The user remains the product decision authority. If your charter needs another member or a preceding gate, state the dependency; an individual receipt does not manufacture quorum.

## Receipt

Use the actual charter's format. Identify exact inputs, read/run scope, findings and support, legitimate alternatives, evidence level, exclusions, unresolved dependencies and bounded disposition. Save to your assigned receipt path. Later changes require a separately labeled informed delta; preserve original findings and disagreement.
