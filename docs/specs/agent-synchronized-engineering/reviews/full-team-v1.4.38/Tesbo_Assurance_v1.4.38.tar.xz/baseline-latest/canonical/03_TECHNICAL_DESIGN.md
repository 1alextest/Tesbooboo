# Technical Architecture and Data Design

**Document ID:** TESBO-TD-003 | **Revision:** 1.4.31 — 20 November 2026; governed graph reasoning and principle-based learning; NOT FROZEN | **Status:** source-informed design plus scoped native increments; NOT FROZEN.
**Scoped implementation evidence:** Native preview increments are tracked in Tesbo PR95 and PR98; use their exact-head receipts and the MBT contract/acceptance sections below. Historical full-source audit pins and older review results retain their original scope/date. Unverified criteria and independent assurance remain open; this is not package-wide implementation or deployment certification.
**Stack:** existing Next.js, NestJS, PostgreSQL/pgvector, Redis/BullMQ and Railway fork.  
**Audited fork:** T-454 source verification `1alextest/Tesbooboo@5989e5e2c646666ed087a7885389b2ffce4bad42` (development); prior historical audit `124f1280afd7ee0e400755796ac46ba9f956b05f`. Production SHA/migrations were not verified.  
**Revision rule:** this replaces earlier additive schema assumptions inside the same document. It does not add a second technical design.

**Current integration amendment:** Read revision 1.4.28 below for ASER scope, exact canonical owners and contracts. Earlier dated source/implementation claims retain their original scope. The original QA round trip and P-07/P-14/P-17/P-18 are preserved. New runtime tests remain NOT RUN; the package is NOT FROZEN.

## 1. Verified foundations and runtime limits

Source references are relative to the audited repository. Source findings were established by the codebase audit; live evidence is limited to the separately recorded browser reconnaissance. Revalidate changed paths against the chosen implementation baseline.

| Existing anchor | Source finding | Required extension |
|---|---|---|
| `src/legacy/legacy.service.ts`: Zyra staging, `zyraSave`, `zyraSaveAttempt`; V89 shared chat staging | `ai_generation_requests.generated_payload` already stages creates/updates/archives, edits/selections and selected transactional saves. Post-save work refreshes caches and queues downstream effects. | Generalize this shared staging/review/apply path for external authors, preserving compatibility. Add stable operation IDs, immutable revisions and human decisions. |
| `components/agents/ZyraChatReviewPanel.tsx`, `ZyraDraftEditor.tsx` | Existing draft editor/review interface | Extend for source reports, case/result/issue operations, exact diffs, comments, approvals and conflicts. |
| Review Board service/UI and compare/edit modals | Duplicate/similar existing-case recommendations with keep/edit/remove, not general change proposals | Keep its purpose; share appropriate components. Normalized similarity fingerprints cannot authorize exact-content publication. |
| `migrations/V63_testcase_versions_snapshot_trigger.sql` | Pre-update `testcase_versions` snapshots already exist | Reuse; assess initial creation, custom fields/tags/profile completeness and current-definition versioning. A historical maximum or maintenance-updated timestamp is not a safe current authoring token. |
| V119 cycle-item field snapshots; V140 run history | Existing case-linked run/result data and snapshots | Reuse and extend snapshot/provenance coverage; retain historical authored expectations. |
| `agents`, `actors`, actor profiles; V65 MCP actor | Human/agent identity foundation; MCP currently shares `tesbo-mcp` actor | Extend identity root for distinct runtime installations; retain actor/credential/issuer separation. |
| `src/auth/api-token.service.ts`, V5 tokens | Project/user-bound hashed credentials with broad read/write; invalid/omitted scopes default broadly | Extend existing credentials/grants/lifecycle. New restricted credentials fail closed; migrate legacy tokens explicitly. |
| `src/auth/auth.middleware.ts`, request types | Browser sessions checked before bearer; some legacy handlers retain only issuing user's ID | Carry actual principal/credential/project grants through every domain operation; define/test mixed cookie/bearer behavior. |
| `src/mcp/*` | Project endpoint and alias, JSON-RPC discovery/calls, broad requiredScope checks, low-level legacy writers | Preserve transport and extend adapters to the same authorized shared services as UI/REST. Reauthorize even unadvertised calls. |
| `src/automation/*` | Existing case resolve/run/result/evidence ingestion uses cycles, cycle_items and executions | Preserve optional reporter compatibility. This is not the required OpenCode Chrome-MCP task/report system. |
| Task creation and Zyra settings | Existing task route invokes internal generation and requires model allocation; four project capability booleans | New external task semantics cannot reuse that generation route unchanged or require an internal key. |
| Attachments/StorageService | Existing file metadata, upload limits, quotas, access and local/S3 abstraction | Add report-parent ownership; verify upload bytes/length/hash and access. StorageService.exists in S3 mode is not proof of object integrity. |
| `audit_logs`, notifications, Redis/BullMQ, project settings | Existing shared infrastructure | Extend with durable decision/apply receipts and task/report events. No parallel audit, notification or scheduler stack. |
| `createBug` / linked executions | Live bug creation can call failLinkedExecutions | Keep issue drafts in shared staging. Drafting/approval-for-copy must not create/link a live bug or alter accepted results. |

Live inspection confirmed inactive Zyra, a disabled Create task action, duplicate-focused Review Board, no project API tokens and no allocated AI keys. Existing case/run/import/bug/custom-field/environment forms were inspected. A labelled KB document was created, searched, reopened and inspected in history. No real MCP call, external task/report, staged review/apply or official case/result mutation was tested. Form presence is not proof of backend security, entitlement enforcement or full field fidelity.

Pinned source examples: [V89 staging](https://github.com/1alextest/Tesbooboo/blob/124f1280afd7ee0e400755796ac46ba9f956b05f/Tesbo-Backend-Nest/migrations/V89_zyra_chat_review.sql), [case history](https://github.com/1alextest/Tesbooboo/blob/124f1280afd7ee0e400755796ac46ba9f956b05f/Tesbo-Backend-Nest/migrations/V63_testcase_versions_snapshot_trigger.sql), [review panel](https://github.com/1alextest/Tesbooboo/blob/124f1280afd7ee0e400755796ac46ba9f956b05f/Tesbo-Frontend/components/agents/ZyraChatReviewPanel.tsx), [draft editor](https://github.com/1alextest/Tesbooboo/blob/124f1280afd7ee0e400755796ac46ba9f956b05f/Tesbo-Frontend/components/agents/ZyraDraftEditor.tsx).

**Platform independence requirement:** Isolate project-level target adapters/capabilities, case field/profile mapping, hierarchy, external tracker configuration, imported-source identity, retention rules and permissions. Never add `DMIS`, role/module, government, GitLab, workbook or Chrome-specific columns/branches to shared domain policy. Store these as typed/versioned project configuration and optional integration metadata using the existing architecture; implement a new adapter only after a demonstrated gap and supported execution contract. Initial web-target policy (HTTPS origin/path and browser actions) applies **only** to web adapters; non-web targets use typed target-specific authorization and do not inherit unsafe blanket allowances. A project with no Excel source, no role structure and no GitLab connection must still complete task → report → review → publication.

## 2. Logical boundaries within the existing application

Remain a modular monolith. Names below are responsibilities to extract/extend, not mandates to build new parallel modules.

| Boundary | Owns | Shared implementation rule |
|---|---|---|
| Principal and policy | Actual human/agent/service identity, grants, resource/project ownership, writability | Used by REST, MCP, background services and existing writers; no issuer-membership shortcut. |
| External task and attempt | Exact prompt revision, assignment, claim/lease, questions, retry/retest | Reuse task UI and suitable claim/recovery patterns; external lifecycle never invokes internal generation. |
| Report receipt/evidence | Immutable source report and supplements, attempt provenance, attachments | Independent of official case/run IDs. Use existing storage with report-aware access. |
| Shared staging/review | Generalized generation batch, typed stable operations, revisions, discussion and human decisions | Zyra and external clients use the same staging and review engine. |
| Approved apply | Exact approved payload/base checks, selected transaction, receipt/audit | Harden existing selected save and SQL writers; no separate privileged agent publisher. |
| Existing records and effects | Testcases/suites, run snapshots/results, approved bugs if requested, caches/search/notifications | Reuse existing data and post-commit mechanisms, with explicit outbound integration authorization. |

OpenCode controls Chrome MCP on its own workstation, using its existing credentials/VPN where needed. Tesbo coordinates prompt/report exchange and cannot launch an offline agent or take over that browser. Automatic pickup requires a running client/poller or supported runtime trigger; manual pickup is the first slice.

### 2.1 Concrete component reuse map and MCP execution separation — revision 1.3.5

The following are **audited source building blocks**, not deployed guarantees. Build inside the existing modular monolith; any new boundary named below is a responsibility extracted from existing modules, not a disconnected microservice.

| Round-trip function | Existing code/data to use | Required extension; owner/side-effect boundary |
|---|---|---|
| ChatGPT creates/scopes task through Tesbo MCP | `src/mcp/mcp.controller.ts`, `mcp.service.ts`, `mcp.tools.ts`; `Agents → Tasks` shell, `legacy.service.ts` task functions | Add external kind/task revisions/context; scoped `task.create/submit`; external task must **not call current generation-bound `aiGenerate`** |
| Instance registration/assignment/claim | `agents`, `actors`, `actor_profiles` (V58), `api_tokens` (V5), legacy claims; task/Agent list/Project settings | Distinct runtime installations/credentials and current capabilities, assignment ID/attempt fencing/lease; no inferred issuer approval or false online status |
| OpenCode executes on target | **Outside Tesbo**: OpenCode agent invokes its connected Chrome MCP or Playwright MCP tools using its own runtime setup. Existing Tesbo reporters/Playwright checks remain independent | Store intended executor tool/provider/capabilities and observed actual tool/run metadata; no direct Tesbo-to-Chrome proxy or Tesbo-required new runner. Browser tools may have different features; capability negotiation/deny must be explicit |
| Execution report and screenshot upload | `storage/storage.service.ts`, existing attachments/evidence validation, audit | Pending receipt, immutable report body/manifest, evidence hashes/bytes, parent task/attempt and privacy gates. Receipt may have zero official case IDs |
| ChatGPT reads full sources and drafts changes | MCP handlers, KB + exact-version read adapter, `ai_generation_requests.generated_payload`, V89 chat-review reuse, `ZyraChatReviewPanel`, `ZyraDraftEditor` | Complete report/artifact/chunk reads; analysis revisions, typed case/result/**native Bug**/optional tracker-copy operations, stable operation IDs and item decisions |
| ChatGPT requests targeted retest | Same task/revision/assignment/receipt services, existing queues/notifications | `create_followup_task` referencing parent task/report/finding, new authorized scope+claim+report; old report immutable; new analysis revision; invalidate stale approvals |
| Human review and selected publication | `zyraSave`/`zyraSaveAttempt` shared transactional patterns, `testcases`, `testcase_versions`, `cycles`, `cycle_items`, `executions`, `bugs`, `audit_logs` | Authoritative human decision and separate apply; exact reviewed payload/base/profile/policy; **selected native bug create/link only after approval**; validate existing Bugs side effects within atomic policy-aware transaction; no draft write/auto tracker post |
| UI state and notifications | Next.js workflow shell, UI primitives, violet tokens, project providers/API cache helpers, BullMQ/Redis and notifications | Existing Tasks → Reports/Proposals/Discussion and Change requests; explicit retest controls, native Bug vs copy dispositions, durable source links and no duplicate navigation app |

**Two different MCP surfaces:** ChatGPT and OpenCode both connect to **Tesbo MCP** for durable project coordination; OpenCode alone connects to its **executor MCP** (Chrome MCP/Playwright MCP in web configurations) for browsing. The executor MCP does not write official Tesbo records, and Tesbo's current Playwright dependency/reporter is neither proof of Playwright MCP availability nor an implicit agent runtime. Verify each actual client/tool combination. Client-side manual pickup is MVP; a resident poller is optional and never inferred from registration.

**Failure routing:** task+prompt persist before claim; incomplete evidence does not finalize report; cancellation/revocation stops subsequent authorized Tesbo calls and cooperative future target actions; a retest appends a new task/report, not edits an old one; review drafts never mutate cases/results/Bugs; merge is server-validated with idempotency, mandatory audit and post-commit deduplicated effects.

## 3. Disposition of every earlier proposed table

These names identify earlier proposals, not approved migrations. New persistence is justified only for semantics the existing foundation cannot represent. Preserve existing table ownership and verified FK conventions while explicitly adapting incompatible retention semantics.

| Earlier proposal | Revised disposition | Data/invariant to preserve |
|---|---|---|
| `agent_instances` | Extend existing agents/actors or a directly linked runtime-instance child where needed | Stable per-installation identity, project, owner, runtime/client metadata, last contact and status; no new disconnected registry. |
| `agent_token_bindings` | Prefer existing api_tokens fields/association; add relation only if cardinality requires | Credential-to-agent mapping, issuer, expiry, rotation/revocation; no duplicated credential store. |
| `capability_profiles` | New/additive configurable grant/profile persistence justified | Versioned profile identity and project scope; avoid vendor-hardcoded roles. |
| `capability_grants` | New/additive grants sharing existing subject/project model | Explicit capabilities/scopes/denials/expiry; no implicit broad write expansion. |
| `project_workflow_policies` | Start with validated/versioned projects.settings and audited changes | Human publication rule, dispatch/result review policies and explicit human exceptions; normalize only when constraints require. |
| `test_tasks` | New/generalized external task header linked to existing workflow | Optional case refs, exact task purpose, project and current prompt revision; distinct from internal generation. |
| `test_task_revisions` | Immutable prompt revision persistence justified | Exact Markdown/hash, context/environment/profile references and author/time. |
| `task_assignments` | External attempts/leases justified, using existing claim conventions | Instance/revision binding, attempt number, claim/lease/heartbeat/expiry/cancellation, single active authority. |
| `task_reports` | Immutable external report receipts justified | Original narrative/hash, assignment/agent/prompt revision, submission key, receipt time and supplement lineage. |
| `report_artifacts` | Extend attachments with report parent/provenance; link table only for actual many-to-many | Content hash, length/type, owner and authenticated access; no second file service. |
| `analysis_revisions` | Typed immutable analysis artifact/revision in shared workflow | Source report IDs, analyst identity, claims/uncertainty and content hash; no independent generic subsystem. |
| `change_proposals` | Generalize ai_generation_requests staging or migrate it into one common review envelope | External/Zyra source, project, title, state, current revision and task/report linkage. Do not run two proposal engines. |
| `proposal_revisions` | Add immutable revisions to shared staging envelope | Full profile/payload, revision identity/hash, author/time and base references. |
| `proposal_operations` | Add stable typed operation IDs within shared staging | Create/update/archive/result/issue payload, exact base, evidence, operation hash and decisions; array indexes are not IDs. |
| `proposal_comments` | New operation/revision/field-linked discussion where needed | Authenticated author, body and durable revision/field references. Reuse presentation patterns, not KB ownership rules. |
| `review_decisions` | New immutable revision-bound decision records | Human reviewer, exact revision/operation hashes, policy/profile versions, decision/time. |
| `merge_commits` | Extend current save events with durable idempotent apply receipt; normalize if needed | Selected operations, exact decision/base, actual record IDs, reviewer/time and replay result. |
| `published_case_revisions` | Remove as default new table; reuse testcase_versions/history | Complete authoring version/provenance plus separate-field completeness. Do not duplicate case history. |
| `issue_drafts` | Typed native-defect and optional external-tracker-copy operations in **shared staging** first | Reviewable evidence/target/links and independent decisions; no live `bugs`/result side effects until separately authorized protected native publication. No second official defect store. |
| `workflow_audit_events` | Reuse audit_logs with required metadata/transactional writes | Actual principal, instance, issuer/credential, transport, project/entity, action, correlation and before/after references. |

V116 already makes chat deletion soft and changes chat message/review FKs to ON DELETE RESTRICT; reuse it and do not create a duplicate chat-cascade migration. The surviving ai_generation_requests.requested_by ON DELETE CASCADE (V8/V107) still needs retention/ownership treatment. Permanent approvals/report lineage must not disappear on issuer removal; inspect downstream comment ledgers and preserve privacy/deletion policy explicitly.

Native case lifecycle status Draft/In Review/Approved is separate from unpublished proposal states. Case IDs allocate only when publishing a new accepted case; imported source IDs use approved reconciliation mapping. Preserve existing internal IDs for updates. Case history must cover initial creation and separately stored custom fields/tags/profile identity. A maintenance embedding update must not falsely change the authored-base token.

## 4. Authentication, capabilities and policy

An operation context retains subject kind (human session, agent token, OAuth-linked agent, narrow service identity), subject/actor ID, instance, credential ID/validity, issuer and project/task grants. The issuer is accountability metadata, not the acting human reviewer.

Authorization order:

1. Validate credential/session, expiry/revocation, account/instance status.
2. Resolve the actual resource and owning project, including indirect cycle/execution/attachment joins.
3. Check effective membership/delegated capability and current explicit denials.
4. Check requested operation and task/assignment ownership/valid lease as applicable.
5. Apply protected publication and configured human-review policy for every authored-definition/result effect.
6. Apply project/plan writability, quota and retention rules at the domain operation, without relying only on URL prefixes or HTTP verbs.

Capabilities include read, task create/edit/submit/assign/claim/progress/retest, report/evidence submit/read, analysis create/read, proposal create/read/edit/submit/comment/decision/merge, issue-copy review and agent/credential/grant administration. `04_MCP_API_CONTRACTS.md` maps operations. Human-only policy is a separate invariant; assigning a capability label to an agent does not override it.

New credential scopes omitted/empty/unknown must fail closed. Token issuance cannot exceed delegated administration rights. Migration of broad read/write tokens is explicit; do not silently convert write into all new privileges. Grant changes/revocation apply on the next protected request. Define machine-route cookie/bearer precedence so a human cookie cannot elevate a restricted agent request.

### Writer coverage

| Existing route/effect | Required treatment |
|---|---|
| MCP case CRUD/restore/archive/duplicate/bulk/clone | Capability, project and publication checks in shared services; tools/list filtering is supplementary. |
| REST/manual CRUD/import/bulk | Same checks, including nested import suites, required custom fields and tags. Human direct edit only by explicit policy. |
| Suite move/delete/clone and case assignment | Treat indirect definition/location/removal changes as protected repository effects. |
| Custom-field values/definitions and tags | Include reviewed values and approved profile identity; policy/schema changes cannot silently weaken required validation. |
| Zyra selected/set-based save, chat immediate actions, archive sweeps | Shared staging/apply; no AI/internal queue exception to publication. |
| Duplicate Review Board edit/remove | Same policy; its existing edit path is not automatically an atomic general merge. |
| Bug create/link and result ingestion | Preserve accepted outcome policy; issue drafts never call routines that fail linked executions. |
| System/setup/maintenance | Narrow explicit service authority. Embedding/search metadata maintenance cannot alter authored definitions. |

The current URL-prefix write-lock guard does not cover every alias/entity-addressed path; a project MCP read is also HTTP POST. Classify operations semantically, preserving existing plan protections without treating every MCP POST as a write.

## 5. Exact approval and selected apply transaction

Extend existing zyraSaveAttempt/with-client SQL transaction boundaries:

1. Resolve authenticated human and current publication capability/policy. Reject machine approval under the default protected-project policy.
2. Acquire locks in the §10.2 order: suite-tree first when hierarchy participates, then shared envelope and actual SQL-ordered affected rows, with existing ID-allocation lock as specified. Load immutable revision and explicit stable selected operation IDs under that protocol.
3. Validate human decisions against exact revision/operation payload hashes, profile/policy versions, stable logical-operation commitment and current eligibility. Any approval-relevant change requires a new decision. Normalized duplicate fingerprints are unsuitable.
4. Compare full current authored-base token, including separately stored custom values and intended suite. Reject missing/changed targets, stale bases, invalid dependencies, unavailable suites, ID collisions or required-field failures with zero selected writes.
5. Apply only selected approved, dependency-closed, uncommitted logical operations using existing parameterized SQL validators/writers and the same transaction client. Persisted operation kind/target must match reviewed intent; no late ticket/similarity retargeting. Allocate IDs inside the transaction. Create no unreviewed destination suites before it starts and never silently relocate a case.
6. Persist definition/history/provenance, accepted result snapshots where applicable, operation states, durable idempotent receipt and mandatory audit in the same transaction. An audit failure aborts publication.
7. Commit; then perform cache invalidation, embeddings, counts, notifications and explicitly permitted integrations. Use durable deduplicated jobs/outbox where necessary for reliable retries.
8. Same idempotency key/payload returns the prior result; a different payload with the same key conflicts. Subsequent partial merges select only remaining approved operations. Rejected/pending/issue-copy items are never included implicitly.

The aggregate request remains partially merged only while actionable work exists. Rejected/withdrawn and approved-for-copy issue items are terminal review dispositions; when every item is terminal, derive MERGED only if every item is a publishing operation already applied, REJECTED if all were rejected, WITHDRAWN if all withdrawn, otherwise COMPLETED with the mixed/copy-only summary. Keep legacy generation done separate from shared review state. Retain explicit decisions for every item. Restoring an old definition creates a reviewed compensating operation; it does not erase later history or bypass protection.

## 6. Integration and downstream-effect map

| Existing mechanism | Extension/compatibility requirement |
|---|---|
| Sessions/OTP/password and workspace/project membership | Preserve human login and isolation; add actual agent principals without issuer impersonation. |
| MCP project endpoint and /api/mcp alias | Reuse registry/adapters; runtime schema validation, per-call authorization, safe errors and both-path regression coverage. No assumed server push. |
| Automation REST/SDK reporter | Reuse existing cycles/executions/snapshots and evidence; optional, separately authorized compatibility path. |
| KB/RAG, documents/versions/comments, ticket mirrors | Reuse trusted contextual sources/version references; reports are untrusted observations, not instructions. Control draft indexing and telemetry. |
| Jira/Linear/Notion OAuth/PAT, mappings/sync and queued comments | Existing outbound integrations are not an inbound MCP OAuth server. Case approval does not authorize external posting. Keep manual GitLab filing. |
| Storage/quota/download/trace links | Extend report ownership across upload, read, soft-delete and signed access; verify content completeness rather than an exists stub. |
| Custom fields, tags, imports/exports | Include complete values/schema/profile in staging, diffs, validation, history, merge and run snapshots. Preserve source IDs/mapping. |
| Redis/BullMQ ticket sync/archive/recovery jobs | Reuse server infrastructure with narrow service authority; queues do not launch local Chrome MCP. |
| audit_logs, notifications, Postmark | Extend event metadata/deduplication and project-recipient policy; mandatory apply audit is transactional. |
| Stripe/plan locks/entitlements | Preserve project writability and storage gates. The custom-field form's availability is not entitlement proof; decide generalized review availability deliberately. |
| Langfuse, Sentry, PostHog, BetterBugs and optional Basecamp reporting | Review prompt/report/evidence flows and redaction; no accidental new external disclosure or replicated report store. |
| API helper/cache/pageDataCache/zyraCacheSync | Refresh existing repository/run/requirement/report counts only after commit; test retries because helpers may retry writes after network errors. |
| Dormant automation/report/webhook schema | No automatic reuse or deletion merely from names. Runtime references/ownership must justify reactivation. |
| Docker/migrator/DB/Redis/Railway rewrite | Reuse deployment arrangement and append migrations; production build/DB role/migrations require verification. |

Live Jira/Linear/Notion integrations were unconnected, model keys unallocated and project tokens absent. No integration above beyond human browser/KB persistence was acceptance-tested. A later real-client test must show allowed task/report/proposal operations and denied official publication with separate identities.

## 7. Frontend and coding conventions

Use existing Next.js App Router providers, `@/` imports, shared UI/workflow layouts, project context, loading/errors, pagination and lib/api.ts. Generalize ZyraChatReviewPanel/ZyraDraftEditor and suitable comparison components. Place Tasks/Change requests in existing Agents area; connect existing repository/history/runs rather than introducing independent applications.

Follow actual `app/globals.css` violet/semantic tokens and light/dark behavior. Older visualguideline.txt teal guidance and Java-backend contribution notes have drifted. Read applicable repository AGENTS.md/CLAUDE.md and installed framework guidance at implementation time; reconcile workstation-specific instructions with the execution environment.

Backend stays strict TypeScript/NestJS with parameterized pg and `DatabaseService.transaction(PoolClient)`/with-client writers. Do not introduce an ORM, new UI framework or unrelated legacy rewrite. Migrations append `V<number>_<name>.sql`; choose numbering after upstream/baseline review. Extend existing Jest and e2e/api/e2e/ui checks; Tesbo's own Playwright checks do not impose a Playwright runner on OpenCode's execution workflow.

## 8. Connection, migration and rollout sequence

1. Confirm fork HEAD and deployed SHA/migrations. Compare relevant upstream Review Board/MCP changes, including the previously inspected upstream `f12c9c6f9fe56c3897cf43cb88fcbdee13208b94`, without assuming it is current. Preserve Railway host/rewrite behavior.
2. Implement principal/grant/publication checks and explicit broad-token migration. Protect legacy/indirect paths before exposing restricted-agent credentials.
3. Generalize existing staging/apply/history/UI and complete custom/profile fidelity, immutable review decisions and durable receipts.
4. Add external task/attempt/report semantics and report-owned evidence through existing storage/task shells; no internal model allocation required.
5. Extend MCP adapters; validate actual OpenCode and ChatGPT client/authentication compatibility in a disposable project. Implement an OAuth-compatible mapping/gateway only if the supported client path requires it; never remove authentication or use a shared unrestricted service token.
6. Demonstrate task → OpenCode Chrome-MCP report → ChatGPT proposals → human revision/retest/selective approval → existing records, with denial/concurrency/retry evidence.
7. Where requested, reconcile sample imported-source IDs/hierarchy/fields (Excel in the pilot) into staged proposals before full cutover. Never rewrite the original workbook or assume full IDs fit a prefix input.
8. Stage reviewed changes with backup/health checks and a forward-fix/rollback plan. Any application rollback must preserve protected authorization and durable approval/report history; it cannot reenable unguarded writers.

This document records the revised design inside the original specification. No code, migration, production publication or live multi-agent connection is represented as completed.

## 9. Team-reviewed identity, policy and environment contracts

### 9.1 Deterministic effective authority

Human sessions keep active-workspace isolation. Machine calls resolve organization from their credential-bound project, never the issuer's mutable active_organization_id. Revalidate project/instance status, issuer's current delegated administration eligibility and instance-owner membership separately. MVP removal/demotion/loss of required delegation suspends affected credentials/active attempts on next request. Authorized ownership transfer/reissue is explicit/audited; reports and historical attribution survive. Later issuer promotion does not enlarge an existing credential's issuance ceiling.

Compute effective authority as credential issuance ceiling intersected with current instance/profile allows and resource/task restrictions, with any explicit deny winning. Instance overrides can narrow or add within that ceiling only under delegated administration; unknown/absent capability denies. Scope is exact resource by default; suite-descendant scope is an explicit grant option, reevaluated after moves. No runtime-name or issuing-user-role shortcut.

Use explicit context.profile.read for the approved references in an assigned task. Report/proposal read grants distinguish assigned/referenced work from project-wide analysis/review. List/search applies the same predicates before pagination/counts so task-only clients cannot enumerate unrelated records. Credential/grant/profile changes invalidate authorization caches for the next request.

### 9.2 Protected settings and profile lifecycle

Reuse projects.settings but reserve workflow policy and QA-format namespaces. Generic project/settings saves preserve reserved keys, reject attempted unauthorized replacement and never turn missing/corrupt policy into a permissive default. Protected changes require current policy-admin capability, server-assigned version, expected-version compare-and-set and mandatory audit. Unrelated stale environment/icon/general saves cannot erase/reset policy, profile IDs or versions. Grant tables, if normalized, remain the single grant source rather than duplicated settings copies.

Capability and QA-format profiles have draft/active/retired immutable versions. Create/clone/edit/validate/activate/retire are explicit existing-settings actions. Activation shows affected instances/pending approvals; current grants reevaluate next call while format-bound dispatched work keeps its recorded version. Retired profiles remain historically readable but unavailable for new selection. Require an authorized human reviewer/admin path to remain; an agent cannot weaken protected policy through generic settings. Migrate legacy whole-blob writers and frontend serializers, not only new endpoints.

### 9.3 Existing environment object upgrade

Current TestEnvironmentSetting is only name/url; frontend getTestRunEnvironments and settings normalization drop other keys. Add stable environment ID/context version within the same projects.settings.testRunEnvironments objects, migrate legacy entries deterministically/idempotently and update every parser/writer to preserve them. Array index/name/URL are not durable identity.

Store exact dispatched name/URL/context snapshot in prompt revision alongside identity/version. Rename/reorder/removal cannot change dispatched work or historical run labels. Removal retires selection for new dispatch while old snapshots remain; changed targets need an explicit new task revision/assignment. Validate current naming/URL duplicate rules and backward-compatible existing run labels without another environment store.

## 10. Shared publication semantics that existing save does not supply

### 10.1 Logical operation identity and exact resolved postimage

Separate stable logical operation ID from immutable operation revision ID. A logical publishing operation can commit once across revisions, enforced by durable unique commitment linked to receipt. Previously committed A copied into revision 2 is a historical reference, not a new eligible write, even with a new idempotency key. A new intended correction is an explicit compensating operation against current official base. Do not use content-hash deduplication to collapse intentionally distinct cases.

Before review, normalize/match recommendations and persist exact kind, existing target UUID or stable logical new-target reference, complete proposed definition, destination/dependencies and authored base. Current zyraDraftTicketLink positional pairing loads ticket-linked cases at save time and can convert a reviewed create into update; bypass/remove that late resolver for protected shared applies in BOTH sequential and set-based branches. Earlier similarity recommendations may remain if the resolved update/base is explicitly reviewed. Changing ticket order/linkage or selected subset cannot choose a new target at apply.

### 10.2 Suite operations, dependencies and locks

Shared staging supports at least SUITE_CREATE and necessary reviewed suite rename/reparent/placement operations. A new parent/destination uses a stable logical operation reference; existing destinations use exact UUID and reviewed hierarchy token. Validate dependency graph/project ownership, reject cycles/missing/foreign/unapproved dependencies and conflicting multiple mutations of one target. Selection must be dependency-closed: each uncommitted dependency is explicitly approved and selected, or the dependency is satisfied by its exact prior committed logical-operation receipt/mapping and still-valid reviewed resource context. Already committed dependencies are neither reselected nor reapplied. Revalidate resulting parent UUID/hierarchy/base; a changed/deleted parent conflicts. Do not implicitly approve/select an uncommitted parent.

Extract existing validated suite writers/parent checks to accept the same transaction client. Parent identity includes lineage: project-global case-insensitive name matching is not resolution of an approved Role/Module tree. Collisions conflict or resolve through a reviewed existing UUID; no silent name-based relocation. Parent deletion effects must be explicitly governed.

Reuse the suite-tree advisory-lock concept across ALL participating create/reparent/delete/import/apply writers. Use one documented lock order: project suite-tree lock when hierarchy is affected, shared envelope, affected resource rows ordered by actual SQL ORDER BY UUID, then existing external-ID allocation lock where required. Reconcile current callers to that order. Sorting an input array passed to ANY does not guarantee PostgreSQL row-lock order. Validate hierarchy/base under lock; no orphan child on concurrent ancestor deletion. Cache effects run after commit.

### 10.3 Receipt/state writers, audit and legacy adapters

Protect review lifecycle and provenance writers in addition to official case writers. Legacy aiSave/generation-history tracking accepts client testcaseIds and marks done without applying cases; it must not mint authoritative acceptance/receipts, inflate counts or hide pending items. Adapt/deprecate it for protected workflows, and inspect close/discard/edit/regenerate tracking similarly. Only actual shared apply transaction creates a trusted receipt from persisted outcomes.

logProjectActivity currently uses the independent pool and swallows errors, even when invoked inside selected-save loops. Add a mandatory supplied-client path for official publication/decision audit; propagate failure and include it in the transaction. Do not wrap the old helper and call the result atomic. Validate all downstream required custom values, IDs, suites and history with the same client; optional notifications stay post-commit.

Current task-board partial save sets done; only chat-linked batches retain remaining entries. Generalized proposal status is independent of chat_session_id/source kind. Keep legacy generation status as a compatibility projection; no fake chat session is needed for external review. Persist each logical operation's terminal/actionable state and derive aggregate completion as in §5.

## 11. Canonical definition adapter and migration fidelity

Create one canonical definition-to-existing-writer adapter and verify field parity through ordinary, sequential and set-based apply. Native fields include source/native IDs, description/pre/postconditions, duration/component/severity, native steps/data, provider links, source refs, custom field values, customTagIds and automation tags as distinct concepts. Draft tags must not silently become automation_tags; set-based custom-field persistence must receive reviewed values instead of an empty object.

Define patch semantics: omitted field means keep current value on update; explicit clear is validated separately from set; null/empty have field-specific rules. For a create, required/default values must be resolved into the exact reviewed postimage. Unsupported fields are rejected or visibly flagged before review, never silently dropped by the current patch whitelist. Snapshot/profile/hash includes all separately stored values.

Use native step objects {stepNumber, action, expectedResult} and independent caseExpectedResults/expectedResponse when applicable. Do not infer correspondence between a global numbered expectation block and steps. Persist independent expectations via an explicit native extension or a reserved, versioned profile field—not Notes or discarded text. Define legacy expectedResults alias mapping and reject conflicting representations. Preserve newlines, pipes and arrows as literal text in a structured/versioned export format; legacy delimiter parsing is an explicit compatibility mode with ambiguity errors.

Extend current importer mapping/staging: workbook source identity and row number, proposed create/update/unchanged/conflict/rejected, exact existing/new-suite references, source/native ID mapping and all applicable fields. Current project-wide normalized-title rejection is not valid identity reconciliation across roles/modules. Keep title similarity as a review warning; never silently drop or merge valid same-title cases. Reimport by stable source identity is retry-safe; a renamed title with the same source ID is an explicit proposed update.

Native external_id has length/case-sensitive uniqueness while the optional reporter resolves lowercased IDs. Reconcile case-fold collisions, leading zeros, length/whitespace and preserve original spelling separately where native mapping differs. Reject ambiguous reporter mappings. Extend existing exports with stable IDs, full parent path/identity, structured steps/global expectations/custom fields and requirement refs, using explicit format version/option to preserve legacy consumers. Prove export → staged reimport without hierarchy flattening or content loss.

Requirement references are a typed list in the profile: local source IDs and approved document/version refs are distinct from native Jira/Linear/Notion link fields. Preserve local reference spelling/cardinality and expose it in detail/search/export/coverage as declared; provider sync is not a prerequisite. Existing Requirements UI is provider-only and requirementMatrix omits reference fields/full bug_links, so extend its read projection/coverage or explicitly label unsupported coverage instead of claiming custom text automatically participates. Reuse case/provider/KB identities, not a new requirements platform.

## 12. Accepted execution history and evidence access

Bind tested definition/custom/profile/environment provenance to exact dispatch/attempt snapshot when accepting results; run-creation snapshot alone can differ if the case changes before execution. Existing history-import accepts replacement history and refreshSnapshots copies latest case data onto cycle items. Add this route/flag to protected writers. Accepted/completed tested snapshots and history cannot be refreshed in place; correction uses a reviewed compensating revision preserving original outcome/definition provenance. Pending/untested refresh, if allowed, remains explicit/audited and cannot change an already dispatched assignment.

Report/proposal artifacts are private by default through an authenticated proxy/content adapter that checks current grant, parent state and applicable scoped ownership on every read. Historical analyst/supplement access does not require an active executor lease; it requires explicit current report access. Do not inherit public cycle sharing or existing one-hour trace bearer links/current S3 redirect TTL. Retain accepted-run sharing compatibility separately. A bearer-URL exception needs an approved bounded lifetime plus documented inability to revoke already issued URLs, or a revocable server-side grant; no exception is enabled for unpublished evidence by default. Test revoke-after-mint, reassignment, parent archive/delete and foreign attachment references.

Analyst clients need actual authorized image/file content, not metadata/counts. Current MCP serializes all results as JSON text. Extend the same report/storage adapter and MCP result representation with client-supported typed image/resource or authenticated content access, retaining artifact ID/MIME/length/hash. Verify actual ChatGPT and OpenCode consumption; a cookie-only browser URL is insufficient. If bytes cannot be inspected, mark evidence unverified rather than claiming screenshot confirmation.

## 13. Source-neutral read models, manual continuation and UI primitives

Provide shared project-authorized paginated analysis/report and proposal discovery with stable sort/filter/source/task/author/assignee state. Existing generation board excludes chat batches and caps the latest 50; it is not the authoritative review inbox. Headless external proposals and old pending work must remain reachable without pasted IDs.

The current case detail route redirects to list and ignores tcId; testcase_versions has storage but no complete frontend read/history path. Reuse repository drawer with durable case/revision URL, routeParams resolution and authorized history/provenance read adapters. Links/notifications must open correct case/version after refresh/new tab, preserving list state. No parallel case/detail application/store.

Manual receipt/import records authenticated human submitter plus separately asserted runtime origin without forged claims. Human analysis/stage-proposal uses shared services with no model key; current Zyra Feedback/regenerate is not that path. Draft editor has explicit dirty/save/conflict recovery. Harden existing Modal/Drawer/Field and comparison primitives for labelled dialog/focus/close/field association and exact non-color base/current/proposed differences; reuse does not imply current accessibility is complete.

## 14. Existing MCP transport and delivery gates

Preserve requested/negotiated protocol versions, fingerprinted sessions, stale-session 404 reinitialize/rediscovery, notification 202, unsupported GET/DELETE behavior, both URL forms and distinction between session ID and authentication. Reuse e2e/api/mcp.spec.ts. Update MCP_SERVER_INSTRUCTIONS that currently recommend direct bug/result writes to describe protected workflow, while enforcement remains in services. Rediscovery/retry after schema change cannot repeat completed logical operations.

Task/report adapters are delivered with the task/report vertical slice; proposal adapters follow shared staging. Approved result acceptance depends on human-decision/apply services. The hardening task has explicit predecessor IDs, not a self-referential all-P0 dependency. Current repository guidance exempts docs-only work from live e2e; this review ran no application/database tests and changes no application code.

### 14.1 Closure-review clarifications

Uncommitted dependent cases can publish later against a previously committed suite operation only through its exact receipt-to-UUID mapping and a still-valid reviewed hierarchy; fresh keys cannot republish the parent. Terminal aggregate semantics distinguish all-publishing MERGED, all-rejected REJECTED/all-withdrawn WITHDRAWN and mixed/copy-only COMPLETED. No actionable item may be hidden by any terminal state.

Only an initial current-attempt primary report finalization moves CLAIMED/IN_PROGRESS to REPORTED. A truthful human primary receipt can drive DRAFT/READY/ASSIGNED to REPORTED under report.import.manual, expected task-version CAS and dispatch/manual-adoption policy when no active executor lease exists; unclaimed assignment closes with an explicit manual-fulfilled reason. If a real executor is active, manual receipt appends provenance only and clearly leaves that lifecycle active; it cannot impersonate, silently cancel or complete the executor. Supplemental/historical receipts append without rewinding UNDER_ANALYSIS/CLOSED/terminal tasks.

After primary finalization, historical supplementation requires explicit scoped report.supplement or human report.import.manual authority against the finalized original and current project/grants. It does not renew old execution authority or authorize new target actions. A new testing action requires a valid follow-up task/attempt. Revoked clients remain denied; historical-source attribution is not a live claim.

## 15. Full-assurance integration contracts and source reuse closure — revision 1.3

**Source boundary:** The 17 October nine-role review independently read all eight revision-1.2 files plus selected source at `124f128`; deployed schema/commit, exact client auth and full product execution are **not** verified. Extend the existing NestJS, `DatabaseService.transaction(PoolClient)`, `pg`, MCP registry, agents/tokens, Zyra staging/save, versions, runs, attachment/storage, settings, queues, providers and violet UI primitives. Do not introduce a second authoritative case/run/proposal/evidence/history store to satisfy these contracts.

### 15.1 D01: intended-versus-observed context and semantic scope

Persist **task-authorized target** (immutable environment ID/context revision, allowed origin/path/action, declared tenant/role/build if supplied) separately from **executor-observed** URL/origin after navigation, runtime/tool/browser version, timestamp and safely verifiable tenant/role/build, with source and UNKNOWN/NOT_REACHED. Normalization must avoid falsely treating a related hostname/IdP as automatically authorized. Store requested verification points and explicit TESTED/BLOCKED/NOT_TESTED dispositions with evidence IDs/reasons. Analysis/report readers must not infer coverage or identity from the prompt alone. No privileged cookie, OTP or secret is accepted in an immutable task prompt.

### 15.2 D05: exact historical reference and full-content consumption

Reuse existing KB/document version storage or an immutable dispatched source snapshot; expose an authenticated **read-only** exact-version adapter returning resolved version, content digest, total byte length, ordered chunk count/indices and completion indicators. A current KB document read, history list or `restore` operation is not a read of historical bytes. Build a paginated/chunked report read with deterministic completeness receipts and actual reauthorized artifact-byte retrieval. Client analysis must confirm it consumed all required content/evidence rather than just JSON metadata/URL. Authorized replacement sessions use paginated discovery plus linked stable IDs; no new transcript store is required. Record errors if the original version/attachment is unavailable.

### 15.3 D02: result equivalence and history protection

**MVP policy:** `RESULT_ACCEPT` for any new or edited case requires a subsequent authentic execution bound to the exact **approved** definition (case ID, authored-version/hash, steps and independent case expectations, custom/profile/context versions) and actual outcome/evidence. Earlier exploratory findings can support approval of an authored definition but cannot create formal PASS/FAIL against a later definition. Keep candidate result separate until this test passes; the existing `cycles`, `cycle_items`, `executions` and history are the only official destination. No unreviewed compensating import, refreshSnapshots or reporter update can rewrite already accepted tested history.

### 15.4 D03/D04: external action authority and evidence trust

Treat structured task policy as a restricting upper bound on natural-language instructions. Explicitly define URL origin, scheme, IDN/punycode/port/path, redirects, IdP domains, new tabs, downloads, form submissions, state-changing operations and evidence egress; require clarification for inconsistencies, and a cooperating client checks current lease/grants before target actions. A revoked offline client cannot be forcibly stopped; report actual limitations. Admission path: reserve receipt → upload to project/receipt-owned storage → enforce bytes/hash/MIME/size/AV where supported → classify PII/secrets/external instructions → quarantine or create separate hashed redacted derivative → finalize only an authorized admissible manifest. Keep restricted original verifiable and immutable with restricted access; never silently overwrite. Preserve provenance for consumption, exports, logs and model prompts without copying secrets.

### 15.5 Deterministic races, upgrade and injection testing (V01–V06)

- Two primary report finalizations with **different** idempotency keys for one attempt: row lock plus authoritative attempt constraint yield at most one primary; loser gets a typed conflict and no second REPORTED transition.
- Concurrent upload/finalize/abandon/cleanup: finalized bytes are immutable and cleanup cannot remove them; stale pending artifacts cannot become a finalized manifest later; old uploads cannot replace current checksums.
- Authorization/profile/reviewer-grant change racing transactional apply: linearize protected policy reads and final revision/decision checks inside the same transaction/locking regime, or deny with safe retry. A stale previously approved request cannot commit after the revocation becomes authoritative.
- Mixed pre-migration and new records: explicit backfill/default semantics, reversal or forward-fix and backup proof; no bypass via legacy `read,write` tokens, null provenance, imported histories or old chat rows.
- Hostile web content → OpenCode and hostile report/attachment → analyst must remain **data**, never authorize widened target scope, file exfiltration, additional MCP calls, secret exposure or forged approvals. Attack fixtures must verify actual outputs and audit, not rely on prompt wording.
- DMIS pilot-only tolerance/navigation fixtures (slow readiness, expired OIDC and horizontally offscreen wizard control) stay separate from Tesbo UI responsiveness or simulated work.

### 15.6 Open external interfaces and gates

MCP contract owner: `04_MCP_API_CONTRACTS.md` §12; UX owner: `02_WORKFLOW_AND_UX_SPEC.md` §11 and `07_UI_DESIGN_TASKS.md`; requirement owner: `01_PRODUCT_REQUIREMENTS.md` §10; scenario owner: `05_IMPLEMENTATION_BACKLOG_AND_TEST_PLAN.md` QA-094–QA-122. Original 36 task IDs remain. F01–F07 in README govern freeze/release. Green's optional bounded continuation projection is a **derived view**, not an additional authoritative data primitive. Deferred policy choices and formal reviewer receipts must not be marked resolved by documentation alone.

### 15.7 Coverage and enforcement closure — revision 1.3.1


**Third-pass NFR engineering gate (revision 1.3.2):** Reuse existing telemetry, queue, storage, version/history, agents/MCP, UI and maintenance pipelines to meet NFR-002/004/005/007/010/011/012; do not create new evidence, analytics or portability subsystems. Map one real second runtime with a separate principal and unchanged schemas; scan/quarantine hostile artifact fixtures *before* making them available to analyst/model/public previews; validate end-to-end lineage from committed testcase version back to immutable original artifact bytes; monitor queue depth, expired leases, rejected auth, finalization/merge failures and retries with safe labels and cardinality; agree P95/P99 or other selected threshold/workload from measured baseline before a PASS; enforce configured retention, hold/restricted deletion and preserved minimum audit provenance. Prefer instrumenting existing observability/tracing helpers, which do not automatically sanitize metadata, headers, screenshots, or model payloads.

Treat novel backend task/proposal states and unknown grant values as **deny/unknown**, not successful legacy status. The same canonical server-side policy service remains authoritative across REST/MCP/legacy; UI fallbacks are user feedback only. QA-123–QA-129 (alongside QA-080/114) verify these contracts; each is planned and subject to demonstrated deployed/runtime evidence.


Trace each existing operation capability independently through agent instance/current grant, issuer delegation, transport, service, authoritative write, mandatory audit and error path (QA-116). `read`/`write` legacy-token compatibility must not collapse the ten different task/report/analysis/review/merge/admin privileges. Parameterize both positive and negative request identities, reauthorization after revocation, and direct entity/MCP aliases. Expose credential identity/activity facts through current Agent list without treating `created` as `online` (QA-117). Rejected final-report rewrite attempts and supplemental writes must share the existing storage/receipt lock+integrity contract, including direct upload key attack (QA-118). Keep case authoring, observations and accepted execution separately typed (QA-119/120). Every protected outcome has real principal/interface/project/target/correlation and transactional audit when consequential (QA-121); prompt/context secrets are rejected or restricted before persistence, task dispatch and model/tool egress (QA-122). No new parallel datastore or service is authorized.

## Revision 1.3.3 — implementation-policy decisions and canonical-source discipline

**Policy implementation baseline:** Apply README PD-01–PD-08 through existing `projects.settings` (reserved versioned namespaces, compare-and-set), agent/actor identity, `api_tokens`, shared Zyra stage/apply, PostgreSQL transactions, report storage, audit and current UI primitives. Do **not** introduce a parallel permissions service, evidence database, CRM, browser runner or commercial entitlement bypass.

1. **Approvals and delegation:** Bind review decision to an actual authenticated human principal, current `approve` grant, operation/revision/hash and policy revision. Bind selected apply to the separately authorized `merge` grant; re-evaluate authority *inside* the publication transaction. Project owner may delegate approval (scoped, auditable, revocable), without transferring project ownership or inheriting from `api_tokens.userId`. Transactionally forbid removal of the last authorized reviewer. Preserve a configured stronger two-person rule when explicitly present.
2. **External task scope:** New task policy must carry HTTPS exact origin, normalized hostname/port/path, permitted actions, redirect/IdP/egress exceptions and signed dispatch revision; default GET/navigate/nonmutating inspection only. Browser state-changing UI actions are classified by actual effect, not merely HTTP verb. Undefined classification is deny/clarify. No secret fields stored in prompt, logs, traces or ticket text. Revoked/offline clients cannot be forced to stop; runtime cooperates by checking current fencing/grants before impactful acts.
3. **Bounded private evidence:** Enforce pilot config ceilings 25 MiB/artifact, 250 MiB/receipt and 2 GiB/project (synthetic only), with atomic accounting for concurrent reserve/upload/finalize and typed quota errors. Pending receipts expire at 24h; synthetic artifacts at 7d only if no pending/approved result or review/provenance references them, otherwise hold; repeated cleanup preserves original audit and does not race finalized content. Unknown malware/scanner availability fails closed, quarantine stays inaccessible to analysis by default. Sensitive real-project evidence intake remains disabled for that project until classification, retention, geographic residency, exception and deletion/hold policy are approved.
4. **Entitlements:** Do not call internal model allocation for external task/report/review. Existing membership, plan, project writability and storage rules still apply. When project becomes read-only, permit currently authorized historical reads and prohibit new task/report/proposal/merge writes; never issue a broad long-lived token as a fallback. Billing changes require explicit product authorization and relevant tests.
5. **Migration:** Use existing import/field mapping; preserve source workbook digest and stable source-case ID independently of UUID. All field loss/collisions/unmapped requirements block affected lines; entire-suite cutover is gated on approved sample mapping, exact readback, backup and tested restore/forward-fix. Keep tested snapshot/history independent of mutable authored definition.
6. **Integration and performance:** Initial manual pickup only; optional agent-side poller feature flag after real client tests. MCP inbound auth must be verified with actual connected ChatGPT/OpenCode configurations. Use existing telemetry to instrument latency and load and select release thresholds only from measured representative staging runs. Existing CI/e2e suites must prove both negative and positive compatibility paths.

**No-go conditions:** no real sensitive-project capture without project-specific privacy/security/retention authorization; no official apply before protected-writer/red-team tests; no source migration without that project’s actual source-data signoff; no claims of ChatGPT MCP/Chrome image-byte support or achieved throughput without an execution receipt. Source audit is not deployment proof.

## 16. Durable project sessions, single web Copilot and universal execution architecture — revision 1.4.3

### 16.1 Existing-first reuse and semantic gaps

Generalize existing `zyra_chat_sessions` and `zyra_chat_messages` in the existing NestJS/pg stack; preserve historical session/message IDs and compatibility with `V89_zyra_chat_review.sql` and `ai_generation_requests` links. Existing `agents`, `actors`, `api_tokens`, KB documents/versions, audit logs, storage and BullMQ support the extension. A migration may add project-neutral session attributes and an **append-only ordered event stream** only after proving existing chat rows cannot represent tools/progress/handoffs/retries with required provenance. Do not duplicate chat, KB, official cases, cycle executions, bugs or shared review staging. Treat duplicate Review Board as a different domain.

Conceptual contract (not a claim existing tables have these columns): `Platform Copilot UI (singleton interface) -> selected Project -> QA Session -> ordered Event`; `QA Session -> Participant Binding (backend/runtime instance, role, provider thread ID)`, `Session -> Task -> Attempt -> Immutable Report -> Artifact`, `Session -> Proposal Revision -> Human Decision -> Protected Apply`. KB document versions, repository cases, run snapshots, Bugs and receipts remain referenced by stable authorized IDs. The Copilot creates no separate source store and loads session-scoped context by project/session authorization on each switch. Server-assigned event sequence, idempotency and immutable KB-version citations support replay and recovery.

### 16.2 Execution selection and adapters

Create a *small integration facade around existing MCP/domain endpoints and NestJS services*, distinguishing **analysis-model adapters** from **execution-agent capability bindings**; do not require a new controller for user-managed agents. For optional hosted/gateway transports use a small adapter interface with `discoverCapabilities`, `checkReadiness`, `startOrResume`, `sendInput`, `streamEvents`, `requestPermission`, `cancel`, `recoverStatus`, `dispose` as applicable. **Primary execution requires no agent-hosting adapter in Tesbo:** registered user-managed/remote task executors use existing Tesbo MCP and shared domain services. A separately configured hosted SDK, isolated worker or gateway adapter is conditional on the optional managed-execution mode. Advertise only verified auth, runtime version/protocol, compatible models (if exposed), tool/evidence support, cost information, and current status. The Copilot backend is not automatically the task executor. Do not presume each CLI can run through an end user browser or that all protocols support resume.

- **Claude Code:** evaluate official Agent SDK (`query`, `resume`, `stream`) for app embedding and CLI headless where appropriate; provider session files are local unless explicitly persisted, and never equal Tesbo history. Official: https://code.claude.com/docs/en/agent-sdk/sessions and https://code.claude.com/docs/en/headless.
- **Codex:** prefer `codex app-server` when embedding streamed turns/approval requests; use SDK or bounded `codex exec` for automation. Track app-server thread ID as an adapter binding only. Official: https://developers.openai.com/blog/codex-as-a-platform.
- **Kimi CLI:** evaluate supported `--print --output-format stream-json` for bounded automation and tested ACP support where version supports it; explicit session resume via ID, no arbitrary interactive stdout parsing. Official: https://moonshotai.github.io/kimi-cli/en/reference/kimi-command.html.
- **Hermes:** evaluate the user-authorized Hermes gateway/session API for long-running work; bounded CLI `hermes chat --query-file -` where supported, with durable native gateway session ID. Gateway may continue after UI detaches; reconcile before retry, not duplicate a turn. Official: https://hermes-agent.nousresearch.com/docs/user-guide/cli.
- **ACP:** the Agent Client Protocol supports editor/client↔agent sessions and permission/event negotiation, *not* the Tesbo MCP tools used to read/modify QA records; probe negotiated protocol/capabilities rather than assuming a universal ACP implementation. Official: https://github.com/agentclientprotocol/agent-client-protocol.

**Execution-location boundary (no mandatory companion):** Tesbo is a web-only SaaS/application. Its frontend never scans a laptop PATH, connects to a local daemon, installs a CLI or executes user workstation commands. A **user-managed execution agent may already run on the tester’s machine** and connect to Tesbo MCP to claim/report tasks. Its own installed CLI, execution environment, authorized target access, browser MCP and existing VPN (if any) remain independent of Tesbo. Only if the project explicitly chooses managed execution should Tesbo deploy a supported agent runtime in an isolated server-side worker or configured remote gateway. Native Copilot chat itself may use hosted provider APIs and must never require a workstation CLI. Use least-privilege project/task identity, sandbox/ephemeral workspaces, tool/command allowlists, network egress restrictions, quotas, process termination, secret isolation and auditable receipts. No arbitrary host shell invoked from chat. External OpenCode/Hermes agents may independently connect through scoped Tesbo MCP and are never represented as managed by Tesbo unless actually deployed as workers.

### 16.3 Model/auth, handoffs and failure semantics

Model/provider allocation is distinct from hosted agent/runtime selection, external MCP execution, and project task authorization. Copilot chooses the configured hosted API/SDK or an available **server-hosted agent**; separately assigned executors operate via scoped tasks/MCP. Subscription login, CLI entitlement, BYOK API entitlement, and commercial agent-hosting permission are not interchangeable; verify each actual provider pathway. Model choices are verified capability reports, never assumed from names. Fresh session handoff uses an application-owned manifest (objective, decisions, open questions, KB/case versions, task/report/proposal/approval links), not a fabricated provider transcript; source reads are reauthorized and audited.

Persist the user message/event receipt with correlation/idempotency ID before side effects. Normalize streaming start/delta/tool/permission/completion/error while retaining safely admitted original logs. On hosted worker crash, remote gateway disconnection, external MCP agent loss, or timeout distinguish `never_sent`, `accepted`, `completed`, `failed`, `unknown` and reconcile before retry. Switching Copilot project/session/backend never merges histories, imports another provider’s hidden transcript, or confers approval rights. Human review is separate from model/tool approval.

## 17. Verified external architecture comparison, reuse decisions and technology boundaries — revision 1.4.3

**Baseline to preserve:** audited fork `1alextest/Tesbooboo@124f128`: Next.js 16/React 19 frontend, NestJS + PostgreSQL, BullMQ/Redis, Langfuse, existing Zyra chat tables/UI, `ai_generation_requests` staging, `agents`/`actors`/tokens, KB, storage and MCP. Source inspection is not deployed proof. The project is a web application; browser clients do not start local CLI processes. A single Copilot UX selects many project-scoped sessions; model backend and execution agent are different runtime choices. See P-01–P-20 in README.

### 17.1 Existing products and components: adopt vs learn vs defer

| Candidate (upstream reference, observed 17 Oct 2026) | Verified capabilities / integration shape | Decision relative to existing Tesbo | Proof/concerns before adoption |
|---|---|---|---|
| [assistant-ui](https://github.com/assistant-ui/assistant-ui) | MIT React chat/thread/composer primitives; streaming, tool rendering, accessibility, custom backend; optional hosted thread service | **FIRST UI SPIKE**, not wholesale application replacement. Compare small integration into existing Zyra/Copilot screens vs improving native UI | Reuse current Tesbo session/event API, existing violet tokens, auth, source links, no `assistant-cloud` or second chat store; a11y and streaming regression |
| [CopilotKit / AG-UI](https://github.com/CopilotKit/CopilotKit) | MIT React agent UI, shared state, human-in-the-loop and AG-UI bridge | **ALTERNATE UI SPIKE ONLY** if complex agent-driven UI requires it; don't install both chat frameworks by default | Fit with NestJS domain policy, existing Zyra controls, exact approval boundary, package footprint and optional cloud features |
| [LibreChat](https://github.com/LibreChat-AI/LibreChat) | MIT multi-provider chat, persisted sessions, MCP, agents, RAG and streaming; standard full deployment includes separate backend/stores | **SELECTIVE INCORPORATION CANDIDATE**: inspect React components, packages, message/tool/agent affordances and portable utilities for direct integration into existing Tesbo Zyra/Copilot; do **not** deploy a competing full LibreChat application | Verify actual code-level portability into Next.js/React, dependencies, design-system and auth compatibility, maintenance/upstream merge path, Tesbo session/KB ownership |
| [OpenCode SDK / headless server](https://opencode.ai/docs/sdk/) and [server API](https://opencode.ai/docs/server/) | MIT agent with documented HTTP server, JS/TS SDK, session lifecycle, SSE events and structured outputs | **OPTIONAL HOSTED EXECUTOR SPIKE** after the primary user-managed MCP executor; do not make its provider session Tesbo session authority | Confirm version/SDK API, isolated worker support, tenant filesystem/network sandbox, cost, model auth, MCP tool binding, cancellation and report/evidence fidelity |
| [OpenHands Agent SDK/Server](https://github.com/OpenHands/software-agent-sdk) | MIT Python/TypeScript/REST APIs; hosted ephemeral workspaces, conversations and tool execution | **CONDITIONAL HOSTED RUNTIME SPIKE**, especially for code/complex QA agents | Isolation, cost/limits, auth, cancellation, provenance, hosted worker architecture; not a default platform orchestrator |
| [Midscene.js](https://github.com/web-infra-dev/midscene) | MIT natural-language visual actions/assertions, Playwright, reports, multiple UI targets | **FIRST OPTIONAL WEB EXECUTION SPIKE** as a hosted adapter, not a replacement for external Chrome/Playwright MCP | Evidence export, assertion accuracy, flaky repeats, source-report integrity, tenant isolation, synthetic website smoke |
| [Stagehand](https://github.com/browserbase/stagehand) | MIT browser act/extract/observe SDK (TypeScript/Python/Go), compatible with browser automation | **ALTERNATE WEB ADAPTER SPIKE** alongside Midscene, not both by default | Deterministic assertion bridge, reliable screenshots/reports, hosted browser provision, rate/cost controls |
| [browser-use](https://github.com/browser-use/browser-use) | MIT browser automation agent library and separate cloud service | **OPTIONAL EXECUTOR**, not QA lifecycle/source store | Can it produce reliable test oracles, structured receipts and auditable evidence? Cloud fees/data residency separate |
| [Qase MCP Server](https://github.com/qase-tms/qase-mcp-server) | MCP integration for cases, runs, defects, discoverable task-oriented tools; Qase is not Tesbo | **DESIGN REFERENCE** for restructuring existing 50 Tesbo MCP tools; do not deploy another MCP backend | Preserve aliases/compatibility; enforce actual project/resource/domain permission before every tool call |
| [LangGraph persistence](https://github.com/langchain-ai/langgraph) | Thread checkpoints, durable agent graph state and cross-thread stores | **DEFER** as orchestration framework; extract patterns where existing pg+BullMQ insufficient | Do not introduce a second authoritative session history or competing queue; benchmark interrupt/resume/retry first |
| [A2A protocol](https://github.com/a2aproject/A2A) | Inter-agent task/context IDs, status/streaming and interoperability | **OPTIONAL FUTURE ADAPTER** for independent agents; MCP remains first project QA tool transport | No assumption of interoperable clients; map A2A contextId/taskId to Tesbo session/task without duplicate authority |
| [Open WebUI](https://github.com/open-webui/open-webui) | Full web AI assistant/knowledge UX; post-0.6.5 code carries branding restrictions | **REFERENCE ONLY**; do not import branded UI/system without legal review | Parallel storage/auth risks and owner-directed incorporation decisions: https://docs.openwebui.com/license/ |
| [Skyvern](https://github.com/skyvern-ai/skyvern), [TestZeus Hercules](https://github.com/test-zeus-ai/testzeus-hercules) | Browser/QA automation with AGPL-3.0 licensing | **REFERENCE / EXTERNAL INTEGRATION EVALUATION**; no copied/embedded AGPL code pending project-owner incorporation decision | Network/hosted-service separation, AGPL implications, test/evidence reliability, overlap with existing runners |
| [Momentic](https://momentic.ai/), [Qase AI](https://docs.qase.io/en/articles/14442830-ai-in-qase) | Commercial AI testing, generated cases, cloud execution and defect workflows | **COMPETITOR BENCHMARK**, not reusable open-source foundations | Benchmark true differentiators: one durable Copilot, multi-agent sessions, canonical KB, original report, retest loop, exact human-approved writes |

### 17.2 Architectural synthesis: compose, do not replace

1. **Core domain: Tesbo owns** user/project/session IDs, participant grants, document versions, QA task/attempt, immutable reports, staged proposals, decisions, official cases/results/Bugs, audit and outbox/job receipts. PostgreSQL remains the authoritative system; existing BullMQ/Redis handles event/outbox dispatch. Reuse existing `zyra_chat_*`, `ai_generation_requests`, version/attachment services, rather than proxying all truth into a third-party agent framework.
2. **One web UI:** upgrade existing Zyra/Copilot shell; consider assistant-ui **only** as composable presentation primitives after proving it does not duplicate or replace Tesbo routing, history, auth or design system. AI backend selection is not executor assignment. Streamed external tool events are linked to Tesbo event identities.
3. **LLM layer:** reuse existing model provider catalogue/API integration for native chat; a user-managed coding agent is a separate runtime, and optional hosted agent workers are a later independent deployment choice. The external MCP channel stays usable with no native inference subscription allocation for already-authorized non-LLM task/report operations.
4. **Test execution:** User-managed OpenCode/Hermes/OpenClaw/Claude Code/Codex/Kimi or another compatible agent first claims a scoped task via Tesbo MCP (or verified adapter), executes using its **own** browser/Playwright/API/mobile tools and returns an original report. Agent MCP support or a supported plugin/transport bridge must be verified for each runtime; agent registration alone cannot start it. Hosted workers may use Stagehand/Midscene/Playwright or another supported adapter; report outputs normalize to one Tesbo-owned immutable receipt/evidence contract. **AI interactions alone do not certify assertions**: preserve exact expected/observed comparison, deterministic checks where possible, explicit `UNKNOWN/BLOCKED` and human review.
5. **Workflow protocol boundaries:** MCP = Tesbo tools and executor's target-tool interfaces, AG-UI = optional realtime model/agent UI event projection, A2A = optional peer-agent exchange, ACP = optional agent interface where supported. None replaces authoritative domain lifecycle. No browser-side arbitrary CLI/shell API.
6. **Target access belongs to executor:** If a user-managed agent can already reach an application (including through its own established VPN), Tesbo does **not** need VPN plumbing, tunnels or target-host routing. The user-managed agent retrieves work and uploads reports through internet-accessible, authorized Tesbo MCP. **Only** managed/other remote workers that lack target connectivity need optional target-network planning; never open an unrestricted public tunnel. Capture network-scoped worker trust, credential and egress boundaries, evidence storage locality, cancellation and disconnection recovery. No machine-side Tesbo companion is part of standard user setup.
7. **Cost, security and maintenance:** server-side sandbox isolation, per-project credential/target allowlist, short-lived capability, model budget, network egress, quota/retention, kill/cancel, audit; evaluate upstream cadence, backward compatibility and package impact before dependencies.

### 17.2A Universal execution-layer taxonomy and OpenClaw/Grok-box options — revision 1.4.3

Treat **five independent layers** as distinct: (1) Tesbo QA control plane, session history, MCP and approved stores; (2) Copilot analyst/model API; (3) **agent runtime** (OpenCode, Hermes, OpenClaw, Claude Code, Codex, Kimi or any supported executor); (4) **execution substrate** (the executor's existing OS, optional Grok-box or another isolated sandbox); (5) **target driver** (Chrome MCP, Playwright MCP, Appium, API client, etc.). The executor controls its own tools and target connectivity. A runtime need not be installed on Tesbo's servers for its MCP task/report participation.

| Candidate | Type / confirmed interface | Tesbo integration posture |
|---|---|---|
| [OpenCode](https://docs.opencode.ai/docs/mcp-servers/) | Agent that can connect to remote/local MCP tools; optional SDK/headless HTTP server | **First user-managed external-agent proof**: connect Tesbo MCP, manually claim task, test with user's existing tool, submit source/evidence; SDK/server only optional later |
| [Hermes](https://github.com/NousResearch/hermes-agent) | Agent runtime with configurable remote HTTP MCP; gateway and ACP modes are separate | **Second-runtime comparison**: test project-scoped MCP identity/capabilities, task pickup, evidence and session handoff; no assumed gateway parity |
| [OpenClaw](https://docs.openclaw.ai/concepts/architecture) | Persistent multi-agent gateway, WebSocket client/node model and extensible skills/plugins | **Alternative persistent executor**: prove an authenticated Tesbo-facing adapter/plugin or task poller and report path first; don't assume native parity with an MCP client |
| [Grok-box](https://github.com/hexuria/box) | MIT Docker/Linux sandbox with authenticated shell, files, Chromium/Computer Use HTTP and SDKs; not an LLM planner or Tesbo workflow engine | **Optional execution substrate** for an authorized agent requiring isolated compute; do not present as a standalone AI execution agent or expose privileged sandbox ports publicly |

**Primary integration contract:** Tesbo records assigned executor identity and connection mode (`USER_MANAGED`, `REMOTE_GATEWAY`, `TESBO_MANAGED_OPTIONAL`), target-tool capability and task/attempt fencing. The executor reads exact permitted KB/task context over Tesbo MCP, runs tools in its own environment, submits immutable report/evidence, and can receive later clarification/retest tasks. User-managed clients initially pick up tasks manually; autonomous dispatch requires separately running client-side scheduling or a proven inbound gateway mechanism. Tesbo cannot wake an offline laptop from MCP registration. Machine/network authorization remains scoped and evidence ingestion scanned independently.

**Open-source embedding policy:** Evaluate a **specific source package/component/function** for direct addition to Tesbo (LibreChat UI primitives, agent/tool views, selected utility code, assistant-ui, etc.) by extracting only what interoperates with existing `zyra_chat_*`, `ai_generation_requests`, Knowledge Base, theme and NestJS APIs. Compare extension-only, selective incorporation and full-framework runtime cost. Maintain source provenance, integration notes and upstream update plan. Never create a second identity, session, KB, test-case or defect store merely to reuse an external UI.

### 17.3 Reuse-first spike scoring and no-go triggers

For each candidate record: `existing Tesbo path`, `actual unmet requirement`, `candidate capability`, `integration hours`, `added stores/services`, `data ownership`, `tenant/safety posture`, `reversibility`, `measured evidence`. Compare against **no new dependency** and a small in-house extension; score maintainability and semantic fit above feature count. Prove one scoped feature (existing Zyra chat → session switch → knowledge version citation → agent task → immutable report → retest → approved proposal) on a **non-DMIS disposable project**.

**No-go:** new compulsory desktop software to use Tesbo Copilot; forced migration from a user-managed agent to a Tesbo-managed worker; duplicated canonical KB/chat/test/bug stores; direct unapproved publication; app-wide arbitrary shell access; remote executor lacking source/evidence attribution; new workflow engine introduced before existing PostgreSQL/BullMQ reliability was measured. Do not imply selected tools already integrate with the fork; none was installed or live-tested in this research.

## 18. Module-level reuse audit, dual entry paths and project MCP governance — revision 1.4.4

**Source audit basis:** `1alextest/Tesbooboo` project route pages and selected matching migrations/services inspected 17 October 2026, alongside the pinned repository audit; **not** an exhaustive database/deployment runtime inspection. Do not infer a displayed action is fully implemented. Paths below refer to `Tesbo-Frontend/app/(app)/projects/[id]/` unless specified; current source is one implementation basis, not evidence of deployed parity.

| Existing sidebar area | Actual inspected code/contract | Reuse and necessary bounded extension; no replacement store |
|---|---|---|
| Project home | `dashboard/page.tsx`, project dashboard summary and caches | Show per-project QA sessions/tasks/pending changes summary via existing dashboard components; link to Copilot rather than reproducing dashboard |
| Requirements | `requirements/page.tsx` uses Jira/Linear/Notion/all-ticket listing, linked-key APIs, `getRequirementsSummary`, `getKnowledgeFolderTree` | Keep linked requirements and source mapping; add session/task source citations and selected requirement-version context, not an unrelated AI requirement repository |
| Test Cases | `testcases/page.tsx`, `listTestCases`, `listSuites`, `getTestCase`, CRUD, custom fields/tags; `testcase_versions` (V63) | Keep cases/suites, definitions, existing case detail/history; Copilot stages reviewed changes, protected case writer checks exact approval revision; case links resolve here |
| Test Plans | `plans/page.tsx`, `listPlans`, `createPlan`, `deletePlan`, `PlanCard`, pass-rate metrics | Keep authored plans; optionally link a QA session/task to an existing plan; do not promote exploratory report automatically to a plan |
| Runs | `cycles/page.tsx`, `listTestRuns`, `createTestRun`, `getTestRunEnvironments`, `cycle_items` snapshot (V119), execution history (V140) | Keep run/case snapshot/result model; report-only exploratory attempts remain outside official PASS/FAIL until approved case/snapshot match and result authorization |
| Bugs | `bugs/page.tsx`, `listBugs`, `createBug`, `uploadBugAttachments`, link picker, evidence/comment/link tables (V48–49, V129–131) | Stage AI issue drafts in shared Zyra proposals; only selected approved native Bug creates/links official bug and any explicit execution side effects |
| Insights | `reports/page.tsx`, `getRequirementMatrix`, `getReportsInsights`, existing reports components | Reuse reporting metrics; add source-labelled AI task/session/agent attempt metrics only when backed by records; no second AI-specific analytics service |
| Agents / Tasks | `agents/page.tsx`, `getZyraAgent`, `ZyraChatReviewPanel`, `ZyraDraftEditor`, `ai_generation_requests`, V35/V89 and actor tables | Extend existing Zyra chat/task/review and Agents identity with external analyst/executor instances; separate existing generation API from agent-owned testing tasks; one Copilot, many sessions |
| Knowledge Base | `knowledge-base/page.tsx`, folder/document/file CRUD, V45 project-root uniqueness, V102 document history, V54–57 RAG | Keep one canonical document/version identity and share links across sessions; summaries are derived session artifacts, never duplicate KB source files |
| Activity Stream | `activity/page.tsx`, `getActivitySummary`, `listActivity`, append-only `audit_logs` V62 | Add existing-stream events for permission toggles, session summaries, dispatch/report/decision/apply; do not duplicate raw private transcripts or evidence in activity bodies |
| Project Settings | `settings/page.tsx` has `general`, `testRuns`, `members`, `apiTokens`, `customFields`, `integrations`, `customTags`; `src/auth/api-token.service.ts`, V5 | Extend `apiTokens`/integration UX with explicit project `externalMcpEnabled` plus per-client grants, session scopes and audit; native internal UI remains usable when external MCP OFF |

**Dual-entry operation boundary:** External ChatGPT/Claude calls existing `/api/mcp` through *new authorized adapters* and never needs native Copilot. Native Copilot uses the same authenticated domain services through REST/application API and selects a model/API or compatible hosted/remote CLI/SDK gateway for chat. Neither path writes official entities directly as a proposal-only actor. **Do not** create parallel controllers with separate business-rule implementations. Record origin (`external_mcp`, `native_copilot`, `executor`), principal, client, selected session, task, attempt and correlation, and preserve no hidden-provider-transcript claims.

**Effective external authorization:** `permit = organization_external_policy && project.external_mcp_enabled && principal_active && project_membership && client_binding_active && credential_valid && operation_capability && permitted_resource_scope && session/conversation_thread/task constraint && data_class_scope && human_only_guard_if_applicable`. Deny if ANY condition fails. Project opt-in defaults false. `tools/list` and `list_projects` filter by this intersection but `tools/call`, REST adapters, evidence download and existing legacy domain writers **reauthorize on every request**. Disabled projects must not be enumerated or inferred through counts/error differences; use opaque not-found/denied semantics appropriate to authenticated caller. Native UI permissions remain independent of external opt-in. Migration must quarantine/rotate explicit current `read,write` legacy tokens: never auto-expand into newly privileged connected-client access; interactive authenticated project-owner consent required to grant newly protected capabilities. On revocation, prevent new calls, active upload finalization, further progress/heartbeat or new claim; preserve already accepted immutable receipts and safely reconcile in-flight requests. Previously exported data cannot be remotely erased.

**Minimal schema extensions (reuse current foundations; exact migrations to be designed against deployed schema):** project-level MCP exposure state/version; external-client/consent bindings and scoped grants (project, actor/user, client identity, credential identity, actions, authorized session/task/resource classes, expiry/revocation); session participant/source bindings; immutable `session_summary_revisions` (linked to `zyra_chat_sessions`/canonical generalized session ID), with source kind `external_chat|native_copilot|execution_agent`, source app/runtime, visibility/completeness declaration, represented period or source event range, referenced task/attempt/report/event/hash IDs, revision, submitted-by actor, provenance and audit. Store a raw submission receipt or content digest separate from human-editable summary view; do not store nonexistent third-party private messages. Link native/external summary revisions to standard session events without merging them into the authoritative KB.

**Summary safety:** trust levels: original signed Tesbo action/evidence receipt > provenance-linked observation > analyst narrative/summary. `submit_session_summary` is a contributor assertion even if ChatGPT authored it; executor summary is an observation digest, never a substitute for exact report/evidence bytes. Require source IDs for claims where available; explicit `transcript_not_fully_visible`/missing intervals, max size, semantic injection screening, source-version drift and user-visible corrections. Check submitter authority and referenced IDs server-side, enforce idempotent attempt/summary versioning, preserve original/historical summaries and reject unbounded cross-project aggregation. Use source-linked summaries as a **retrieval optimization**, with original KB/case/evidence accessed under fresh permission at read time.

**Architecture proof before claiming completion:** External ChatGPT (not native Copilot) performs project/session discovery → KB/Requirements → task/retest → report → proposal using only Tesbo MCP; external disabled project remains invisible; native Copilot changes its own chat backend within the same existing session; user-managed OpenCode plus a second runtime submit equivalent attempt reports; external chat and execution summaries are attributed and insufficient to fabricate PASS; only human-reviewed selected operations update the official modules.

**Reuse-minded storage shape for multiple chats per QA session:** Existing `zyra_chat_sessions` / `zyra_chat_messages` remain the authoritative native message storage; add minimal nullable `thread_id`/binding references and session-thread metadata when actual multi-thread behavior needs it, rather than duplicating conversations in a LibreChat schema. A thread binding records session, source client, owner, opaque provider-native thread identifier only if disclosed, `visibility=full_native|partial_external|summary_only`, grants and timestamps. Executor tool logs/reports remain task/attempt artifacts and reference the session rather than pretending to be ordinary user chat messages. Session rollups aggregate links and summaries without materializing another set of original bytes.


## 19. v1.4.4 full-assurance source-to-design gates — revision 1.4.5

**Minimal parent/child reuse:** `zyra_chat_sessions` + `zyra_chat_messages` (V41, V89, V116/V127/V128) preserve conversation history, processing ownership, soft-delete/review references and source traces; they are not inherently the requested *multiple threads within one QA session* domain. First test whether a narrow `qa_sessions` parent plus `qa_session_id` binding on existing chat threads and task/report/link records is the minimum durable change. A parent record is a justified distinct lifecycle, **not** a second chat store. Define owner, participant membership, private-thread access, deletion/archive behavior, source-reference revocation and retention before migration; retain historical IDs and display.

**MCP policy and actor migration:** The actual `ApiTokenService.normalizeScopes` implementation currently falls back to `['read','write']` if no valid scope was supplied. The actual MCP `tools/list` returns the static full registry and `callTool` checks only tool `requiredScope`. `mcp.tools.ts` includes direct `create_testcase`/bulk/direct write operations; V65 seeds one `tesbo-mcp` actor for all token-client writes, with some KB/bug writers using the token-owning human ID. The new semantic authorization matrix must check effective project-enable state, named client, actual human/instance, session/thread/task grant, per-resource sensitivity, and operation at every read/write/media/proposed writer, and capture true origin/initiator/delegation rather than misattributing an AI write to a human reviewer. Do not merely relabel the shared actor.

**Multi-project discovery:** Existing `/api/mcp` and project-qualified MCP routes take a single project token. An authorized external user discovering multiple projects needs a separately designed, revocable identity/consent binding (e.g. supported OAuth/client authorization plus explicit project grants) that maps to the same domain guard. It must not widen legacy project tokens by guessing all of the issuer's projects. Verify actual ChatGPT/Claude MCP authentication and tool-use capabilities; do not assume an already working client.

**Knowledge uniqueness (historical correction):** V45 originally constrained `(source_provider,source_external_id)` globally, but V72 already replaced that unique index with project/provider/external-ID/source-role identity in the pinned source. Test two projects and mirror restore after replacement; do not duplicate the migration. The current KB UI has an explicit `duplicateKnowledgeDocument` operation and the migration seeds a `Screenshots & Evidence` KB folder: these existing behaviors need a canonical-document policy (link/revision vs independently authorized clone) and evidence authority labels before claiming no duplicate source files or identical project context across sessions. Deduplication must never reveal an otherwise unauthorized document or cross-tenant hash match.

**Requirements and evidence truth:** A linked Jira/Linear/Notion issue may change independently of a Tesbo task. Persist exact externally observed snapshot/version or explicit missing provenance, not a mutable current read disguised as task-time knowledge. An executor on its own machine has tool autonomy and target connectivity; Tesbo may constrain task authority and ingest evidence but cannot remotely prove/control every browser click unless the executor/tool actually supplies attested records. This belongs in actual agent acceptance, not product marketing.

**Release sequencing:** Project MCP policy and legacy-token migration (`T-411`) must gate externally reachable user-managed executor work (`T-408`) and full Copilot flow (`T-409`/`T-410`). Preserve per-project OFF as the server default, not merely a new frontend toggle.

## 20. Revision 1.4.6 — post-journey source/ownership reconciliation

**KB imported-source identity (A07/J-06, J-07, J-19, J-24).** `V45_knowledge_base_v2.sql` originally defined the global index, but `V72_integration_sync_pipeline.sql` already replaces it with the per-project/source-role uniqueness in pinned source. Before adding any further migration, inspect the actual deployed schema, existing sync upserts, duplicate-document behavior and actual source namespace/provider identities. For separately owned project copies, the likely key is `(project_id,source_provider,source_external_id)` (including provider account/source namespace where needed), with collision-safe dedupe and a migration for existing rows. If an intentionally shared canonical source is required, explicitly model its owner and per-project authorized references instead of granting access by matching hashes or identifiers. Test two projects using the same ticket key, distinct connector accounts with colliding IDs, import/update/deletion, isolation after revocation, and restoration of historical versions. Do **not** change the index blindly without checking conflicting existing records and importer lookups.

**Alternate entrances and consumers (J-23–J-27).** Reconcile the actual source owner and transactional guard for current UI/REST, MCP, legacy Zyra save, bulk/import, async sync jobs, bug-to-execution effects, outgoing notifications/webhooks, activity/Insights and report exports/shares. Only the authoritative operation is permitted to create/modify official QA truth. Consumers may project that truth with stable operation/event IDs and at-least-once-safe dedupe; a replayed webhook/sync/export cannot manufacture a new approval, report or official result. Import/export changes must preserve custom fields, version/snapshot semantics and project-bound identity. For public/shared links, document their independent intentional exposure policy and expiry rather than inferring ongoing private link revocation without a server check.

**Identity/evidence invariants (J-02, J-08, J-11, J-17, J-18).** Carry real human issuer, effective machine/client identity, agent instance, project and operation correlation into every mutation and derived event. Preserve signed original report/evidence references separate from model-authored summary and UI metric claims. Project-level OFF must affect both `/api/mcp` and project-qualified endpoints, cached discovery calls, evidence/media downloads and async follow-on effects; safe receipts already committed before revocation remain immutable. Reject unknown token scopes rather than defaulting to read/write.

**Implementation proof:** before claiming this technical design closed, run an independently derived journey inventory against the pinned source and these eight specs, compare only after the second review is frozen, adjudicate missing journeys and duplicate findings, then execute G2/G3 client/agent/database acceptance scenarios in a disposable environment. Source-only G0 and requirements-ID coverage do not constitute a runnable migration or product PASS.

## Revision 1.4.7 — reconciled technical change

Baseline: the same eight rev-1.4.6 files and pinned fork were reviewed in the completed Work second-pass (G0/G1 only). Read `00_README.md` for version/evidence and the standalone reconciliation audit for all IA-001–IA-040 dispositions. The content below records only this document’s assigned responsibilities; no live acceptance or source change is claimed.

### Code-informed reconciliation seams: preserve owners; fix mechanisms

| Existing owner/path | Disposition / required implementation invariant | Review evidence |
|---|---|---|
| `src/auth/auth.middleware.ts`, `api-token.service.ts`, `src/mcp/mcp.service.ts` and `legacy.controller.ts` | Propagate typed effective *machine* principal into every REST/MCP/domain writer; enforce project, current issuer membership, client, task, action and credential ceiling at the final authoritative write. Reject unknown scopes; delegated tokens cannot mint greater privileges. | IA-001/002/005; AS-01–03 |
| `src/plan-limits/project-write-lock.guard.ts`, MCP controller aliases | Read-only entitlement is checked per semantic operation and resource owner, never by POST alone or by project-ID path spelling. | IA-004 |
| `legacy.service.ts` plan items, suites, Bugs and projections | Validate child IDs and tenancy before link persistence and again for joined projections; do not assume parent grant authorizes foreign project child. No new QA record store. | IA-003/012 |
| `Tesbo-Frontend/lib/api.ts`, Zyra native chat and report pages | Safe methods may retry; mutation commands need stable client command ID and durable idempotency receipt. Key drafts/responses by thread and generation; scope exports and mark errors as errors, not empty data. | IA-006/007/013–018 |
| `src/rag/rag-ingestion.service.ts`, `rag-embedding.processor.ts` | Enqueue per source revision, fence stale generation, validate complete vector generation before swapping usable chunks, mark error instead of ready on invalid vector set; test Redis retained IDs and worker crash. | IA-008/009 |
| `src/integration-sync/` and KB files/storage | Count each unique ticket outcome once under quota/retry, preserve source attribution. V72 project-scoped external-source unique index is current baseline; archived mirror restore must return controlled conflict when replaced. KB file byte restore must not claim success for absent objects. | IA-010/011/020/026/032 |
| Existing Bug-to-execution and requirement coverage services | Clearly separate accepted result, Bug link and proposed status correction; include authorized `bug_links` only once in declared matrix scope. | IA-012/022 |
| Existing auth/signup/OTP/session cache/profile services | Platform-owner remediation for immutable signup OTP payload binding, atomic reset, stale cache revocation and validate-before-write profile PATCH; do not fork authentication into orchestration service. | IA-033–035/039/040 |
| Existing billing/Stripe webhook + entitlement owner | Platform-owner remediation for recoverable event claim, out-of-order event identity, concurrent checkout and active work entitlement transition; not an excuse for a new billing domain. | IA-027/036–038 |
| Existing analytics/Insights and external target instrumentation | Distinguish external delivery UNKNOWN versus accepted, risk scores with insufficient observations and target cleanup residual state; no report-only observation becomes official. | IA-029–031 |

**Migration erratum:** the earlier V45 global source identity warning is historical, not current DDL. V72 drops `idx_knowledge_documents_source` and rebuilds it on `(project_id, source_provider, source_external_id, source_role)` for live records. Verify actual migrated environment before proposing data repairs. For existing mirrors, test project isolation, replacement/restore and identity continuity—not a duplicate V72 DDL patch.

**Security and delivery gates:** no external ChatGPT/Claude/OpenCode connection before the first effective server-side per-project MCP consent gate, including T-402 and T-403. `T-411` is a dependency of both real-client tasks, with platform-principal hardening `T-415`. Generic API request retries cannot be substituted for idempotent task/apply/report receipts. Implementation follows the revision 1.4.8 BUG-EFFECT-01 direct/side-finding decision; only finalized-correction current-view presentation remains open.


## Revision 1.4.8 — finding provenance, execution truth and versioned QA playbooks

**Existing schema reuse:** V2 `testcases.steps` JSONB and `testcase_versions` plus V63 pre-update snapshot trigger give authored-definition history; V3 originally stored only `cycle_items.snapshot_title`; **V119 subsequently added `snapshot_*` full-field copies and a retrospective backfill**. Neither V119 backfill nor a snapshot-only row independently proves the approved, exact historical definition actually executed. V48 `bug_links` joins Bug, test case, cycle, execution, but has no `DIRECT`/`SIDE` relationship semantics, expected-condition references, or discovery-versus-affected context. Extend these owners; do not create duplicate Test Cases, Runs, Bugs or KB repositories.

**Minimal new semantic needed:** append-only `finding_observations` (or equivalently named existing-report/attempt subrecord) records observed occurrence before formal Bug approval, with scoped project, immutable report/attempt/evidence refs, step/condition ref, observed build, actor/agent/source, classification (`DIRECT` / `SIDE` / `UNDETERMINED`), classification revision/decision receipt and optional resulting Bug ID. It distinguishes **discovered-during** from **caused-failure-of** edges per observation, not per Bug globally. Retain current `bug_links` for accepted Bug/testcase/run projections, extending link-kind/provenance or mapping through the observation association, with referential and cross-project validation. Do not infer a Bug from every observation.

**Expectation and execution identity:** assign stable IDs to expected-condition assertions within the authored `steps` contract, including applicability and AND/conditional rules. Publish test-case versions with immutable exact definition hashes; store an approved full definition/version snapshot on execution assignment, not just the title. Store per-condition actual outcome, evidence, observation refs, and a separately versioned final disposition. A required condition failure fails its execution; incomplete/blocked remains distinguishable. Legacy rows with V119 migration-time reconstructed fields (and any truly title-only rows) retain an honest snapshot provenance/completeness flag and cannot be retrospectively asserted fully verified as executed.

**Corrections and remediation:** keep an immutable historical result event and permit a **new approved correction event** only when evidence demonstrates that *that same execution's* expectations were misclassified; mere new Bug or Bug link/unlink cannot mutate historical status. Existing `failLinkedExecutions` behavior is an explicit remediation target, not an approved shortcut. A side finding may support a new formal case result only when every needed setup/action/applicable expectation and observed build is attested; otherwise schedule actual first run. Retests are new attempt IDs linked by Bug, case version, fix/build and requirement coverage. Status and insights are derived from accepted attempt/correction policy, not from presence of Bug links.

**QA Standards & Playbooks service:** store one canonical `qa_guide` identity plus immutable revisions or reuse an existing versioned-config subsystem if source inspection proves equivalence. Each revision contains `scope {org/project, module, artifact/type}`, `kind {decision_policy, authoring_template, evidence_rule, example}`, machine-readable validated fields/conditions, markdown guidance, template variables, revision hash, author/reviewer, published/effective timestamps and supersession links. Resolve a deterministic *effective guide manifest* from mandatory global/org constraints and project defaults, with module-specific and explicitly permitted per-task style overrides; reject unauthorized conflicts. The Knowledge Base may link supporting rationale but must not be a second mutable source of operational policy.

**Cross-client contract:** native Copilot and remote MCP call the same authorized guide-resolution service; executors get only task-relevant guide excerpts; store guide revision/hash on task prompts, finding decisions, generated proposals and accepted results. Server validates mandatory expected-result/outcome, project scope, approval state and structured artifact fields regardless of model behavior. Guides, retrieved docs and examples are untrusted text (prompt-injection defense); never elevate their content to tool grants. Editing/removing guides follows project authorization, human review, audit and effective-version invalidation of pending proposals.

**Metrics and history:** reuse the current Test Cases, Runs, Bugs, Activity and Insights read models; publish canonical events for `observation_created`, `observation_classified`, `coverage_decision`, `case_revision_approved`, `attempt_result_accepted`, `result_correction_approved`, `bug_fixed_claimed`, `retest_observed` with provenance and event-time definitions. Avoid inflation by counting unique Bugs separately from unique observation occurrences; one Bug can have N incidental sightings and M direct failures.


## Revision 1.4.9 — correction journal, executable steps and typed relationship views

**Source-first extension:** V2 stores `testcases.steps` in JSONB, V63 snapshots pre-update test-case rows, V3 stores executions/cycle items (initially title-only snapshots), and V48 stores `bug_links` without causal labels. Preserve these owners. Before designing tables inspect later live migrations/code for equivalent stores and avoid duplicate storage.

**Correction and field history:** separate the immutable observed attempt result and its accepted revision/correction events from the *effective* status projection. Every correction event carries attempt/definition ID, previous and next effective values, changed conditions where applicable, evidence, reason, actor, reviewed proposal/revision, timestamp and optimistic-lock token; accept in either direction only under actual authorization and evidence checks. Derive ordinary field-level change previews/diffs from V63 snapshots and any subsequent existing audit, adding historical event persistence only for semantically consequential values with inadequate provenance. Do not mutate original evidence or use an independently mutable `previous_status` column as history.

**Actionable step contract:** each approved definition version contains stable `stepId`, `order`, `action`, dependencies/applicability, and zero or more `conditionId` + requiredness/condition expression + expected result. Each attempt stores action-progress events, condition-verification events, actual values/evidence/time/source, unknown/skipped/blocked distinctions and final accepted result. The UI is a derived task checklist with progressive expansion. Marking `performed` is not equivalent to `verified_pass`; textual imported legacy cases can be rendered in read-only compatibility mode until normalized through review. Freeze the complete approved definition snapshot and hash at assignment/execution.

**Typed edge registry as application-service/read model:** each relationship should carry source/target canonical IDs, `entity|version|attempt|condition|observation` grain, directed semantic kind, occurrence/event identity, effective/as-of time, provenance, confidence if inferred, and project visibility. Reuse existing foreign keys, case versions, Bug links, test-plan and activity/requirement evidence; introduce only missing typed association columns/records after Blue-style ownership archaeology. Do not replace source tables with a standalone graph database. Guard dangling, cross-project and mutable-latest substitutions. Support linked path traversal in existing screens and filtered analytics while preserving correct aggregate units.

## Revision 1.4.10 — executable reuse boundaries at pinned source
**Avoid duplicate frontend ownership.** The existing `testcases/page.tsx` right-side create/edit panel owns definition drafting and numbered `Step { action, expectedResult }` cards; `components/testcases/RepositoryTestCaseTable.tsx` owns repository column behavior. The execution lifecycle currently has **two existing readers**: `cycles/[cycleId]/page.tsx`'s `Drawer` and `cycles/[cycleId]/execute/[executionId]/page.tsx`. Reuse `components/ui` Button/Field/Input/Select/Textarea/StatusChip/Drawer, `LogBugDialog`, `ExecutionEvidencePanel`, badges, existing design tokens and module routes. Extract a shared component/hook for **rendering and updating execution action/condition observations** to avoid maintaining two diverging step renderers; backend canonical execution owner remains unchanged.

**Explicit source conflicts (baseline, not live reproductions):** `cycles/[cycleId]/page.tsx` near `onLogged` sets status `Failed` based on `failLinkedExecutions`; it gates linked Bugs behind `panelStatus === "Failed"`; full execute page likewise hides links unless `status === "Failed"`. Replace these with accepted DIRECT/SIDE/UNDETERMINED occurrence semantics and visible authorized Bug links independent of status, retaining existing dialog and relation storage. Existing `V63` snapshot trigger is definition-edit history only; result corrections need the planned immutable correction event on V3 execution attempts, not a reinterpretation of V63. V3 initially provided only `cycle_items.snapshot_title`, but **V119 already extends `cycle_items` with `snapshot_steps`, other Test Case fields and a retrospective backfill**; extend this owner with approved revision identity and provenance proof rather than duplicating its full-field snapshots.

**Change safety:** source has optimistic status writes (`handleStatusChange` and `handlePanelSave`) and request-ID guard for delayed Bug fetches in the Run drawer. Preserve their useful behavior while adding server-revision concurrency and rollback/reconciliation across both execution views; do not rely on status optimistic UI as historical proof. Existing `normalizeSteps` legacy fallbacks must be accepted through an explicit migration/compatibility adapter and never silently fabricate assertion verdicts. Shared execution-step state must not be attached only to React local state or only to a sidebar animation.

**Read/model parity:** Test Case lifecycle status counts in repository summary/table and execution statuses in Runs must be independently scoped; neither may be derived from the other. Reconcile aggregate and displayed row values against the authoritative source after mutations. No existing frontend branch, service, route or component is assumed to have changed in this specification-only revision.

## Revision 1.4.11 — shared execution UI extraction and migration boundary

**Existing route owners (pinned GitHub source):** `Tesbo-Frontend/app/(app)/projects/[id]/cycles/[cycleId]/page.tsx` (~1950–2164) and `cycles/[cycleId]/execute/[executionId]/page.tsx` (~196–385). Keep current shells; replace their respective read-only `normalizeSteps(...).map(...)` blocks with an extracted *proposed* `ExecutionStepReview` presenter consuming exactly the same execution+frozen-definition+per-condition contract. It is **not** a currently existing component. Pull shared API/service semantics from the existing execution owner, not from a second frontend cache/source-of-truth. Authoring `testcases/page.tsx` retains its existing independent definition Step cards, not execution checkmarks.

**Bug-dialog seam:** `Tesbo-Frontend/components/LogBugDialog.tsx` currently says “Test case marked as Failed” and treats association as a failing execution. `cycles/[cycleId]/page.tsx` `onLogged` forces `status:'Failed'`. Fix those callsites and authoritative `failLinkedExecutions` writer together for per-observation DIRECT/SIDE/UNDETERMINED semantics. A log/link response should return or cause fetch of the accepted *effective* execution status; no optimistic UI assumption based only on a Bug ID. Existing `bug_links`, `ExecutionEvidencePanel` and source-linked defect records remain the owners. Preserve the current delayed-Bug-response guard and require stable operation/attempt revisions to resist stale responses, ambiguous retries and cross-view races.

**Definition snapshot and events:** Verify all migrations newer than V3/V63 before schema changes. Bind attempt to immutable full approved definition revision/hash and stable step/condition IDs; persist performed action and each applicable condition verdict as separate idempotent events; surface them in both shells. Do not materialize separate drawer/full-page execution histories. The full page may expose more detail, but must not modify semantics. Result correction is an approved append-only event, not inferred from current Bug links. `QA-277`–`QA-279` cover the new narrowly scoped seams.


## Revision 1.4.12 — evidence levels for UI parity

Use the existing Next.js component tree, actual CSS/theme tokens and rendered DOM when verifying visual appearance. `testcases/page.tsx` code and user screenshots provide dual grounding for the Test Case screens. `cycles/[cycleId]/page.tsx` and `cycles/[cycleId]/execute/[executionId]/page.tsx` are **source inspected only**; screenshots at their actual runtime state are unavailable. A screenshot from an independent HTML reconstruction can demonstrate a proposed interaction but must **never** be used as proof of current UI or baseline pixel fidelity. Compare controlled authentic Before and native-app After captures, isolating intentionally changed regions while retaining all untouched components/behavior.

## Revision 1.4.13 — source-reconciled execution/attempt and snapshot contract

**Existing canonical tables:** V2 `testcases.steps` JSONB and `testcase_versions`, V63 `BEFORE UPDATE` old-row snapshot; V3 `cycles/cycle_items/executions` with unique execution-per-cycle-item, V78/V79 unique case-per-cycle; V119 **already stores** full-field `cycle_items.snapshot_*` plus older-row migration-time backfill; V84 automation latest-attempt-wins with `retry_count`; V140 adds `executions.step_results` and `executions.history` to preserve imported prior results; V48/V117 `bug_links` active uniqueness `(bug_id,testcase_id,cycle_id)`, omitting a per-observation or attempt discriminator; V60/62 audit and actor functionality. Validate actual deployed schema before migrations. Never resurrect superseded V3-only diagnoses or invent a second full snapshot/history store.

**Minimal semantic extension to existing owners (T-428/T-429):** one immutable logical execution-attempt/observation identity subordinate to the existing `executions` canonical result, with a separate reviewed correction-event chain and current effective projection. Each attempt's frozen definition is bound to the authoritative, approved revision/hash and existing `cycle_items.snapshot_*` data, with `capture_origin` / `capture_at` / `verified_as_executed` / `reconstruction_limit` and provenance; copy event data only where required to prove exact historical content and do not declare V119 migration-time backfills verified without contemporaneous evidence. Stable `stepId` and `conditionId` must survive edits within a version, and reorder/insert/removal must yield an explicit version-aware correspondence (do not infer semantic identity from array indexes). Use source-appropriate canonical JSON serialization/hashes, collision-safe project scoping and immutability constraints. Validated new attempts may reuse existing `executions`/report APIs through projections; choose the narrowest schema augmentation that satisfies history and concurrency rather than a parallel Run/Result product.

**Imported legacy mapping:** V140 `step_results[{position,status,comment}]` are position-based *per-result facts*, not evidence of per-condition IDs; `history[]` is the source tool's earlier results (with source fields), not a local human-reviewed status-correction log. Preserve raw imported content and provenance; explicitly mark unknown original definition, actor, timing or condition mapping, and never auto-assign an imported result as an approved subsequent Tesbo attempt. If legacy history contains enough trustworthy source identifiers, allow reviewed association with an auditable import mapping; unknown remains unknown. V63 pre-update snapshots alone are not guaranteed initial/current version receipts; an approved/version-pinned canonical definition must be established for future writes.

**Attempt-bound media/Bugs/metrics:** evidence currently attaches to `entity_type='execution', entity_id=executions.id`; legacy files remain there but must not be silently attached to all future attempts. Add typed attempt provenance for new evidence (back-compatible projection); preserve source byte ownership, deletion/retention and request idempotency. V117's soft-delete-aware bug_link identity can represent a current case/run association, not multiple semantic DIRECT/SIDE occurrences during different attempts: retain its existing consumers, link each new finding event to the exact attempt/step/condition, and emit only justified case/run projections. Reports/exports declare whether numerator/denominator uses latest effective results, all attempts, confirmed direct failures, distinct Bugs, or incidental discoveries; never double count corrections, retries or old imported events.

**Concurrency and parity:** UI/REST/MCP/backend jobs must use one authoritative write owner, request idempotency and expected server revision for action/condition writes, corrections, Bug association and attempt finalization. A lost 2xx response must read the server's operation receipt rather than optimistically resetting a newer result. Reject reused operation key with changed body, stale definition, old grant or cross-project linked child; preserve performed-but-unverified state, attachments and exact actor/source. Both current execution surfaces display the same confirmed revision after writes; no fabricated visual parity claim without the actual app render. Tests QA-280–QA-301.

**Historical cleanup and recoverable UI errors:** V78 includes removal of duplicate `cycle_items` before enforcing the unique key, with cascading execution effects. Whether production had more than one substantive result is UNKNOWN; a release migration review must preserve/describe legacy history and not retroactively assert erased attempts never occurred. The existing full execution page `handleSave` has a `finally` but no visible error recovery path for a failed `updateExecution`; it must preserve entered status/actual when write fails. QA-300 and QA-301 distinguish these conditional and code-supported cases.

## Revision 1.4.14 — source-grounded cross-system integrity owners

### Enforcement at the canonical writer, not the URL pattern

Observed at pinned SHA: `src/app.module.ts` installs `ProjectWriteLockGuard` as `APP_GUARD`; `src/plan-limits/project-write-lock.guard.ts` returns true for a write whose path does not match `^/api/projects/<UUID>`; `src/legacy/legacy.controller.ts` exposes PATCH `/api/cycles/:cycleId/executions/:executionId`, Bug links under `/api/bugs/:bugId/links`, and `src/mcp/mcp.controller.ts` supports POST `/api/mcp`. This establishes **guard-path incompleteness**, not by itself a proven entitlement bypass because full downstream checks have not been run. T-430 must establish a single transactional project-operation entitlement/authorization check or a verified exhaustive mapping of all mutation owners; never inspect arbitrary attacker-supplied project IDs as authority. Recheck policy after grant change/queue delay and at actual protected commit. Retain explicit archive escape and legitimate read access.

### Protected audit and event ownership

`src/audit/audit.service.ts` currently catches database INSERT errors and logs a warning. V62's append-only enforcement covers rows that were inserted but cannot prove they were committed for an official decision; operational configuration of `tesbo_app` is not verified. For critical selected publication, corrections, accepted dispositions and guide changes, commit event + domain state atomically or use a durable transactionally enqueued outbox that blocks `published` until provenance is guaranteed. Attribute actual principal/credential/task/revision. Do not repurpose best-effort analytics or notifications as a regulatory-grade event stream.

### Preserve existing Bug links while adding occurrence grain

V48 defines `(bug_id,testcase_id,cycle_id)` uniqueness and V117 recreates it as a partial unique index on active rows after soft delete. Both are correct for existing case/run association and are **not** sufficient to record the same Bug's multiple independent finding occurrences within one case/run. T-432 must reuse `bug_links` as a compatible projection but introduce an append-only typed observation/attempt/step/condition relation with its own idempotency identity. Distinguish `discovered_during` from `caused_failure_of`. V119 existing field snapshots and V140 legacy imported history retain truthful provenance; no retrospective invented assertion IDs.

### Cross-module reuse and ingress contracts

The existing Knowledge Base `ChangeHistoryList`/`ChangeDiffModal`/hover trigger provide a precedent for compact contextual histories. Existing `ReviewBoard` analyzes duplicate Test Cases; native Zyra review UI stages AI drafts; they are **not** interchangeable with general exact-version proposal approval unless the authoritative review semantics are extended. Existing `AutomationService` is SDK result ingest; independent execution-agent claim/lease/report needs a distinct governed operation built over canonical Runs/evidence rather than assuming an SDK reporter can wake or drive an agent. `IntegrationSyncProcessor`, RAG worker, caching, project workspace roles, billing and storage remain their original owners.

### Deployment proof and non-claims

No full clone, compile, database migration replay, live G2 run, signed-in browser or authenticated MCP client has been executed in this pass. This is a pinned source/G1 review. Verify every actual deployment SHA, complete DDL graph, feature flags, background workers and selected-code service checks before describing a concern as a live exploit, resolved finding or architecture freeze.

**Route inventory caveat:** 313 source-inventoried HTTP routes / 176 mutating route declarations / 74 non-`/api/projects/...` mutations were counted in the separate frozen independent Work route matrix. Non-project routes are **not automatically project-scoped**; do not infer an entitlement bypass without resolving their real resource owner. Parent-owned Runs/Bugs/Plans/Suites and `/api/mcp` require a focused actual-principal/entitlement test; auth/workspace/billing have their own policies.

## Revision 1.4.15 — authoritative writer audit: causality, finalization and lineage

**DA-15-01 — ordered automation result writes (confirmed missing guard).** `sdk/playwright-reporter/src/index.ts` dispatches every `onTestEnd` through `inFlight` concurrently; `Tesbo-Backend-Nest/src/automation/automation.service.ts::recordResult()` executes an unconditional `UPDATE executions SET status=$3,retry_count=$6,...` keyed by Run/Test Case. The unique execution row prevents **duplicates** but does not enforce **causal last attempt**, so result retry 0 can arrive after retry 1 and overwrite the accepted retry 1. `retry_count` is set to the supplied value without a monotonic comparison. Never use last commit as evidence of latest logical attempt. Reuse V84/V140 and T-428's attempt events; make ordering check and idempotent receipt authoritative in the one domain service, including parallel shards, same logical attempt delivery, and corrected human edits. Older retries remain immutable history, not current result.

**DA-15-02 — close is not an immutable barrier (current contract gap).** `AutomationService::recordResult()` checks project/Run existence but does not gate `closed_at`; `closeRun()` checks `closed_at`, then reads counts and performs a separate unguarded `UPDATE cycles`; these operations are not one transaction or conditional state transition. A result may update after close or race count calculation. `sdk/playwright-reporter/src/index.ts::onEnd()` prints “run ... closed” regardless of `closed.ok`; `Promise.allSettled()` waits for submissions but does not establish all accepted. Retain Runs and SDK, add a transaction/lock or equivalent serializable state machine for result/close, explicit after-close policy and durable retry receipts. Use source outcomes and counters, not CLI text, as truth. Whether a manual reopened Run may accept a new attempt is a separate **authorized** transition, not a retrospective change to a finalized result.

**DA-15-03 — execution actor rewritten by metadata-only PATCH.** `LegacyService::updateExecution()` updates `executed_by=$7,updated_at=now()` regardless of whether `body.status` is supplied, while preserving `executed_at` when status is omitted. Assignee-only and note-only saves may therefore assign an old execution's performer to the editor. Modify the existing writer to separate observation performer, metadata editor and accepted correction reviewer, with append-only provenance. Do not reuse the imported `executions.history` array (V140) as if it were a correction log.

**DA-15-04 — nested parent mismatch.** REST controller `PATCH /api/cycles/:cycleId/executions/:executionId` invokes `legacy.updateExecution(executionId,req.userId,body)` without passing or binding the requested `cycleId`; the service resolves only the execution's true project. Thus a caller with access to both Runs may operate on an execution with the wrong URL parent, although cross-project impersonation remains separately guarded. Bind path parent and child in the same authoritative query/transaction; hidden IDs must not be treated as an alternate parent authority.

**DA-15-05 — relationship exists vs relationship makes sense.** `LegacyService::sanitizeBugLinks()` independently validates supplied Test Case, Run and execution IDs within a project but does not prove they belong to the same cycle item. `addBugLink()` checks Bug access but inserts caller-supplied Test Case/Run/execution IDs without the same sanitization, updates an existing link's execution ID and invokes `failLinkedExecutions()` based on the caller payload. `V48/V117` uniqueness is about association duplicates, not lineage correctness. Enforce exact chain and valid semantic type before insert/update, with a shared validator for create/edit/add/import/MCP; reject mismatched identities rather than silently producing semantically false partial links. A future attempt-level edge must bind the same source-version and assertion, preserving legacy projection.

**Reuse:** keep V3/V84/V119/V140/V48/V117, `AutomationService`, `LegacyService`, API controller, SDK client/reporter, existing Runs/Bugs/status/history UI and audit/outbox. No parallel execution or defect service. Key implementation proof: two reversed out-of-order result deliveries, close/result race, metadata-only actor stability, URL parent mismatch, same-project incoherent parent-child triples; no acceptance based on type checks or passing basic smoke tests alone.

## Revision 1.4.16 — pinned source evidence and narrow reuse seams

**SYNC-16-01 — premature completion from double count (confirmed source logic).** `integration-sync.processor.ts:557–564` reports a storage-limited ticket with `{processed:1,failed:1}`. `integration-sync.service.ts:298–314` increments both counters and closes when `processed_tickets + failed_tickets >= total_tickets`. A one-ticket failure can contribute 2 toward the threshold, closing while another ticket is pending. Define an invariant, e.g. `succeeded + failed + skipped_terminal = completed` where each ticket receipt is applied idempotently; use the same canonical Run and ticket worker and avoid rewriting past progress from cached counters. `recordTicketResult` updates a settled run without `status IN('queued','running')`, another lifecycle boundary to repair consistently.

**SYNC-16-02 — invalid-data all-skipped can appear succeeded (confirmed source logic).** `integration-sync.processor.ts:199–260` catches initial upsert errors into local `skipped` but does not call `recordTicketResult(...failed...)` for them. If `queued.length` is zero the coordinator calls `finishRun(runId,emptyNote)`, which in `integration-sync.service.ts:278–290` sets `succeeded` when `failed_tickets=0`. If every fetched ticket was invalid, the error note states that, but official status may be succeeded. Count skipped before terminal status; maintain retry cursor/attempt history without fabricating success.

**REV-16-01 — reclaimed worker lacks fencing (conditional concurrency risk supported by current SQL).** `review-board.service.ts:177–187` reclaims by resetting `status='running'` and `heartbeat_at`, but does not store a unique generation/owner. `heartbeat` only checks `status='running'` (`244–246`); `persist` transaction starts with `UPDATE ... WHERE id=$1 AND status='running'` (`259–269`). If worker A stalls, B reclaims, then A resumes before B finishes, A can satisfy that predicate and publish A's stale findings. Fence claim/heartbeat/persist/fail with a monotonically increasing claim version; do not replace Review Board or its fingerprint/decision tables. A stalled-worker two-process replay is required to confirm timing in deployment.

**REQ-16-01 — provider and history stale-response paths (confirmed UI code, conditional timing).** `requirements/page.tsx:358–423` commits list results unconditionally after asynchronous fetches; `484–509` writes `setSourceHistory` and patches `requirements:${projectId}` cache without verifying that `activeSource` is still selected; `609–620` fires new `refreshHistory(next)` on source switches without cancelling old promises. `428–451` converts failed linked-source lookups to empty sets, so a source error may look like zero linked test cases. Add source+generation guard or abort handles to the **existing page** and surface failed/stale distinct from empty.

**PLAN-16-01 — secondary fetch failure causes navigation (confirmed UI source).** `plans/[planId]/page.tsx:183–198` awaits `Promise.all([getPlan,listPlanRuns,getPlanProgress,listPlans])` and on any rejection calls `router.replace('/projects')`. A temporary progress/list error can eject the user from a valid Plan. A separate result aggregator already derives progress from visible Runs; preserve its reuse but decouple nonessential reads and recoverable network errors from missing/denied Plan routing. Existing `handleCreateCycle`/`handleAssociate` rely on finally without UI error fallback, requiring covered draft preservation.

**Implementation boundary:** existing IntegrationSyncService/Processor, ReviewBoardService, RequirementsPage and Plan detail remain the canonical owners. Improve disjoint outcome identity, claim fences and request generations; no second queue, Plan reader, Requirements database or newly drawn design system.


**SYNC-16-03 — partial-result cursor may skip failed source revisions (conditional source-backed loss-of-coverage scenario).** `integration-sync.service.ts:514–531` computes `getLastSuccessfulRunStart` from `status IN ('succeeded','partial') AND truncated=false`, returning `MAX(COALESCE(window_start, started_at))`; `integration-sync.processor.ts:555–564` records storage-capacity failure as processed/failed, and finalizes partial. If an unchanged upstream revision was not mirrored during a partial run, the next *nightly incremental fetch* since that run's start may omit it. This is separate from counter double-counting. Extend the existing cursor and mirrored-ticket reconciliation so terminal success/failed-to-mirror obligations are tracked by source ID and version; a manual full sync may recover but cannot be assumed for correct unattended operation.

**PLAN-16-02 — Plan reference integrity not proven by V3 FKs (confirmed current source/DDL gap, downstream constraints require deployed DDL review).** `legacy.service.ts:6260–6267` `addPlanItem()` only calls `requirePlanAccess` before inserting `body.suiteId` and `body.testcaseId`. `legacy.service.ts:6393–6412` `createCycle()` takes the project ID and `body.planId` independently. V3 `plan_items` separately references `plans`, `suites`, and `testcases` by their IDs, and `cycles` separately references `projects` and `plans`, without a composite same-project foreign key. Validate same-project and compatible parent/child identity at canonical service writes, and preserve the existing Plan editor/Run workflow and migrations with a forward-only integrity gate. Prior generic cross-project child-reference findings are corroborated, not newly counted as independent platform features.

## Additional authoritative write-boundary findings, reconciled

**ZSR-16-01 Suite-before-transaction:** `124f1280afd7ee0e400755796ac46ba9f956b05f` `legacy.service.ts:19477–19514` invokes Suite creation before the Zyra Save transaction; retries/invalid selections can orphan Suites. Reuse current Suite creation but enlist it under the task row lock, validation, and case-save transaction with operation idempotency. See FR-093/AC-055/T-437.

**ZSR-16-02 Unscoped final project write:** `legacy.service.ts:19566–19581` validates staged update/archive target existence without project identity; `:24806–24829` patches by target ID without a project predicate. Actual untrusted-client staging reachability remains unproven, so treat exploitation as UNVERIFIED. Require current project ID in both lock/read and final UPDATE, with no partial mixed batch. See FR-094/AC-056/T-437.

**KBD-16-01 JSON change omission:** `legacy.service.ts:11082–11220` can persist new contentJson without triggering semantic `contentChanged` when title/html/text did not change. Ensure the canonical normalized JSON representation participates in history, approval review and embedding change rules. See FR-095/AC-057/T-438.

**KBD-16-02 Lost update across advisory lock:** `legacy.service.ts:11153–11175` briefly locks history insertion, but final document write at `:11206–11212` occurs outside the same revision transition. Protect the full before/read/write and restore sequence with a document row lock and revision precondition (or equivalent). See FR-096/AC-058/T-438.

**PLN-16-03 Projection and lifecycle completion:** `legacy.service.ts:6228–6257` reads joined Suite/Test Case labels without same-project filters and `:6280–6294` reads Runs by Plan ID without ensuring the Run project's equality. Extend the already described PLAN-16-02 service/DDL validation to read projections and soft-deleted relations, not just creates; inspect all alternate MCP/API callers. See FR-085/090/AC-054.

**SYNC-16-04 Terminal write guards:** `integration-sync.service.ts:193–216,278–315` permits late updates to settled runs and coordinator `markRunning` can resurrect one. This is an elaboration of existing FR-091, AC-049, QA-348 and T-435, not a second synchronization requirement. Validate through DB/queue race fixtures.

Pinned source link: https://github.com/1alextest/Tesbooboo/tree/124f1280afd7ee0e400755796ac46ba9f956b05f. G1 source inspection; G2 application/DB/browser execution has NOT RUN.

## Revision 1.4.17 — additional authoritative source traces and validation boundaries

**AUTH-17-01 — read-scoped bearer can reach normal REST mutation (confirmed code path; deployment reproduction NOT RUN).** `auth/auth.middleware.ts:18–41` authenticates a machine token then maps `principal.userId` onto `req.userId`, independently of `principal.scopes`. `auth/api-token.service.ts:132–151` returns the token scope but does not enforce it. `mcp/mcp.service.ts:187–195` enforces scopes **only for MCP tools**. `legacy/legacy.controller.ts:538–540,567–574,595–607` exposes Test Case create/update/bulk HTTP routes using `req.userId`, with no presented-token-scope guard. The route remains subject to the human's project membership/role but the machine token's read-only restriction is not honored. Patch shared authentication/authorization at current entry and final-write owners, including alternative REST paths, not only MCP. `api-token.service.ts:59–74` further normalizes wholly invalid/empty scope input to `read,write` by default; decide fail-closed semantics explicitly.

**SHARE-17-01 — public Run row excessively broad and revoked token reused (confirmed code shape).** `legacy/legacy.controller.ts:905–912` exposes unauthenticated shared-run detail and executions. `legacy/legacy.service.ts:6472–6480` returns `toCamel` of `SELECT * FROM cycles`, including internal columns added in V3/V10; `legacy.service.ts:6495–6515` already uses a narrow projection for public executions. `Tesbo-Frontend/app/share/[token]/page.tsx:240–252` only needs name/description/status/environment/build/visible dates. `legacy.service.ts:6453–6469` sets the same saved `share_token` when a link is re-enabled. Use a hard-coded DTO allowlist and deliberate share-authorization/rotation contract; no new public route or page.

**RECOVERY-17-01 — reset-token double consume and partial success (confirmed non-atomic sequence).** `auth/password-reset.service.ts:48–63` first reads usable token, then calls `password.setPassword` (its own UPDATE), then sets `used_at` unconditionally, deletes sessions, invalidates session cache, and clears lockout. `findValidToken` (`69–76`) uses an ordinary SELECT (no lock/claim or update-where-unused), so racing reset calls can both pass validation and update a password. `migrations/V80_password_reset_tokens.sql` has token hash uniqueness but no consume-once transition. Use current `DatabaseService.transaction` with row claim and consumed-row count, persistent session revocation, post-commit cache invalidation recovery/outbox as needed; use existing AuthController routes.

**META-17-01 — invalid replacement tags erase valid current assignments (confirmed).** `custom-tags/custom-tags.service.ts:152–170` filters submitted tags to valid UUIDs and project-owned tags, but when none survive it performs unqualified `DELETE FROM testcase_custom_tags WHERE testcase_id=$1`. `legacy.service.ts:5749–5750` invokes this for any defined `body.customTagIds`. A stale or foreign-only nonempty selection therefore clears existing project tags in a successful testcase update. Reject invalid/non-owned references before mutation and distinguish intentional `[]` from an invalid nonempty request, preserving the existing transaction.

**META-17-02 — restore/rename collision (confirmed database constraint; resulting HTTP mapping not proved).** `custom-fields/custom-fields.service.ts:140–155` allows replacement creation when the old field is soft-deleted, `restoreDefinition` at `423–452` updates `deleted_at=NULL` without handling name collision, and `migrations/V99_custom_field_definitions_soft_delete.sql` defines unique active non-archived `(project_id,lower(name))` when undeleted. A reused active name makes Undo's UPDATE fail with SQL 23505; turn this into a controlled conflict response without dropping the old values or swallowing database errors. `CustomFieldDefinitionList.tsx:143–155` already has an Undo error presentation.

**REPORT-17-01 — claim lease and external posting not one idempotent completion (source-backed retry window).** `analytics-report/analytics-report.service.ts:25–47` posts to Basecamp before recording `posted_at`/`basecamp_answer_id`. `claim()` at `77–87` can be reclaimed after a 15-minute lease; `release()` at `89–98` is not claim-generation scoped. If the external post succeeds but the DB update fails, the catch releases its claim and a retry can create a duplicate; expired worker A can also post after worker B obtains the claim. Reuse existing scheduler, report run row and Basecamp client with fenced claims and provider-side correlation/find/reconcile. Treat exactly-once external posting as an acceptance property requiring provider-capability verification; a DB transaction alone cannot make HTTP+SQL atomic.

**Evidence limitations:** static source behavior at pinned commit 124f1280afd7ee0e400755796ac46ba9f956b05f. Source-supported race/authorization failure paths do not establish a live deployment exploit. Read the latest deployment migrations/config and execute API concurrency, authorization, worker fault and UI tests before accepting changes. Existing wider scope (integration workers, Plan/Run/SDK, Zyra/KB, billing webhooks, migration drift, RAG) remains on the assurance ledger; this revision does not certify untouched routes.

## Revision 1.4.18 — extend existing session and review owners for product distillation

**Reuse audit before schema changes:** inspect the implementation branch, not only the historical pinned source. Start with existing QA-session/thread associations and ordered events, automation recordings/events where applicable, KB document versions/history, Requirements, task/attempt receipts, attachments, staged ai_generation_requests/proposal revisions, human review/apply, BullMQ and Activity. Map KEEP/EXTEND/EXTRACT and actual semantic gaps in the implementation task. A similar field name is not proof of equivalent semantics. No parallel session, evidence, specification, approval or job store is authorized by this section.

**Logical associations, not prescribed new tables:** an observation references a source version/range and evidence type; a canonical product candidate aggregates authorized observations and versioned dispositions; a distillation checkpoint records requested/processed/excluded/unavailable source revisions and resource usage; an amendment references candidate revision, source manifest, target canonical document base revision and exact patch hash; implementation and validation are linked existing task/PR/report records. Store only the minimum new associations absent from current owners.

**State separation:** immutable original evidence and capture receipts; versioned derived observations/candidates; separately governed amendment decisions; independent publication, implementation and validation receipts. Candidate acceptance does not imply any downstream state. Principle/Guide promotion continues through FR-076–077, not product-proposal status. Superseded/corrected interpretations cannot rewrite original events.

**Concurrency/retry:** use a project/source revision/range plus client observation key for exact ingest idempotency; retain independently sourced evidence even when bytes match. Semantic dedup is advisory unless a reviewed merge is authorized. Use existing compare-and-swap/transaction patterns for candidate edits and exact multi-document selected apply. All selected amendments must apply atomically where supported; otherwise fail before publication or explicitly stage an uncommitted batch. Never report complete apply for a partially published batch. Append durable audit/outbox receipts with the authoritative mutation.

**Source security:** distinguish source readability from permission to share/promote it to a product project. Enforce source and destination ACLs, private-thread visibility, redaction classification, tenant boundaries and live grants on every read/write/finalize. Do not deduplicate across scopes in a way that leaks existence. Treat source instructions, screenshots, summaries and candidate text as untrusted data. Denial/revocation must not create hidden target records, exposure URLs or official state changes.

**Execution:** reuse configured workers/adapters and existing job controls for optional automatic checkpoints. No always-on surveillance of external sessions, new inference purchase or model training is implied. Persist source coverage/checkpoints; use explicit time/token/item budgets, cancellation and retry without duplicating publication. Inference unavailability is a blocked draft operation, not loss of evidence. A client may submit proposals without Tesbo-native inference.

**Closure:** require current-source verification and workflow-level validation against the originating problem. Hold-out examples/counterexamples may assess proposal quality, but model agreement is not evidence of actual product behavior. Artifact-registry storage changes remain subject to PD-01 investigation and the existing execution/evidence work.

## Revision 1.4.19 — extend T-422 for one platform default pack and workspace pin (design, not code)

### Ownership and reuse decision

The canonical platform skill/QA guide owner is the **existing planned T-422 QA Standards & Playbooks resolver**, and the canonical project content owner remains V45 Knowledge Base documents+versions. Do not confuse a project-scoped mutable `knowledge_documents` with a platform-wide immutable pack: V45 requires `organization_id` and `project_id`, so a global pack must be stored as a platform-approved published guide revision or equivalent approved shared representation, **not** a fake project/organization with copied project docs. One core pack is an immutable manifest of section IDs, referenced templates, source digests and published revision. Workspace installs are *references*; project contexts are separate versioned overlays. A new model is justified only where existing typed qa_guide/KB owners cannot express the platform revision and one per-workspace pin safely.

**Anchors checked in current source:** `Tesbo-Backend-Nest/src/legacy/legacy.controller.ts` invokes `createWorkspace` for both `/api/onboarding/workspace` and `/api/workspaces`, `createOrgAndProject` for combined onboarding, and `createProject` separately. `src/setup/setup.service.ts` creates first admin/organization and optionally a demo project inside a transaction; `src/legacy/multi-workspace.spec.ts` covers workspace creation slug handling. `migrations/V1_init_schema.sql` has organization identity and project ownership, and V45/V94/V102 cover project KB history. `src/mcp/mcp.tools.ts` has current read/list Knowledge Base tools; `mcp.service.ts` has `tools/list`, `tools/call` but no generic `resources/list/read` implementation. The actual multi-route writer inside very large `legacy.service.ts`, transactional boundary and all edge-case administrative creation paths **must** be verified directly before coding; names alone are not proof of complete coverage.

### Minimal data and state contract (proposal, not prescribed tables)

- PlatformPack: stable globally governed ID, active approved revision reference, historical revisions, canonical ordered section manifest, source hashes, classifier/version, publication receipt, reviewer and effective date. Use existing T-422 QA-guide revision/publishing infrastructure once built; no independent Skills DB if it fits.
- WorkspacePackBinding: one logical `(organizationId, packId)` unique installed reference with pinned revision, installedBy/effectiveAt, explicit adoption source, and optional reviewed upgrade history. Prefer an existing organization settings/config association if it provides proper immutable FKs, CAS and audit; **otherwise** one small binding table with FK and uniqueness is justified. Never store full duplicate core content for each workspace.
- ProjectMethodBinding: project-owned optional overrides, source-revision and applicability metadata pointing at existing project Knowledge Base/authoring profile and core pack. Do not copy Nesberry roles or content into platform defaults.
- EffectiveMethodManifest (derived projection): `{schemaVersion, platformPackId, platformRevisionId/hash, workspaceBindingRevision, projectId, applicableSectionIds, scope/precedence, sourceRefs+hashes, denied/missing/unknown, asOf, provenance}`; deterministic, authorization-filtered, immutable when pinned to a run/proposal. The resolver is one service consumed by REST/native Copilot and project MCP; never an independent published record authority.
- HistoricalArtifactProvenance: source requirements/skill/case revisions, exact generating method manifest hash, observed vs authored/derived classification, reviewer/auto-policy receipt and previous attempts, stored through existing domain owners. Pack upgrades do not rewrite old artifacts.

### Proposed v1 core section index (design candidate, NOT published)

One coherent core skill with small references/templates; stable section IDs permit the current project-MCP adapter to retrieve only what a task needs. This manifest is **draft content**, not an already installed platform pack or signed-off policy:

```json
{
  "packId": "tesbo.default-product-testing",
  "schemaVersion": 1,
  "proposedPublishedRevision": "1",
  "status": "DRAFT_UNAPPROVED",
  "sections": [
    {"id": "core.project-discovery", "covers": ["primary-user-type", "module", "context", "sources", "applicability"]},
    {"id": "core.user-story-authoring", "covers": ["goal", "benefit", "source/version", "acceptance", "draft-vs-approved"]},
    {"id": "core.risk-based-test-design", "covers": ["positive", "negative", "boundary", "coverage", "exclusions"]},
    {"id": "core.regression-and-exploration", "covers": ["approved baselines", "fresh-eyes", "distinct scope and memory"]},
    {"id": "core.execution-and-evidence", "covers": ["permission manifest", "attempt", "actual outcome", "tool failures"]},
    {"id": "core.reporting-and-learning", "covers": ["observations", "review", "versioned records", "feedback"]},
    {"id": "core.evaluation", "covers": ["ordinal dimensions", "non-compensating gates", "held-out tests"]}
  ]
}
```

*Content approval requires source provenance and owner review.* A project adapter may bind exact approved local source references, modules and actors; it cannot replace the generic pack or bypass the applicable platform safety conditions. Section IDs should be durable across a pack revision; removal/deprecation requires an explicit upgrade compatibility decision, not a silently broken agent link. Hash should cover exact approved content bytes and ordered section identities. The manifest is **not** a claim that `qa_guide` revision 1 or a global storage table currently exists.

### Single creation and read path

New-workspace creation validates the currently published default pack (fail closed if absent), creates workspace and installs/reconciles its pinned reference **within one authoritative creation transaction** where possible; bootstrap/demo and other creation routes use the same helper, not duplicate seed functions. Provide a unique `(workspace, pack)` constraint and idempotency key handling; concurrent retry returning an existing workspace must not create a second binding. Workspace identity created but pack installation failing is rolled back, or must be visibly unreconciled with durable recovery if an existing legacy transaction cannot be extended safely. No project, external MCP enablement, AI key or target run is required. Existing workspace adoption is a separate reviewed operation, never an implicit backfill.

On project read, load the selected workspace's pinned pack revision, then authorized project/module overlay. Precedence: platform/org mandatory safety > platform default method > approved workspace preferences > permitted project module-specific authoring style > task hints; reject conflicts that attempt to narrow higher-priority controls. A project-wide role requirement is derived from its own source; missing users/modules are UNKNOWN, not automatically inferred from the local model's environment. **Verify** the existing T-422 effective-guide resolver implementation before adding a second; if not yet built, implement as a T-422 slice.

### Security and integrity limits

- Project MCP OFF and explicit grants remain enforced before tool discovery/call, by project membership and credential/session capabilities; pack installed does **not** confer permissions. No debug/info leak for foreign package, workspace, private project rules or hidden drafts.
- A retrieved skill is instruction content, never policy authority. No arbitrary content-to-tool instructions, model-provided approval, cross-project embedding lookup or access to secret evidence. Use deterministic schema/oracle validators as needed, with user-specified product policy.
- Publication and upgrades human-reviewed by platform/workspace authority, under one guarded reviewed writer; no global agent self-approval. Optional automatic *asset publication* remains blocked under P-07/FR-033 until ratified separately.
- Signed session/manifest provenance for generated cases and stories; auth/tenancy checked at retrieval and on any subsequent write; invalidate caches on revocation, version switch or project transfer. Revalidate after pending long model calls.
- No content duplication, no separate microservice/worker/agent, no automatic test launch. Existing Redis/BullMQ may be used later if a measured dependency needs asynchronous handling. Agent improvements cannot silently publish new global core revisions or mark themselves effective.

### Alternative and future capability gates

**Native stories:** existing Requirements page is a linked Jira/Linear/Notion ticket reader; project KB `requirement_note` is not a tracked native requirement. Use source-backed draft in approved staging until an existing Requirement owner/API path is proved or minimally extended. A full requirements-system redesign is NOT a prerequisite to M1; users must not be misled.

**Candidate platform pack source:** Nesberry repository `SKILL.md`, `templates/session.md`, `references/user-journeys-and-personas.md` currently exist, but exact paths for `user-perspective-journeys.md`, `templates/user-story.md`, `templates/persona-agent.md`, `references/grading-and-improvement.md` were unavailable on inspected `main`. The generic default method is a proposed normalized distillation, not a claim of full imported pack or verified local uncommitted content. Keep Nesberry adapter strictly project-bound.

**Negative architecture proof:** reusable method can be published as T-422 `qa_guide` sections/references; org pin needs only one additional relation, and MCP needs one read-only index/section tool in its existing gateway. The nearest alternatives—per-project KB copies, another skills app, a new MCP server, a duplicate requirements table, dedicated worker or static prompts pasted into every agent—create independent mutable truth or bypass the specified lifecycle. Do not adopt without source-demonstrated need.

## Revision 1.4.20 — change-aware behavioral/evidence graph technical contract (PROPOSED, SOURCE-RECONCILED)

**Source pin:** `1alextest/Tesbooboo@development:5989e5e2c646666ed087a7885389b2ffce4bad42` on 13 November 2026. This section is additive to the canonical FR-081/T-426 typed directed relationship owner, T-421/T-428/T-429 result/history owners, T-304/T-305 protected staged publication, T-422 guide, T-452 per-asset version proposal, existing project MCP and V6/V109 notifications. No current graph tables or routes were found at this pin, and no production runtime/DB verified; names below are future **proposals**.

### 1. Concrete existing vs missing map (no ghost features)

| Concern | Current evidenced source | What is genuinely new or unresolved |
|---|---|---|
| Requirements | `Tesbo-Frontend/app/(app)/projects/[id]/requirements/page.tsx` reads linked Jira/Linear/Notion tickets; `src/integration-sync/integration-sync.processor.ts` stores provider tickets and mirrors read-only KB docs (V72); existing cases have Jira/Linear/Notion reference fields and V101 `source_refs`. | No confirmed standalone native requirement/AC approval/version owner. Store source identity/hash/approval evidence as a reference; native authoring approval is OPEN, not inferred from KB. |
| Native cases/versions | V2 `suites`, `testcases`, `testcase_versions`, `attachments`; V63 snapshot-before-update; V119 cycle-item field snapshots; T-429/FR-112 specifies more precise approved revisions. | Existing snapshots are not automatically verified approved-at-run identity. Add explicit pinned content hashes and make older backfill `RECONSTRUCTED/UNKNOWN`. No graph-owned case copies. |
| Plans/runs/results | V3 `plans`,`plan_items`,`cycles`,`cycle_items`,`executions`; V84 automation run metadata/commit/retry; V140 `step_results`/imported history; `src/automation/automation.service.ts::recordResult`. | Explicit immutable per-obligation assertion/attempt receipts, exact build/environment pins, unknown outcome/provenance and graph navigation; still ONE native execution projection. |
| Bugs/finding/evidence | V48 `bug_links`, V49 BetterBugs, existing generic attachments + `src/storage/storage.service.ts`; FR-087/T-428 proposed attempt-safe occurrence. | Separate immutable finding/assertion occurrence and evidence link to original attempt; reuse existing Bug/attachment writers, no duplicate repository or evidence blob. |
| MCP/agents | `src/mcp/{mcp.service,mcp.tools,mcp.controller}.ts`, project-scoped token scopes, `src/auth/api-token-rest.guard.ts`, existing Zyra review/`ai_generation_requests`. | A bounded set of proposed quality read/changeset/impact calls, no new MCP server, assistant or remote executor. |
| Notification/QA | V6 `notifications`, V109 `(user_id,dedupe_key)` index, `src/legacy/{notification-writer,notification-events}.ts`, `components/TopBar.tsx`. Writer logs and suppresses errors, returning a bare count; zero is ambiguous between duplicate/no eligible recipient and failed insert. Extend a single delivery adapter to return structured per-recipient outcomes or verify authoritative delivery state before acknowledging an outbox event; never treat the existing `0` as successful delivery. | Need authoritative *durable* QA impact and transactional outbox; bell is best-effort view and read != QA assessed. |
| Trust and runtime | `src/database/database.service.ts` transaction; `src/audit/audit.service.ts` and V62 append-only DB audit; `src/review-board/review-board.service.ts` and V141/V143 fingerprints; `src/integration-sync/` BullMQ; SQL V1–V144/`scripts/check-migrations.mjs`; e2e/api+ui selected tests. | Source-reconciled change events, protected revision publication, fail-closed project-safe directed traversal, revocation and actual conformance proof; do not claim the existing Review Board is a general model-approval queue. |

**Historical reconciliation:** `docs/reviews/governed-asset-evolution-reconciliation.md` is a noncanonical proposal from earlier asset-version work, NOT a ninth spec or implemented migration. Retain its compatible independent-asset/version decisions; new source observations and QA impacts are lifecycle entities, not another published testcase/requirement version stream.

### 2. Logical model and canonical ownership (first combined slice)

Use one `QualityImpactModule` (name tentative) in the current NestJS monolith, backed by native PostgreSQL transactions and existing auth/audit/services. Two **logical** graphs share the same typed link owner; a user diagram does not own another copy of facts.

| Proposed persistent relation | Fields and integrity intent | Canonical owner / publication |
|---|---|---|
| `quality_journey_families` | UUID, `project_id`, stable `family_key`, business job/context, immutable declared scope, one active/current-published revision FK/NULL plus CAS token; unique `(project_id,family_key)` | Single FR-117 expected-behavior/model owner (C-12); modelId aliases this family ID. A family may have no approved/active revision; no parallel model record. |
| `quality_journey_revisions` | UUID, family/project, immutable ordinal/hash, `model_json` schema-versioned JSONB (states, transition IDs, actor/context applicability, action/event/timeout, guards, required/forbidden effects, invariants, bounded loops/handoffs, observations), source/AC refs, base revision/hash, reviewed status/actor/time; no in-place change of published data | Shared protected review T-304/T-305 approves/publishes exact immutable revision bytes; activation is a separate family-owned CAS under C-02/C-12 and approval never switches the active pointer. modelRevisionId aliases this same revision ID; agent proposals are not approved truth. |
| `quality_source_refs` | UUID, `project_id`, source owner `(provider,type,external_id,revision/hash)`, accepted AC locator, frozen relevant excerpt/digest or explicit unavailable state, `approval_authority/ref/status` | Reference only to authoritative native/external Requirements; not a new writable Requirements or KB mirror. |
| `quality_change_sets` | UUID, `project_id`, registered repository ID, origin `prepared|unplanned`, branch, base/head SHA or provisional worktree digest, source attestation state, parent/merge lineage, last event sequence, optimistic version, idempotency key, created/reconciled timestamps | Coding change metadata (neither implementation proof nor approval of behavior). Branch-specific claims never conflate with merged/deployed build. |
| `quality_change_events` | UUID, changeset, monotonically increasing sequence, event ID/unique source key + canonical payload hash, exact changed path/symbol/route/dependency/test IDs, source path/content hash, `agent_reported|source_verified|inferred|unknown` tier, observed time, omissions/known limits; append-only | Exact attributed incremental observations. Correction is a later event, not update/delete of original. |
| `quality_trace_edges` | UUID, `project_id`, relation `kind`, subject type/ID/revision, object type/ID/revision (native FK when possible), occurrence/validity interval, provenance/evidence tier, created-by/source change; typed allowed-kind registry and cycle/depth boundaries | Extend FR-081/T-426 **one** graph relationship owner, not a graph-specific case/bug/requirement clone. Same directed edges serve behavior and evidence read views. |
| `quality_impact_items` | UUID, project/change/event, affected family/obligation and native case IDs (or explicit unknown), independent source coverage flags, assignee/status, owner decisions, `revision` for compare-and-swap, risk/scope/unknown summary, closure evidence | Durable QA work obligation; assessment is not notification-read state, case status or a Bug itself. |
| `quality_assertion_receipts` | UUID, project, native execution ID, stable logical attempt + assertion/obligation key, immutable case/model/AC/adapter/build pins, expected/actual (redacted), verdict/evidence tier/actor/timestamp, existing attachment IDs with hashes or MISSING; uniqueness for exact `(execution,attempt,assertion,idempotency)` | Actual independent observed assertion only; **never** auto-created as PASS by typing an edge or synthesizing expected source. Corresponding native execution remains one source-of-truth result projection. |
| `quality_outbox_events` | UUID, project, impact/change identity, event kind, recipient policy, delivery attempts/next retry/error, deterministic event key; transactional persisted event | Drives existing `notification-writer.ts` and TopBar. Outbox failure cannot erase QA impact. |

V145 is **tentative**: select the first unused ordered migration number at implementation time after checking latest `development`; use additive FK/index/checks and a migration replay in an authorized isolated DB. No migration is executed during this document revision.

**Type safety:** avoid unsafe free-form `(entity_type, entity_id)` edges. For native bindings use validated relation variants with concrete FKs/composite `(project_id,id)` checks or equivalent database-enforced same-project existence, under the same transaction. Internal behavior element IDs are stable inside an immutable revision and validate against its frozen `model_json`. Do not concatenate untrusted type names into SQL. Cross-project edges cannot be hidden as dangling metadata. Soft-delete and archive make historical edges visible as historical/unavailable, not silently reattached.

**Behavioral validity:** states are conditions of the business/process, not all screens; transition input includes starting prerequisites/data, actor/context and policy; support a successful path, a valid alternative, an explicit refusal, bounded retry or interruption/re-entry, and handoff/downstream effects. Graph path generation is *planning*, not a complete executable test without concrete fixtures, independent assertions, environment adapter and cleanup. Support API/unit/contract/integration/browser adapters at appropriate layers; no forced browser-only execution. Reject imported arbitrary code and unbounded traversal/loop predicates.

### 3. Source reconciliation and two-way agent contract

**Step A — provisional incremental capture:** REST/MCP accepts exact project, registered repo, branch/base/head or worktree snapshot, event id/hash, changed file/path/symbol/route, proposed behavior diff and uncertain dependencies. A new unplanned change with no known requirement/graph/case is valid and creates `UNKNOWN` obligation(s). `GetContext` returns only authorized relevant approved source/method/legacy case information with explicit coverage and staleness; clients may perform targeted source inspection as required.

**Step B — independent source attestation:** A separately authenticated, read-only source-diff/CI attestor computes exact base→head SHA changed paths, route map and accessible dependency neighborhood with its own source digest and tool version. The agent cannot submit the trusted attestation by labeling its own JSON `verified`. Compare the attested changed set and reported set; extra files/routes become missing-submission impacts. Dynamic consumers, unavailable history, dirty worktrees or uninspected modules remain `PARTIAL/UNEXAMINED` until checked. A malicious implementation/source prompt is DATA, not instructions to the verifier. Source attestation proves changed bytes, not intended business correctness.

**Step C — transactional impact acceptance:** Under current project membership/write-lock checks and a row lock for the changeset, validate expected sequence/version and exact idempotency key/hash; insert immutable event, any newly required impact obligations and outbox entry in one DB transaction. Retry same key+hash returns the existing event/impact IDs; same key+different hash fails 409. A nonfatal bell-delivery failure is retried out-of-transaction. **Do not use the existing `writeNotifications()` integer return as a delivery receipt:** it intentionally catches errors and can return zero for duplicate/ineligible/failure. Adapt the shared notification writer or its owner-bound caller to distinguish `DELIVERED`, `ALREADY_PRESENT`, `INELIGIBLE_RECIPIENT`, and `RETRYABLE_FAILURE`; persist delivery status and retry the last category. Never mark an outbox message delivered merely after catching an exception or receiving a zero count. Overlapping agents or branch merges must not flatten two distinct commits into one change. Changesets support planned/unplanned origins using the same service.

**Step D — protected expectation publication:** A proposed behavior delta is evaluated against source-backed approved requirement/AC revisions and current protected publication policy (P-07/FR-033/FR-113, T-304/T-305). Approver's exact base revision/hash plus current policy must match at commit. When no requirement authority exists, model expected outcome is `EXPECTATION_UNKNOWN`, QA impact `BLOCKED` or provisional per an explicitly ratified owner policy; do not create fake AC or publish an agent assertion.

**Step E — real QA result:** QA selects native cases, stages changes via existing review, and records real `cycles`/`executions` through established API/automation. The new assertion receipt is appended only upon true authorized execution/observation with verifiable actual/expected outcome and artifact provenance; a run-status label is not a per-obligation PASS. Native `executions` remains the effective result projection and already uses retry count; all prior failed attempts and attachments persist in immutable receipts, never overwritten by passing retries. Missing evidence, unknown build or no independent oracle yield `UNVERIFIED/MISSING_EVIDENCE`, not PASS.

### 4. Version, history, consistency and security invariants

- **Identity:** stable UUIDs plus optional scoped display IDs; never use string titles or route labels as identifiers. Pin `(project,registered_repo,base_sha,head_sha,branch/merge_lineage)` and separately `(AC_version,behavior_revision,case_hash,adapter_version,run/execution,attempt_id,build_digest,environment)`. An uncommitted event with no head SHA is provisional. `development`, PR, build, and deployed artifact are distinct identities.
- **Approval and concurrency:** compare-and-swap by expected revision/hash and row locks; 409/412 on stale, missing or changed dependencies. Agent may post source observations but cannot self-publish an approved expectation/test/graph. Historical revisions never overwritten, including rollback via a new reviewed revision.
- **Read/traversal:** authorize caller and same-project binding for each node and hop at query time; no unauthorized counts, adjacency lists, search previews, exports, outbox alerts, source excerpt or evidence metadata. Bounded max depth and fanout; deny arbitrary target IDs/graph categories, redact secrets and PII in evidence and logs. Revocation invalidates cached graph/handoff access. Shared default QA method and project context do not grant target execution authority.
- **Error surfaces:** differentiate `PARTIAL_SOURCE`, `MISSING_REQUIREMENT`, `CONFLICTED_EXPECTATION`, `MODEL_STALE`, `CASE_STALE`, `BUILD_UNKNOWN`, `EVIDENCE_UNAVAILABLE`, `NO_CASE`, `NOT_ATTEMPTED`, `NOT_ADJUDICATED`, `UNSUPPORTED_ADAPTER`. Absence is not pass. Reject out-of-scope imported documents and unsafe source paths/URIs.
- **Notifications:** Current V6/V109 + `notification-writer.ts` is delivery/presentation only; a committed outbox row is authoritative for retry. A user's notification read flag does not close the project impact. Recipient membership rechecked at delivery and click time; no silent reassign to a user no longer authorized.
- **Audit:** Protected publication and actual assertion/impact decision require success of mandatory append-only provenance in same transaction or a recoverable pending/outbox marker. Existing best-effort activity logger is not sufficient as sole proof. No arbitrary code execution from graph data, and no production migration/action from this spec.

### 5. Storage architecture and UI boundary

| Architecture | Queries and consistency | Cost, security and migration | Decision |
|---|---|---|---|
| **A: Extend existing PostgreSQL + JSONB revisions + typed relations** | Project-scoped 1–4 hop impact walks and exact version joins, foreign/project constraints and native transaction support; current Stack already uses raw `pg`, migrations and V2/V3 reference tables. | One datasource and governance boundary; requires bounded recursive CTEs, indexes and measured query plan. | **SELECT for first slice.** |
| B: Add graph projection/read model | Can accelerate large derived reachability/dependency matrices once observed query cost warrants; must be rebuilt/invalidated with revision watermark and stale flag. | Additional outbox/consumer consistency/lag and reconciliation costs. | **DEFER** pending real volume/latency/accuracy metrics. |
| C: Dedicated graph database | Native deep traversal may be useful at much greater measured graph scale. | New credentials, tenant policy, backups/restores, cross-store atomicity, operations, migrations and replay proof; no current evidence of need. | **REJECT FOR FIRST SLICE**. |

**Authoring:** use agent-friendly declarative JSON schema + native proposal diff/review; start with accessible read-only list/table. A visual graph is optional synchronized projection. Do not add a standalone graph editor, new path engine or packages merely to draw nodes. Evaluate mature model/path tools and licensing against exact required guards/fixtures before any dependency adoption; existing linked cases remain the baseline control.

### 6. First slice, verification, rollout and rollback

**First slice (planned task T-454–461):** unplanned source modification to native result retry/ambiguous acknowledgement: source diff and agent event → behavior `READY/SUBMITTED/ACK_UNKNOWN/RECORDED/STALE_REFUSED/RETRY` obligations including valid blocked alternative + downstream reporting/defect → typed links to source/AC or explicit UNKNOWN, existing testcase version, native run/execution and actual assertion/evidence → persisted QA assessment + bell alert. One prepared-source change uses the same graph/inbox workflow. No claim that this is an existing product defect or deployed behavior.

**Three independent proof tiers:** (1) graph/schema integrity (allowed typed nodes/edges, version hashes, FK/project scope, conflict/replay, no orphan); (2) model/invariant checks (reachability/finite loops, negative/alternate paths, forbidden effects, injected faulty variant vs a separately specified model oracle); (3) product conformance (actual authorized code+DB/API/contract and targeted browser results, real build and recorded evidence). Model-only checks cannot establish actual product conformance. Regression selection must include existing `e2e/api/{automation,authorization,executions,testcases,notifications}.spec.ts`, relevant UI specs and modified owners; run only when authorized by CLAUDE.md in an approved isolated environment, never silently against shared production data.

**Rollback:** additive forward migrations only after backup/restore rehearsal; feature flag may turn off graph reads and inbox UI but preserve native cases/results and immutable historical receipts. Do not drop accepted evidence or delete project data as a rollback. Inspect exact deployed schema and retention quotas before DDL, ensure migration is idempotent/recoverable and preserve canonical source pins. Source-only draft evaluation and human sign-off are prerequisites, not substitutes for executed tests.

### 7. First-slice exact create/update inventory and untouched owners (PROPOSED)

These paths are **work-item targets, not existing implementation claims**. Confirm their names and current ownership again at the implementation branch head before editing; the migration number must be allocated after inspecting the latest applied and committed migrations.

| Proposed change | Exact repository path or owner | Boundary |
|---|---|---|
| CREATE | `Tesbo-Backend-Nest/migrations/V145_quality_change_graph.sql` (number **provisional**) | Additive project-bound behavior families/revisions, source refs, change sets/events, typed trace relations, QA impacts, assertion receipts and outbox with FK/index/check/unique constraints. No duplicate native case/result tables. |
| CREATE | `Tesbo-Backend-Nest/src/quality-impact/quality-impact.module.ts`, `quality-impact.controller.ts`, `quality-impact.service.ts`, `quality-behavior.types.ts` | One NestJS domain module for project-bound versioned changes, graph revisions, scoped traversal, inbox and transactional storage. Use the existing database/auth/audit/notification owners. |
| UPDATE | `Tesbo-Backend-Nest/src/app.module.ts` | Register one quality-impact module. Do not install a parallel HTTP/MCP server. |
| UPDATE | `Tesbo-Backend-Nest/src/mcp/mcp.tools.ts` and existing `mcp.service.ts` only as required | Expose bounded project-scoped reads and agent submissions with current per-project MCP enablement, revocation and capability gates; no direct machine approval. |
| UPDATE | `Tesbo-Backend-Nest/src/legacy/notification-events.ts` and `notification-writer.ts` | Reuse one bell type/link and existing dedup index. Extend/verify delivery acknowledgment to distinguish caught failure from dedup/no eligible recipient for outbox recovery; do not build a second notification service. |
| UPDATE narrowly | `Tesbo-Backend-Nest/src/automation/automation.service.ts` and relevant existing manual execution writer, after tracing their true owner | Bind actual attempts/assertions to the native execution and evidence lifecycle. Native `executions` remains the effective status owner; avoid treating inferred test passes as evidence. |
| UPDATE | `Tesbo-Frontend/lib/api.ts`, `components/TopBar.tsx`, `components/Sidebar.tsx`, `components/reports/TraceabilityTab.tsx` | Typed client, safe notification links, contextual navigation and accessible traceability table. |
| CREATE | `Tesbo-Frontend/app/(app)/projects/[id]/quality-impact/page.tsx` and minimal native UI components under existing `components/workflows/` only if needed | Project-local durable QA impact inbox + source/behavior/evidence detail. No independent case editor or graph application. |
| UPDATE | Existing `e2e/api/{mcp,automation,authorization,notifications,executions,testcases}.spec.ts` and selected `e2e/ui/` paths, plus backend-owned unit/DB tests | Extend the actual existing suites with permission, idempotency, omitted diff, trace, outbox, conformance, history and accessibility checks; do not run against shared data without explicit authorization. |

**Out of scope / untouched:** source provider Jira/Linear/Notion identities; mutable KB requirement mirrors; canonical `testcases` and suite hierarchy; `plans`, `cycles`, `cycle_items`, `executions`, `bugs`, `bug_links` and `attachments` as independent native owners; Zyra conversation/store and hosted-model configuration; external agent executors; unapproved automation/test environments; production records and historical evidence. New read links do not import, clone or self-publish any of these. Optional visual graph and dedicated graph projection/database are deferred pending measurements.

**Open implementation decisions:** exact approved requirement/AC authority, human model-publication role, provisional oracle handling, source-attestor trust/registered-repository policy, project QA assignment and closure rights, reporting/evidence minimum, build identity and artifact retention/redaction. These must be ratified before T-455 starts. Later source findings may change a proposed path only through an explicitly reviewed reuse/extend decision, never through silent scope expansion.


## Revision 1.4.21 — T-454 exact source and authority disposition (not shipped)

### Source-first findings on actual `development@5989e5e2c646666ed087a7885389b2ffce4bad42`

| Ref | Current source-backed behavior | Contract implication / required work |
|---|---|---|
| S-454-01 | `Tesbo-Backend-Nest/src/mcp/mcp.tools.ts`, `link_requirement_to_testcase`: links case via Jira/Linear/Notion fields **without requiring synchronized ticket**, explicitly documents no native `requirements` table | In graph relation resolver, separate `CASE_LINK_PRESENT` from `SOURCE_REVISION_VERIFIED`, `AC_APPROVED` and `AC_CONFLICTED`. Keep canonical case and provider ownership; unverified link does not establish approved truth. |
| S-454-02 | `Tesbo-Backend-Nest/src/mcp/mcp.service.ts`: project bound to API token; issuer's project membership rechecked; scoped read/write; `tools/list_changed` is false | Reuse authorization and tool registry; add explicit proposal-vs-approval capabilities under policy, and do not assume server-pushed MCP notifications or local agent launch. Clients may poll/read scoped impacts. |
| S-454-03 | `Tesbo-Backend-Nest/src/legacy/notification-writer.ts`: `writeNotifications` dedup/membership filters but catches DB exceptions and returns `0`; `Tesbo-Backend-Nest/migrations/V6_notifications.sql` has user/title/link and no project FK; V109 unique per-user `dedupe_key` | Outbox accepted atomically with impact; use a dispatcher with explicit `INSERTED | ALREADY_DELIVERED | NO_ELIGIBLE_RECIPIENT | RETRYABLE_FAILURE` result and independent reconciled delivery state. Do not treat `0` as ACK. Reauthorize and redact old project alerts at read time after revocation; normalize safe generic notification text until authorized project read. |
| S-454-04 | `Tesbo-Backend-Nest/src/audit/audit.service.ts` catches SQL insert failures and logs warning; `DatabaseService.transaction` supports caller's `PoolClient` | Mandatory graph publication/impact/receipt audit must be inserted on the SAME transaction client, and failure MUST rollback the operation. This does not require weakening or globally replacing best-effort historical logger. |
| S-454-05 | `Tesbo-Backend-Nest/src/automation/automation.service.ts`, `recordResult`: one native execution current row, retry watermark; legacy calls may omit explicit retry index; exact duplicate short-circuit; run closed refusal | Add immutable attempt receipts with stable operation identity and commit/adapter/model/case pins; preserve original attempt independent of latest row. Do not rely on retry count alone as a unique or causally sufficient attempt ID. Extend the existing authoritative result transaction, never create an alternative execution writer. |
| S-454-06 | Same service `uploadEvidence`: may return `{skipped:'quota'}` after result; uploads to local/S3 then commits metadata with compensating deletion on failure; object bytes and PG commit are not atomic | Assertion proof uses only verified durable attachment IDs/hash/ownership. Explicit pending, quota-skipped, missing and inaccessible evidence. Do not mark a required proof satisfied because a result was Passed or a PUT was attempted. Test late-close, partial upload, compensation failure and recovery/orphan tracking. |
| S-454-07 | `Tesbo-Backend-Nest/migrations/V63_testcase_versions_snapshot_trigger.sql` snapshots OLD testcase before meaningful UPDATE; `Tesbo-Backend-Nest/migrations/V119_cycle_items_field_snapshots.sql` backfills snapshots from currently available case; `Tesbo-Backend-Nest/migrations/V140_run_history_fields.sql` stores imported `step_results` / `history` JSON | When binding current and past cases, use exact content hash and native snapshot where actually available; do not invent prior pre-run versions. Mark unknown historical source fidelity, and preserve imported-history provenance and uncertainty. |
| S-454-08 | `Tesbo-Backend-Nest/src/review-board/review-board.service.ts`: duplicate/similar case analysis is Owner/Manager and gated by `assertReviewBoardEnabled`; `V141`/`V143` content and state fingerprints | Reuse stale-fingerprint/review presentation pattern only. Review Board is **not** generic publication authority, must not become a hidden paid dependency, and cannot approve behavior via duplicate review APIs. New domain policy must explicitly choose and test the existing protected review/apply seam. |
| S-454-09 | `Tesbo-Backend-Nest/src/auth/api-token-rest.guard.ts`: scoped tokens can access project REST by prefix and method, denies project administration; `Tesbo-Frontend/components/TopBar.tsx` deep-links notifications; `Tesbo-Backend-Nest/src/legacy/legacy.controller.ts` has current Requirements and matrix routes | Project prefix and generic read/write scope do not grant graph publication, source attestations or evidence traversal. Add per-operation capability and same-project FKs; cover notification title/link leaks even when user has lost membership. |
| S-454-10 | `.github/workflows/` includes Tesbo CI checks, but no verified product-owned Git webhook/attestation endpoint for coding-change capture; `mcp.tools.ts` has no `submit_change_event` tool | Do not label agent-supplied file claims `SOURCE_VERIFIED`. First source attestator requires a reviewed least-privilege host/CI artifact verified against registered repo and immutable base/head, with a separate issuer/actor. Branch/worktree-only state stays PROVISIONAL; no vendor lock-in is presumed. |

**Source references**: each path above resolves within `https://github.com/1alextest/Tesbooboo/tree/5989e5e2c646666ed087a7885389b2ffce4bad42`; code paths are verified at that revision. The existence of migrations does not prove their deployment or historical content authenticity. `Tesbo-Backend-Nest/src/legacy/legacy.service.ts` is too large for full content inspection through this GitHub file adapter; its internal notification read/history transaction semantics and deployed schema are **not** independently verified here. Do not promote an incomplete audit into a full-code completeness claim.

### Recommended owner defaults — explicitly NOT RATIFIED

| Decision | Recommended bounded initial default | Hard block until product owner ratifies |
|---|---|---|
| Requirement/AC truth | External Jira/Linear/Notion revision plus actual approval provenance; otherwise `EXPECTATION_UNKNOWN`. Case links are advisory only | No graph revision labeled approved from a URL/key, model suggestion or KB note alone |
| Provisional unplanned test oracle | QA can submit a proposal; authorized human explicitly accepts a *testing-only provisional assumption* for isolated checks, marked distinct from product-approved requirement | No automatic reclassification to official expectation or conformance certification |
| Human graph publication | Reuse protected review/apply semantics, independently policy-authorized project Owner/Manager review as initial recommendation | No fallback into duplicate Review Board, no API-token write scope as publication permission |
| Source attestor | Trusted CI/git read-only manifest from a registered repository; verified immutable base/head and typed changed-file inventory; declaration and attestation separate actors | No source-verified state based only on agent self-report or unauthenticated public URL |
| QA assignment/closure | Project QA role proposes/assesses; project Owner/Manager resolves high-risk or expectation-conflict closure | Bell-read never closes; gaps and unexamined scope require explicit tracked disposition |
| Minimum proof | Layer-specific independent assertion and authoritative readback; exact attempt, case, graph, source/build/adapter; binary attachment only where obligation requires it | Quota-skipped upload / lost evidence / unknown build remain explicit, never automatic PASS |
| Notification safety | No project sensitive text in generic bell until current authorization is confirmed; keep inbox authoritative; retry typed outbox receipts | Old notification link/title after revocation cannot leak protected project existence |
| Retention | Retain immutable receipts and audit with project classification and deletion policy; redacted source excerpt by default | No real customer artifact retention policy inferred from synthetic pilot |

### T-454 disposition and acceptance conditions

**SOURCE RECONCILED, NOT CLOSED.** Current code paths show viable reuse: native case/run/result/bug IDs, single project MCP, notification infrastructure, transactional PG, review fingerprints, UI components. Missing work is genuinely graph-specific behavior, typed historical link resolution, authoritative impact/outbox state, independently authenticated coding diff, and immutable assertion attempts. A dedicated graph database, global native Requirements registry, second assistant, runner or duplicate case store is still unjustified.

**Closure requires all of:** owner signs the eight decisions; decide exact first approved requirement or an explicitly provisional testing-only oracle; confirm actual deployed SHA/migrations and authorized isolated DB; identify trusted first source attestator and current evidence policy; approve first-slice source/feature owner; perform separate adversarial cold design review and record its limitations. T-455–461 are **NOT STARTED** by this architecture review.


## Revision 1.4.22 — Model Studio MBT-001 revision 0.2

Specification amendment only. Earlier source reviews and decisions above retain their historical dates/baselines; they are not current deployed claims. Existing IDs/content are preserved. This amendment extends native graph, Zyra, case, run/evidence and publication owners, not a parallel platform. Owner ratification and independent delta closeout remain open.

The MBT-C namespace below defines proposed design contracts. The eight files remain one package; each clause has the normative home listed here. All files apply the full cross-referenced contract; omission of duplicated prose never waives a dependency.

| Contract | Normative file |
|---|---|
| MBT-C-01 | `03_TECHNICAL_DESIGN.md` |
| MBT-C-02 | `02_WORKFLOW_AND_UX_SPEC.md` |
| MBT-C-03 | `03_TECHNICAL_DESIGN.md` |
| MBT-C-04 | `03_TECHNICAL_DESIGN.md` |
| MBT-C-05 | `03_TECHNICAL_DESIGN.md` |
| MBT-C-06 | `01_PRODUCT_REQUIREMENTS.md` |
| MBT-C-07 | `04_MCP_API_CONTRACTS.md` |
| MBT-C-08 | `04_MCP_API_CONTRACTS.md` |
| MBT-C-09 | `07_UI_DESIGN_TASKS.md` |
| MBT-C-10 | `03_TECHNICAL_DESIGN.md` |
| MBT-C-11 | `00_README.md` |

#### MBT-001-C — Typed domain contracts and lifecycles

**Model identity:** project ID + immutable model ID + immutable model revision ID. A model identity must also carry a project-scoped tenant boundary in relational foreign keys and test-case/model links; changing a display name or suite location cannot transplant identity or inherited permissions. Every revision records author, timestamp, parent revision, content digest, model type, scope boundaries, requirements/decisions cited, assumptions, validation result, policy, authorizing reviewer and status. Never use a title, slug, array index or mutable branch alias as the identity. M1 supports finite state machines and directed sequential journeys; bounded EFSM and finite compiled decision/permission capability is conditional in M2 under MBT-C-01. Temporal/asynchronous/concurrency generation is explicitly UNSUPPORTED until separately specified. Composition is explicit; no implicit graph join across arbitrary projects/models.

**Model revision lifecycle:** MBT-C-02 defines the complete status × active-pointer × action/mode matrix. Approval of r2 never changes active r1; SUPERSEDED is a derived historical label, retirement explicit. Only active approved revisions support CURRENT generation/dispatch; inactive approved revisions require explicit HISTORICAL mode, and retired revisions cannot generate or dispatch. Activation/rollback/deactivation are exact pointer CAS actions with independent human authority. Attempts retain original revision and scope. Draft previews never populate official coverage.

**Core model schema (conceptual, not a second database):**

| Element | Required properties / invariant |
|---|---|
| Model | projectId, modelId, modelRevisionId, modelType, startingStateIds, scope, provenance, status |
| State | stable element ID, human name, observable predicate/oracle, entry/exit invariants where applicable |
| Transition | stable ID, from/to state IDs, action/event, explicit guard, preconditions, postconditions, expected observation, risk/weight |
| Guard/data | typed finite or bounded variable domains; pure, deterministic declarative expressions; parameter sources and constraints |
| Prohibited behavior | explicit rejection/invariant assertion, rather than a fabricated successful transition |
| Journey | version-bound sequence/branch of explicit transitions with actor/permissions/context and recovery conditions |
| Case association | project, model revision/element/path, existing canonical case ID and exact case revision/step, relation type, author, provenance/status |
| Generated proposal | model digest, algorithm, algorithm version, deterministic seed, replay path, data/fixture reference, selected transitions, rationale, bounds, permissions |
| Execution mapping | selected approved case/path revision → existing native run/attempt/step, real observation, original evidence IDs, timestamps and outcome |
| Evaluation | covered/uncovered/excluded/unknown with denominator, revision, execution environment/build and evidence confidence; never a single misleading “covered” boolean |

**Status truth matrix:** MODELLED means declared in a validated model; LINKED means an accepted relationship to a real case revision; SELECTED means case/path was put into a run; EXECUTED means an actual native attempt has observations; VERIFIED means a supported assertion against the expected oracle with suitable evidence; APPROVED means human-governed decision on an exact revision. A count in one column MUST NOT populate another.

**Source-of-truth precedence:** Independently justified and human-approved normative requirements/rules and versioned accepted business decisions inform **expected** behavior; source-declared implementation feeds **observed** declarations; actual execution evidence supports reality. If the three disagree, report a contradiction requiring triage with distinct provenance, never auto-conform the expected model to defective code. No inferred or “AI-generated” edge is trusted until accepted under policy.


### MBT-C-01 — Finite state semantics and supported capability boundary

M1 supports ordinary finite state machines and directed journeys with fixed, explicit actor/fixture bindings. M2 may enable bounded EFSMs only after the interpreter passes the fixtures below. Permission/decision models compile to the same finite semantic representation; no separate decision runtime is promised. Every model and adapter declares a versioned capability set. Unsupported constructs fail validation with `UNSUPPORTED_SEMANTICS`; they cannot silently degrade into an ordinary edge traversal.

An EFSM configuration is `(stateId, sharedValuation, actorValuations, immutableBindings)`. Each variable has a unique stable ID, explicit SHARED or ACTOR scope, type, finite domain and initial value for every bound actor. Integers have inclusive finite bounds; enums/strings have enumerated finite domains. Secret values are credential references, never model variables. Actor IDs and role-policy revision are pinned input, not inferred from the authenticated Tesbo principal. No implicit actor change is allowed within a transition.

One sequential model step has this exact order: evaluate source invariant and precondition against the pre-state; evaluate the guard; calculate all declared assignments from that same pre-state; apply assignments simultaneously to a candidate valuation; validate types/domain, destination invariant and declared postcondition; then admit the symbolic transition. An unassigned variable retains its value. Duplicate assignments to the same scoped variable, undefined symbols, unbounded domains, impure expressions or out-of-domain results are invalid. Guard FALSE means infeasible for that configuration; evaluation error means INVALID, never FALSE or PASS. Postconditions assert the candidate state; they never solve missing assignments. Branches are separate stable transition IDs, not unspecified nondeterministic effects. State equality includes all valuations and actor bindings; a generator cannot merge distinct valuations because their state labels match.

Symbolic effects describe the expected model only. A separately authorized adapter performs target actions, records pre/post observations and evaluates the independently approved oracle; a symbolic assignment does not prove a target change. Actual observations cannot silently mutate the expected valuation to make an assertion pass. Disagreement is a recorded mismatch or UNKNOWN when required observation is unavailable.

Each independent generated path starts from its declared initial valuation and fixture revision. Before target replay, the adapter must establish/verify the fixture baseline through an authorized reset or prove the declared precondition from observations. Reset is a separate recorded operation, cannot delete prior evidence, and failure blocks the path. Sequential multi-actor paths may use explicit actor switches between transitions while sharing SHARED variables; they do not establish concurrent safety.

M1/M2 do not support virtual time, asynchronous event scheduling, eventual-consistency windows, interleaving exploration or race-coverage claims. Such requests return `UNSUPPORTED_SEMANTICS`. A future capability must specify clock/event ordering, bounded observation windows, schedule/reset identity and replay semantics before enabling them. Independent concurrency testing of Tesbo's own authorization/activation/job mechanisms remains required; this scope limit does not waive those tests.

Hand-calculated fixtures: (a) `remaining=1`, reserve guard `remaining>0`, effect `remaining:=remaining-1`: first reserve yields 0, a second reserve is infeasible; (b) two actors share remaining: sequential A reserve prevents B reserve; actor-local counters do not change each other; (c) reset restores remaining=1 for the next independent path; (d) `x=0`, increment then guard `x=1` admits the second step; (e) duplicate assignments, overflow and undefined actor are invalid; (f) a requested concurrent reserve race is UNSUPPORTED, not “covered.” These fixtures discriminate feasible-path correctness from simple edge visitation.


### MBT-C-03 — Validator classes and exact coverage arithmetic

FATAL errors block approval/generation: invalid schema/IDs, dangling endpoints, missing required initial configuration, invalid domains/assignments, unsafe AST, unauthorized cross-project reference, unsupported semantics, missing normative oracle or unresolved authority for a claimed normative assertion. Diagnostics include stable code, element/configuration identity and reason; input/security failures persist no partial imported model.

An unreachable element, guard unsatisfiable in a reachable configuration, disconnected component or dead end is a semantic diagnostic, not automatically a fatal syntax error. It remains unresolved until corrected or explicitly accepted as an intentional exclusion on the exact revision by the authorized reviewer with reason and source. Unresolved diagnostics block approval of a model claiming complete normative scope. A prohibited operation is a negative assertion with an expected refusal/invariant, not a successful traversable edge. Negative assertions have their own denominator and observed refusal oracle.

For a requested finite revision/scope and dimension, partition all elements into disjoint known eligible E, approved excluded X, unresolved eligibility U, and outside-request O. Unknown inventory cardinality is separately flagged. The eligible set is computed from approved semantics/bindings, not from which cases happen to exist or which paths the generator visited. Independently compute mapped M, selected S, observed T and verified V subsets of E; no stage implies another. Report counts and `|M|/|E|`, `|S|/|E|`, `|T|/|E|`, `|V|/|E|` separately. If E is empty, percentage is null and label NOT_APPLICABLE only when eligibility is fully resolved; otherwise UNKNOWN. Unknown total inventory suppresses an overall percentage. Known subset percentages may appear only as “known eligible subset,” with unknown count prominently visible.

Scoped 100% is permitted for a fully known eligible slice, labeled with revision, mode, dimension and filters. It never implies whole-model verification. Whole-model VERIFIED_COMPLETE requires a complete inventory, all required eligible assertions verified for the declared execution scope, no unresolved unknowns, no required element outside the request, and no unverified negative/non-state obligations. Approved exclusions yield COMPLETE_WITH_EXCLUSIONS rather than unqualified whole-model complete. A generation forecast is not measured execution coverage.



**Coverage unit version MBT-COVERAGE/1:** STATE and TRANSITION dimensions key E by `(projectId, familyId, modelRevisionId, dimension, elementId)` within pinned scope; repeated actor/data observations never multiply a structural element. ACTOR_ASSERTION keys E by that structural key plus exact oracle/assertion ID/version, actor/role-policy revision, declared finite valuation/configuration binding, fixture/dataset revision and environment/build scope. These are separate requested dimensions, not one mixed denominator. Ordinary transition coverage does not require exhaustive valuations; whole-model verification also requires all approved required assertion obligations. Eligible keys come from approved declared semantics/applicability, not from observed executions. Repeated occurrences and correction events support the same obligation rather than increment E or V. Unsupported or incomplete eligibility is U/UNKNOWN; unbounded cross-products are not implicitly enumerated. Fixture: one transition, two required actor assertions; actor A verified once or twice yields structural1/1 and actor-assertion1/2, never2/2; changing a model/oracle/actor-policy/fixture/build binding requires a new scoped claim.

Required display fixture: two reachable observed/verified edges, one reviewed exclusion, one unresolved element, no outside filter: `verified 2/2 known eligible (100%); excluded 1; unresolved 1; whole model UNKNOWN`. Remove the unresolved element with a justified resolution: the scope may read `2/2 (100%); excluded 1; COMPLETE_WITH_EXCLUSIONS`. Empty E with unresolved U reads `—; UNKNOWN`, never 0% or 100%. Failed projection/data fetch reads UNAVAILABLE and retains the last result as stale; it cannot become an empty successful denominator.


### MBT-C-04 — Deterministic traversal and bounded native jobs

Deterministic inputs are canonical model bytes/digest, semantic schema/interpreter version, generator/version, seed, ordered strategy parameters, actor/role-policy and fixture revisions, initial configuration, objective, scope and logical limits. Canonical serialization defines stable ID ordering (UTF-8 byte order), adjacency/queue tie-breaking, seeded PRNG/version and finite value enumeration. The engine counts each candidate transition guard/effect evaluation as one work unit, including infeasible candidates; stops before exceeding maxWorkUnits, maxPathDepth, maxPaths or maxInputCombinations; and records units consumed and the exact deterministic stop reason. Limits are part of the input digest. Each engine version must specify its strategy ordering; libraries with nondeterministic output cannot claim deterministic support.

Equal deterministic inputs with no emergency interruption produce byte-equivalent ordered path/configuration/valuation output and deterministic stop fields. Operational envelope fields (job IDs, timestamps, host, duration, telemetry) are outside that equivalence and outside the logical manifest digest. Execution observations are never included in this deterministic-output promise. Wall-time, memory, CPU or provider interruption is an emergency protection: return PARTIAL with `EMERGENCY_RESOURCE_CUTOFF`, observed prefix and diagnostics, never a deterministic-completion claim. Delayed evaluation with adequate emergency allowance must produce identical logical output; a forced timeout may differ and must be visibly partial. M2 promises replay from the beginning, not opaque resume; resumability requires a later versioned frontier/counter/PRNG checkpoint contract.

Reuse Tesbo's native task/job, BullMQ, project-limit and audit owners. Before admitting any generation/retry, reserve bounded capacity atomically against BOTH project and platform active-work/rate/spend quotas. Charge actual work/tool/provider consumption cumulatively across attempts, without double charging duplicate command receipts or refunding consumed work after cancellation. Admission failure returns `429 RESOURCE_LIMIT` plus retry guidance and causes no automatic follow-up. Unknown or unset safety caps disable generation with `503 RESOURCE_POLICY_UNCONFIGURED`; there is no uncapped default. Numeric defaults, fairness and p95 objectives must be measured and ratified for the two-domain pilot before M2 activation; no measurements are claimed here.

Native jobs follow QUEUED → RUNNING → COMPLETED/PARTIAL/FAILED/CANCELLED. Cancellation first records CANCEL_REQUESTED (nonterminal), prevents new claims/actions, then reaches CANCELLED after fenced ownership reconciliation. Lease expiry ends the old attempt and fences its writes; retry creates a new attempt under the same logical request with a new generation, subject to cumulative budget and retry cap. Terminal states are immutable. Every heartbeat/result/attachment publication checks project, attempt and lease generation transactionally. A late worker cannot publish, release another worker's reservation or consume fresh credentials. Release unused reservation exactly once at terminal reconciliation; shared active slots are not freed merely because an old process missed a heartbeat while its effects are uncertain. Admission counts unresolved in-flight effects until reconciled. The native job owner is responsible for orphan lease accounting, backlog/age/stop-reason telemetry and bounded operator recovery; no second scheduler/job store is introduced.


### MBT-C-05 — Native versions, rule provenance, evidence and retention

Accepted normative reliance pins source kind/provider, native source ID, exact revision where available, retained canonical content digest/snapshot, approval/acceptance event and actor/time, applicability scope and retrieval provenance. A mutable latest URL, provider cache row, source graph node or title is not historical authority. When the provider lacks immutable revisions, retain the authorized approved snapshot under native retention and its digest; absent lawful retained content/authority, the assertion is EXPECTATION_UNKNOWN. Provider update/delete/reconnect creates impact candidates and read restrictions; it does not replace accepted history or silently change an oracle.

The native case owner must expose an immutable content version for BOTH initial and current case content. Reuse trustworthy existing version/snapshot records; extend the native version contract if current content lacks an address. On new selection, atomically capture/resolve the exact approved case revision and stable step/condition IDs, content digest, capture origin/time and approval event. This snapshot is a native version artifact, not a second editable case. A historical OLD-row trigger alone does not prove an unedited initial/current version. Legacy links gain no fabricated contemporaneous version: annotate UNKNOWN or RECONSTRUCTED_UNVERIFIED with reconstruction limits; never promote them to VERIFIED from today's case text.

An accepted mapping event pins model revision/element/path, exact case revision/step/condition and actor/data scope, proposer, acceptor, source and status. Add/reject/supersede/remove are versioned decisions. Removing a mapping is a versioned no-new-dispatch boundary. Preparation records a frozen selection but does not freeze permission to rely on the mapping later. Before preparation and again at claim/dispatch under the canonical native owner, require the exact accepted mapping event still eligible and not removed/superseded. A change before dispatch returns `409 MAPPING_CHANGED`/BLOCKED, preserves the selection and requires fresh accepted mapping plus refreshed consent under a new operation before retry. This applies equally to CURRENT and HISTORICAL work. Once an occurrence has actually dispatched, its original mapping/consent is retained as historical reliance; later removal alone neither rewrites nor cancels it. Explicit cancellation or target/membership revocation remains the separate authority to fence further actions. The remove-versus-dispatch transaction must have one serialization point: if removal commits first, no new dispatch; if dispatch commits first, that exact occurrence retains its prior reliance. Preparation and a queued task are not proof of dispatch. Mixed-validity batches are atomic, with no foreign-object metadata in errors. Suite/name moves preserve identity; material edits create new versions and revalidation candidates.

Before dispatch, the native run/attempt owner retains an immutable selection manifest referencing model and case versions, mapping acceptance event, ordered path/configurations, generated manifest digest, native run/cycle item, attempt ID, step OCCURRENCE ID (including repeated visits), actor/role-policy, dataset/fixture, target environment/build or explicit unknown, adapter/version, independently sourced oracle/evaluator version and exact consent. A run/case pair is insufficient to distinguish reruns, roles, datasets or repeated transitions. The existing picker must gain an opt-in occurrence-aware Model Studio view without silently changing other consumers. Reuse native execution/evidence panels and APIs; extend references/provenance instead of storing copied mutable results in the model domain.

Native observations retain original received report, timestamps/source, expected-vs-actual value, original evidence IDs/digests and admission state. Evidence supports VERIFIED only when bytes, ownership, exact occurrence and oracle adequacy are established under policy. Attachment count, temporal ordering, HTTP 200, navigation or agent PASS alone is not proof. Missing/quarantined/quota-skipped/inaccessible bytes give UNKNOWN/PARTIAL; they do not fabricate evidence or erase the actual action. Corrections append authenticated correction events pointing to the original and reason; the effective result is a native projection. Manual UI, automation reporter, API/MCP, jobs, imports and late callbacks must share this occurrence/correction owner. Findings link the exact occurrence, with direct-failure and side-discovery distinguished.

**Chosen proposed deletion behavior: RESTRICT referenced provenance.** While a model decision, accepted mapping, selected/queued plan, attempt/assertion, retained review or preservation hold relies on a record, hard deletion of that record or its owning project/case/run/model is rejected with `409 PROVENANCE_IN_USE` under the native deletion owner. Existing soft-delete/archive remains available according to policy and removes current eligibility without erasing retained IDs/content. Apply targeted constraints to the relevant native delete paths; do not assume V147 cascade FKs already implement this. Evidence bytes with retained reliance require a preservation hold; deliberate lawful erasure follows a separately authorized native retention process that keeps a minimal access-controlled erasure receipt/digest where permitted and downgrades unavailable proof to UNKNOWN. No fabricated snapshot may stand in for erased bytes. Product privacy/retention owner must ratify the schedule and legally permitted metadata before real sensitive data is admitted. Default referenced provenance has no automatic expiry; this is a proposed integrity rule, not a universal legal retention period.

Restoration preserves original identity and audit, rechecks current access, and restores historical visibility only. It never reactivates a model, reaccepts a removed mapping, restores revoked consent or makes evidence current VERIFIED. Native deletion/migration/restore transactions must be exercised with historical and legacy fixtures before this contract can be called implemented.


### MBT-C-10 — API errors, enforcement owners and dependency direction

Add explicit project/model actions activate, deactivate, retire and historical generation mode alongside existing draft/review/links APIs. Every mutation carries expected artifact/pointer versions and operation key; do not put these in optional UI-only state. Typed outcomes include `400 INVALID_MODEL`, `422 UNSUPPORTED_SEMANTICS`, non-enumerating `403/404`, `409 REVISION_CONFLICT/ACTIVE_REVISION_CONFLICT/MODEL_SCOPE_CHANGED/OPERATION_KEY_CONFLICT/PROVENANCE_IN_USE`, `410 OPERATION_RECEIPT_UNAVAILABLE`, `429 RESOURCE_LIMIT`, `503 RESOURCE_POLICY_UNCONFIGURED/DATA_POLICY_BLOCKED`. Native request transports may map these to existing envelope conventions but must preserve machine-readable distinctions. No API exposes a writable `verified` boolean.

| Authoritative fact | Owner / required extension | Downstream projection; forbidden reverse authority |
|---|---|---|
| Approved normative rule | Native requirement/decision owner + retained accepted version | Justifies model revision; current source/cache cannot approve rule |
| Model bytes/approval/active pointer | Expected-model aggregate under native policy/audit | GraphSnapshot/diff/highlight; projection cannot mutate approval |
| Case content/approval/step version | Native case version/publication owner | Accepted model mapping; model cannot copy/publish a second case |
| Mapping decisions | Typed native trace relationship owner | Case/model highlighting; removing a link cannot erase past reliance |
| Generation intent/work | Native task/job/quota owners | Proposal manifest; no separate job authority |
| Run/attempt/occurrence/report/correction | Native run/execution owner | Coverage evaluation; model cannot edit a native observation |
| Bytes and retention | Native attachment/storage/privacy owner | Evidence drilldown; count is not byte proof |
| Human/target authority | Native authorization + exact consent owner | Dispatch permission; token issuer is not human consent |
| Coverage/evaluation | Derived from exact references + versioned evaluator | Recomputable read view; no independent mutable VERIFIED store |

Implementation archaeology must census all affected writers/readers, including manual native result editing, reporter/automation, MCP, UI, import, jobs, deletion/restore, exports and shared picker/evidence consumers at the actual implementation head. Resolve resource ownership for non-project URL paths rather than trusting a submitted projectId. Each writer enters the same owner-level policy/version/fencing path; a UI or controller-only check is insufficient. Record source path, operation, existing guard, new extension and impacted existing tests. No new universal artifact/review platform, graph DB, assistant, case/run/evidence store or scheduler is earned by these requirements.




## Revision 1.4.23 — Model Studio revision0.3 reconciliation



**Canonical identity:** MBT-C-12 in `03_TECHNICAL_DESIGN.md` binds Model Studio to the same FR-117 behavior family/revision owner; model IDs are aliases, and current-published is the active pointer, never a second latest-approved authority. This v1.4.23 clarification governs operative FR-117/MBT identity and selection wording in earlier proposal sections; historical source evidence retains its original pin.

### MBT-C-12 — Canonical behavior/model identity, publication and applicability

Model Studio is the authoring/generation/view capability of the existing **proposed** FR-117 behavior-definition authority. It does not create a second expected-model registry. `modelId` is the API/UI alias of `quality_journey_families.id`; `modelRevisionId` is the alias of `quality_journey_revisions.id`. They are the same project-bound identities, never separately minted IDs joined later by a best-effort link. Typed model content, source justification and C-01 semantics extend that revision's immutable `model_json`. Observed implementation GraphSnapshot/capture history remains a separate observational authority and cannot publish expected truth. Physical schema names remain implementation choices; the logical owner is singular.

M1/M2 give each family one immutable `declaredScopeId` and one active-revision pointer with a version token. The tuple `(projectId, modelId, declaredScopeId)` therefore addresses that same family-owned selection, not a second applicability registry. Changing the scope requires an explicit new family and reviewed relationship/impact, never silently reinterpreting old attempts. The earlier term **current published revision** means the active approved revision under C-02; it is a compatibility/read alias, not a separately writable pointer or “latest approved” selector. Latest approved is a derived historical query and cannot authorize CURRENT work. Approving/publishing revision r2 stores its exact approval event but leaves active r1 unchanged. Activating/rolling back/deactivating changes the one family-owned pointer through C-02 CAS and a distinct human action.

Prepared requirements/model entry WF-21 and spontaneous coding entry WF-20 resolve this same family/revision/selection owner. An unplanned source observation without an accepted family remains an UNKNOWN impact or candidate proposal; it cannot create a second normative model. All UI/REST/MCP/jobs use this resolver. Missing or inconsistent legacy identity yields BLOCKED/UNKNOWN rather than selecting whichever pointer or record was most recently written. If an existing deployment has duplicate candidate records, migration must establish explicit same-project correspondence from retained content/provenance and owner-reviewed resolution; matching titles alone cannot merge them. Ambiguous candidates stay quarantined from CURRENT selection. No new migration is claimed here.

For M1/M2, incompatible overlapping normative families are blocked with `409 MODEL_SCOPE_CONFLICT`; no last-write-wins or implicit OR/AND of their oracles. An authorized resolution must select the governing family with explicit scope/provenance before CURRENT generation or dispatch. General cross-model composition and multi-scope families are deferred until their conflict/approval/replay semantics are specified. This restriction preserves reusable cases across different non-conflicting models and historical views.

Closure fixture: one family f, approved active r1; author r2 through prepared entry and inspect through spontaneous entry → same f/r2 identities. Approve r2 → both entrances still resolve CURRENT r1 and pointer version v. Competing activation r2/r3 with v → exactly one pointer update/event; both entrances observe that winner. HISTORICAL r1 remains pinned and never becomes current credit for r2. An input containing unequal familyId/modelId or revision aliases fails before persistence. Two conflicting families with no approved resolution return MODEL_SCOPE_CONFLICT; source capture cannot choose a normative winner. These are planned native DB/API/entry-parity tests; the offline finite-semantics pilot does not implement or prove this authority.



## Revision 1.4.24 — opt-in native M1 candidate preview

MBT-C-13 in `04_MCP_API_CONTRACTS.md` owns the exact ephemeral structural preview contract. This adds no expected-model identity, publication, active pointer or second data store; FR-117/C-12 remain authoritative for future persisted models. Intake and authorization are explicit; default OFF. Source implementation is proposed for merge in Tesbo PR95, parent92abc860/native implementation23b5a7ec; no deployed or target-runtime proof is claimed by this spec checkpoint. Existing historical source/test/review claims remain at their original pins.

Use the existing GraphChangeReviewModule and native access/token/plan guard boundaries. Preview core has no database/provider/target dependency; native service performs canonical access and a final scoped membership/archive SELECT, not model/case/run mutation. Bounded reachability is not M2 path generation or queue admission. No schema migration.


## Revision 1.4.25 — native MCP draft-preview integration

MBT-C-14 extends the existing MCP gateway with the MBT-C-13 stateless validator. This adapter creates no model authority or native QA record. Review gates remain NOT FROZEN; persisted models, activation, generation, target execution and native UI require their own completed work/evidence. The earlier native REST code at778e3658 has exact-head CI evidence; this MCP delta requires its own final-head receipt in PR95. Historical review and implementation statements remain pinned to their original revisions.

Reuse GraphChangeReviewModule export/injection and the existing MCP context. No new server, model owner or persistence layer. Preview core traversal has an explicit constant32-state cap as well as validated intake and deduplication. Scanner alert closure requires exact-head evidence, not only a green workflow.


## Revision 1.4.26 — native ephemeral draft inspector

MBT-C-15 adds the bounded structural list inspector and scoped availability read to the existing Zyra page. C-13/C-14 remain validation owners; C-12 remains future persisted-model authority. Earlier API-only/no-frontend statements describe their historical slices, not this new increment. There is still no approved/persisted model, graphical editor, case mapping, target action or self-issued independent freeze. PR98 owns exact-head implementation/visual receipts. Historical acceptance and review results retain their original pins.

Use native ModelStudioPreview availability with shared final access fence, existing API transport and a project-keyed in-memory client inspector. Defensive response admission is not a second interpreter. Sequence and lifetime fences reject stale responses; no persistence or dependency addition.


## Revision 1.4.27 — inspector wire-format and layout proof clarification

C-15 admits only object-shaped JSON to the native POST transport. Invalid JSON, null, arrays and primitives remain in the editor with local errors; semantic fields, bounds and authority still use the one native validator. This avoids treating a pre-routing JSON/CORS transport failure as a typed model response. Mobile containment is measured after the existing sidebar reaches its chosen60px collapsed width; the strict overflow assertion and default timeout are unchanged. Independent assurance, full AT, persisted/graphical authoring and target-conformance gates remain open.


## Revision 1.4.28 — reuse-first integration and governed skill ownership

**Status:** Architecture proposal only. Existing source owners must be re-verified at implementation head. No migration approved by this document.

### 1. Architecture

An application change produces a **Change Packet**: a versioned, project-scoped *coordination receipt* that links canonical records without becoming a duplicate source of truth. Work may start from spontaneous coding, an approved requirement, a QA finding or a policy decision. This is a **cross-role software delivery assurance architecture**, not a replacement coding agent/IDE.

Source providers, optional coding-agent hooks and explicit human/MCP observations feed the existing source/change owners. Tesbo MCP and Zyra obtain scoped context and effective guidance, prepare shared staged operations over native records, and expose human review. Actual execution, deployment and incident receipts feed the same traceable change view; none of those observations automatically approves an expectation. The canonical ownership and lifecycle contracts in §18 define the relationship, including failure and recovery.


Do **not** introduce a new chat assistant, a shadow test case writer, a disconnected project board, a second Knowledge Base or an AI-owned policy authority. Reuse `graph_history`, current cache graph, Model Studio revisions, Zyra task/feedback history, existing notification writers, `LegacyService` business rules, and versioned KB documents; extend them only at evidenced gaps.

### 2. Current evidence and actual gaps

Source inspection pinned to `0c54b8ed28c9dec51ed0ca3bbb3cd3b7b8ab12d8` (not a deployed-build claim): `Tesbo-Backend-Nest/src/mcp/mcp.tools.ts`, `mcp.service.ts`, `docs/FEATURE_DOCUMENTATION.md`, and `graph-change-review.controller.ts`.

- Existing MCP: `create_testcase`, `update_testcase`, `sourceRefs`, `link_requirement_to_testcase`, `create_knowledge_document`, `update_knowledge_document`, graph change capture/history, behavior model drafts. The source currently registers 58 tools; this is **not** proof the deployed client sees them.
- Existing `link_requirement_to_testcase` accepts **exactly one** `jiraIssueKey`, `linearIssueKey`, or `notionPageId`. It does not accept a native Tesbo requirement ID. The `get_requirement_matrix` endpoint largely reports cases/runs/bugs; external Requirements UI counts linked non-deleted cases, which is not executed coverage.
- Existing KB `requirement_note` and feature-requirements templates can hold content, but do not constitute a first-class native requirement object with accepted criteria/revision-aware typed testcase edges.
- The KB already owns documents, folders, version history and files; the MCP source includes KB **document/folder** tools but does **not** advertise binary file-upload tools.
- Zyra has a generation-specific Kanban/task review; Bugs have their own records. Neither is yet a general work-item system covering implementation and policy/documentation tasks.
- Graph history/capture, Zyra change review and Model Studio provide a reuse substrate; source-declared behavior and model/case mappings are not proof of deployed or executed behavior.
- The historical 2026-11-15 manifest did not record an independent team run. The separate 18 November rerun now has original independent receipts; it does not retroactively execute old tests or establish runtime/UI assurance.

### 3. Canonical ownership map

| Record/relationship | Authoritative owner | Projection/adapter |
| --- | --- | --- |
| Code diff, PR, commit, deployment | repository/CI/deployment provider | project source binding and graph observation |
| Native requirement content/version | existing KB document identity + typed requirement rules; approved DB mapping if necessary | native Requirements UI and MCP |
| Jira/Linear/Notion requirement | provider and existing synced cache | integration adapters, external key mapping |
| Case, approval and execution | native case/suite/plan/run/result services | MCP, Zyra generation, Model Studio, reports |
| Manual/API/operations documentation | versioned KB document, classified by audience/access and subtype | internal/external manual views, governed skill-specific authoring and MCP |
| Decision, policy, enforcement rule | typed governed KB content with immutable authority-backed revisions | internal/external policy views, effective skill resolution, lifecycle and impact reports |
| Work item/task | unified native project task service derived from existing task/board infrastructure | agent work queue and board; Bugs remain defects |
| Bug | native Bugs service | work-item relation and graph link |
| File/evidence | existing KB file/storage/evidence services | MCP safe-upload/download/ref adapter |
| Governed Skills Library and approved assignments | T-422 QA Standards & Playbooks, existing guide/workspace/project bindings, immutable governed KB snapshots for project content and separate human authority | read-only effective-skill resolver, candidate MCP tools and human-only Skill Assignments UI |
| Cross-artifact link and review | native graph/link services + change review history | Change Packet and summary read model |

Before adding columns/tables, inspect existing migration indexes, KB version identities, Zyra tables and current graph link schema. The storage implementation is not pre-decided: prove reuse/extend/new options against required invariants first.

### 4. Change Packet contract

The canonical identity is FR-115/T-455 `changesetId`; `changeId` is its API alias. Packet/Workspace is a projection over that owner, shared proposal operations, independent impact/task decisions and native evidence. It is not a second writable lifecycle. Illustrative response, with the actual schema still subject to implementation and capability discovery:

```json
{
  "changeId": "existing-canonical-changeset-uuid",
  "projectId": "authenticated-project",
  "inputRevisionFingerprint": "digest-of-authoritative-input-revisions",
  "sourceRefs": [{"bindingId":"stable-binding-id","configurationRevision":"exact-config","repositoryId":"provider-id","ref":"refs/heads/feature","baseCommit":"sha-or-unknown","candidateCommit":"sha-or-provisional-digest"}],
  "proposalRefs": [{"proposalId":"shared-staging-id","revision":"exact-revision","logicalOperationIds":["operation-id"]}],
  "workItemRefs": [],
  "impactRefs": [],
  "releaseCandidateRefs": [],
  "artifactAssessments": [{"domain":"requirements","applicability":"change_required","workDisposition":"active","reason":"criterion changed","evidenceRefs":[],"operationRefs":["operation-id"]}],
  "coordinationState": "review_required",
  "readiness": "not_assessed",
  "scopeCompleteness": "partial",
  "unexaminedScope": ["additional configured dependency"],
  "asOf": "UTC-time"
}
```

All seven domains have assessment entries; the single row above is illustrative. A valid source-free change records that reason instead of inventing a commit. Many-to-many source/release scope, candidate-to-native target resolution, derived lifecycle, rejection/cancellation/deferral/reopen and exact resume behavior are normative in canonical API revision 1.4.28 (ASER-C01–06). Typed edges use FR-118/T-426 and exact revision/occurrence identity; citations and observed graph links never become approved coverage by proximity.

### 5. Agent work cycle

**Preflight** (read only): Verify project binding, token permissions, runtime server identity, `tools/list` contract, source commit, existing applicable records **and the exact approved effective skill assignments for each selected module/subtype/audience**. Do not load a skill proposal or stale cached version as authority. Missing or conflicting mandatory binding blocks the affected governed authoring action; no automatic choice of another project when binding fails.

**Assess**: Find source and behavior changes, existing artifacts, affected stakeholders, applicable policy versions and tasks. Classify each domain as update/unchanged/not applicable/blocked/deferred, with rationale. For spontaneous code changes, this can occur incrementally; no prerequisite formal spec ceremony.

**Plan**: Establish affected requirement acceptance criteria and verification strategy. Preserve existing IDs, define potential manual/policy impact, list cases before automation. A specialist can draft one area but inherits no extra publishing authority.

**Build and prove**: Code, unit/integration/E2E tests and actual observations remain within the coding tool's execution environment. Record what was **run**, not just authored, and distinguish CI, local, and live target.

**Propose**: Submit immutable **shared staged** requirement revisions and testcase logical operations (not direct official rows), internal/external manual edits, internal/external policy/decision/rule proposals, work item changes and (when requested) *new skill candidates/successor proposals* using existing services and the pinned governing skill versions. An agent can propose a new skill version but **cannot mutate any existing skill version, assign/reassign it, activate/deactivate it or approve it**, even through an admin-owned machine token. Hash source inputs; keep base revisions and exact source citations. Never unilaterally rewrite an approved policy.

**Reconcile**: Link coherent candidate revisions, identify duplicates/conflicts, mark impacted existing cases stale, and surface QA/BA/policy/manual review through existing Zyra and notifications.

**Approve/publish**: Each domain's authorized reviewer approves exact revisions. Skill promotion and module assignment require independently authenticated interactive human governance, not an MCP credential issued by a human. Protected selected publication occurs through the actual shared native transaction with optimistic concurrency, exact approval/dependency validation, logical commitments and mandatory audit. An eligible new run item must match the reviewed semantic definition; a status label alone is insufficient. Ordinary receipt ingestion and official publication are distinct actions.

**Close out**: Save exact persisted receipt(s), links, missing evidence, blocked/deferred work and next actions; support resume after interruption.

### 6. Multistep reliability and security

- Server: all tool handlers call native services; verify project identity and role per operation, not only at the initial client handshake. Explicitly bind reads and writes to the token's project.
- Proposal idempotency: `(projectId, operationKind, idempotencyKey)` must return the prior result when payload hash matches; a reused key with a different payload is a conflict.
- Revision guard: every update carries `expectedRevision` (or an equivalent version token); concurrent disjoint changes may merge only when semantically safe and reviewed.
- Batch safety: partial candidate staging/external effects use the existing operation journal; selected protected native apply must be all-or-nothing with one real transaction client. If a native adapter cannot participate, fail or remain staged before any official mutation. Explicit resume rechecks unresolved items; receipt lookup never silently resumes.
- Permissions: `read`, `propose`, `edit`, `review`, `publish`, `approve_policy` are distinct **capabilities** enforced by Tesbo role/authorization rules. Avoid assuming all existing tokens support these granular scopes.
- Auth and secrets: server-side source allowlist, stored source binding, no user-supplied URL/bearer tokens in free-text prompts, file content/byte checks, tenant isolation and audit trails. An agent is never the policy authority by virtue of being the proposer.
- Client version drift: compare deployed `serverInfo.version` / tool fingerprint and introspected schemas; reconnect or mark blocked if the needed capability is absent. Tool catalog advertised in a branch is not runtime verification.

### 7. Modules and user experience

Use the **existing project navigation** and domain services, with modules or views as needed:

- **Requirements:** Native + External tabs; details and revision diff; acceptance criteria; linked cases and gaps; approval/status. Proposal UI shows effective requirements-authoring skill version.
- **Test Cases:** Existing editor and Zyra review; “Requirement coverage” links are separate from source citations.
- **Knowledge Base / User Manual:** existing document editor; internal/external plus functional-audience subtypes; grouped Manual/Policy/API documentation views without another document store. Audience, source authority and visibility are independent axes.
- **Policies:** governed KB-backed policy index, internal application-governance and external-facing/externally sourced policies, active/draft/history, decision and enforcement reference details, review/activation permission checks, skill-specific authoring rules.
- **Tasks & Issues:** existing task board extended to general project work; defect links continue to native Bugs; a single card exposes cross-artifact change status.
- **Files & Evidence:** existing KB file browse/upload/preview; verifiable byte metadata and canonical source linkage.
- **Skills Library inside D-14 QA Standards & Playbooks:** one versioned searchable view in existing settings, candidate creation/proposed successor via MCP, dependency/evaluation and usage history; only a separately authorized human governance view may approve versions, activate or reassign effective bindings, or change root meta-skill.
- **Zyra Change Review:** one change packet and per-domain proposals, diffs, missing verification, approvals, timeline and reports. No new independent Copilot.

UI status must never collapse `draft`, `linked`, `approved`, `executed`, `passed` and `deployed-verified` into one “complete” badge.

### 8. Policy design extracted from Nesberry (context-sensitive)

Nesberry's Policy Ledger uses distinct *Decision* → *Policy Version* → *Business Rule/enforcement*, append-only semantic versions, provenance/authority, version predecessor validation, session effects and link integrity. Port that **contract**, not its file layout/ID namespace:

- In Tesbo, the KB document owns approved policy text and immutable revision identity. Typed projections expose active/draft/history.
- A decision explains who/why; the policy states normative invariant and effective scope; rules/tests/guards prove some degree of enforcement.
- Session manifest principle becomes a persisted Change Packet activity/effect receipt. Approval and publication remain authorized and audited.
- Policy change impacts graph-linked requirements/cases/manuals/tasks; unknown/dangling links remain explicitly uncertain.
- Source completeness matters: Nesberry's policy-ledger tasks show some phases built and some pending. Do not transplant incomplete features as "already implemented."

Nesberry's concurrent issue-filing lesson becomes **per-record isolation**, collision checks and optimistic locking in Tesbo's DB, not an `ISS-NNNN.md` store.

### 9. Evidence tiers

| Assertion | Minimum evidence |
| --- | --- |
| Proposed artifact | Persisted draft ID + readable revision |
| Approved artifact | Authorized review event binding the precise revision |
| Code changed | Pinned repository diff/commit |
| Test authored | Saved case/spec ID, not a pass |
| Test executed | Actual runner/run receipt + result + selected scope |
| Target validated | Known deployed target identity + test evidence against it |
| File verified | Retrieved/checksummed bytes, not metadata count |
| Change complete | Domain dispositions, accepted revisions, residual risks and reviewer sign-off as applicable |

No artifact count or generated graph equals a proof of real target behavior.

### 10. Skills governance architecture and seven-domain lifecycle
The complete, testable contract is [skills-governance.md](03_TECHNICAL_DESIGN.md); this design adopts it as a **governing layer**, not a seventh duplicate document store.

#### 10.1 Two separable invariants
1. **Skill identity and immutable revisions:** skills are versioned native content; the agent's only skill mutations are additive candidate creation/proposed successors. Creation, editing existing version payload, approving and publishing are distinct verbs.
2. **Effective assignment authority:** a separate typed binding resolves exact approved skill versions to module/subtype/audience/project operations. Activation/deactivation/assignment, precedence and root protection are *never MCP-writable*. The human-governance endpoint must reject machine principals even when the token owner is a human administrator.

A Skills-authoring meta-skill is itself a governed artifact, but initial bootstrap and successor promotion use an independent human-controlled root trust anchor, not a recursive skill loop. The root can be replaced only by a separately authorized and evidenced governance decision.

#### 10.2 Application and source boundaries
- **Manual:** module/user group/internal-external distribution/ACL and artifact subtype are orthogonal. Internal instructions, developer manuals, external customer instructions, partner manuals and support runbooks are not one indiscriminate template.
- **Policy:** internal application/business/governance policies and external-facing or externally mandated policies are distinct in audience, source of authority, required sign-off, jurisdiction and scope; an externally mandated rule can be handled by an internal enforcement policy while external-public display remains separate.
- **Project-specific adaptations:** portable core and scoped adapter may compose by a human-approved rule. No "last matching skill wins" and no candidate skill can override the root, change the module assignment or supply its own authority.
- **Agent control:** a governed authoring call pins effective assignment IDs, skill version IDs and hashes in the candidate and Change Packet. The native service revalidates binding before submission/promotion; stale means `SKILL_CONTEXT_STALE`, ambiguity means `SKILL_ASSIGNMENT_CONFLICT`, and absent mandatory mapping means `SKILL_UNASSIGNED`.
- **Prompt injection:** a skill candidate is untrusted input until approved and assigned, and external files never inherit instruction authority just by being cited. Effective skills are signed/digest-bound read results; references, assets and examples remain data.

#### 10.3 End-to-end authoring flow
```text
coding agent / optional specialist delegates
           |
      MCP identity + project/source binding
           |
  resolve_effective_skills (read-only)
    -> exact approved versions, assignments and hashes
           |
   read existing records + actual target behavior
           |
   create draft per applicable module, pin governing skill set
    -> requirements  -> native testcase candidates
    -> internal/external manuals, internal/external policies
    -> tasks/issues, evidence/files, optionally skill candidate
           |
   native writer validation, typed links, idempotency, audit
           |
     human review for artifact publication
     separate trusted human skill activation/assignment
           |
    graph impact + historical version/skill provenance
```

New skill candidates do not change any active effective assignment. A skill assignment change mid-flight preserves the candidate and records a blocking stale context unless specifically re-reviewed; the prior exact skill version stays in historical records and frozen executions. Old MCP/REST/AI writers **must not** bypass server-enforced skill applicability: inventory and compatibility/migration gate precedes rollout.

#### 10.4 Proposed conceptual governance model (no migration asserted)

All names below are logical attributes/relations of the existing T-422 guide/asset and binding owners, not new independent registries. §18 and canonical 03/04 give the exact owner mapping; do not create a second resolver or Skills database.
- `skills`: stable identity, owning scope, shared KB document identity if compatible, lifecycle and metadata.
- `skill_versions`: immutable content snapshot, predecessor, hash, references, candidate/published/rejected event identity; no in-place overwrite.
- `skill_assignments`: independently versioned binding of approved skill-version(s) to module/context plus activation/precedence/owner/approval.
- `skill_reviews`: human decision and source of authority binding exact reviewed payload hash to version/assignment.
- `artifact_skill_usages`: durable immutable provenance edge per artifact/content version; migration unknown marked UNKNOWN.
- `skill_effective_resolution`: derived read model only, no authored parallel truth.
These are **logical entities**, not a mandate to create six new tables. Use existing KB/history/graph/audit models first, add narrow constrained metadata where proven necessary.

#### 10.5 Admission and completeness criteria
Design isn't ready until library version lineage, composition conflict, root-meta bootstrap, inaccessible/inactive skill, revocation/rollover, per-role privilege checks, cache consistency, externally sourced obligations, all existing REST/MCP/UI writer paths, candidate poisoning, historical provenance and a realistic human approval flow are specified with independently falsifiable tests. The `SK-E2E` test matrix in the Skills document is mandatory for implementation admission, **not** proof of execution.

No implementation or current deployment claim is implied by this section.

### 11. Hybrid source-change detection and reconciliation — Kiro precedent, Tesbo implementation
**Source-owner reuse:** The existing project source binding, current-cache graph capture/history, `GraphChangeReviewController`, native notification writers and Zyra review feed remain the canonical Tesbo sources. Integration adapters supply observations only; no second repository record system.

**Observation channels and trust:** (a) optional client events such as file save, task completion or agent stop, with exact supported wire event names and security scope discovered for the installed client/version, (b) source provider webhooks for push/PR/merge and repository identity, (c) CI build/check callbacks, (d) deployment/incident provider events when installed, (e) explicit Tesbo MCP capture or human rescan. These channels are complementary, not redundant claims of exhaustive coverage. Not all tools/IDE surfaces support hooks. **Do not require a client hook to prove that a commit exists.**

**Logical normalized receipt** (exact schema delegated to native data/service discovery):
```json
{
  "projectId": "from-authenticated-source-binding",
  "sourceBindingId": "stable-binding-id",
  "configurationRevision": "immutable-configuration-at-original-observation",
  "sourceType": "agent_hook|repository|ci|deployment|manual_reconciliation",
  "sourceEventId": "stable-provider-id",
  "deliveryId": "dedupe-key",
  "sourceRevision": "git-sha-or-provider-version",
  "sourceScope": {"repository": "owner/repo", "ref": "refs/heads/..."},
  "observedAt": "UTC",
  "sourceOccurredAt": "UTC-or-unknown",
  "actor": {"principalId": "verified-or-null", "agentId": "attributed-or-null"},
  "evidenceClass": "tesbo_observed|provider_attested|agent_reported|derived_inference|unobserved",
  "processing": "received|reconciled|incomplete|rejected|superseded",
  "gap": "none|unknown-range|unsupported-source|stale|authorization-failed"
}
```

- Verify source/project binding on each receive and on reconciliation. Reject an unbound remote repository, spoofed source IDs, replaying stale head across environments and cross-project scope.
- Deduplicate by provider/scope/sourceEventId+content identity; record gaps and conflicting branch/head observations; do not order by local arrival time as if it were causality. Repeated file-save events for the same eventual commit may coalesce, but never erase meaningful separate source revisions or reported errors.
- Provider reconciliation detects source commits with no corresponding current successful capture for *known authorized tracked sources*. Where the repository is unreachable or permissions are revoked, result is `UNKNOWN`, not `UNCHANGED`.
- Source-change detection may suggest *review*, never directly mutate approved requirements/testcases/policies or set release readiness to ready. Capture acknowledgments and queue delivery use the existing graph history/notifications and outbox/worker substrate, backed by replay and dead-letter monitoring.
- Multi-repository/dependency scopes are configured explicitly; report `impact_incomplete` for unbound sibling repos. Historical captures are never rewritten by later source events.

### 12. Agent activity, claims and the human Change Workspace — GitLab precedent
**Existing owner:** Zyra's sessions/task/activity, graph review and native change linkage; no separate assistant/agent database. Externally connected coding agents may publish authenticated telemetry or scoped MCP calls without being granted UI-human powers.

**Evidence-level event vocabulary:**
- `tesbo_observed`: authenticated Tesbo MCP/REST operation, authorized native UI action or internally executed job with durable receipt.
- `provider_attested`: signed/authenticated repository/CI/deployment event with verifiable origin and scoped payload.
- `agent_reported`: content submitted by an agent describing work or execution not independently observed by Tesbo.
- `derived_inference`: graph/LLM analysis whose premise and confidence/limitations are inspectable.
- `unobserved`: no trustworthy observation (not a failed test, success or "agent did nothing").

Each timeline entry carries work/change/session/attempt identity, originating authenticated principal (distinct from delegated model/runtime), operation type/target/scope, source revision/build, causality parent, event time/ingestion time, retention/visibility class, redaction policy, outcome, linked evidence and explicit missing observation. Do **not** claim access to hidden chain-of-thought, uninstrumented local tool calls or secret agent prompts. Detailed traces are opt-in/permissioned; project owners can review aggregate progress without seeing restricted evidence.

**Human experience:** Reuse Tesbo project navigation and existing `Zyra` change review. A Change Workspace summarizes one change as:
1. intent/approved expectation vs proposed interpretation;
2. source diff/PR/build/deployment identities with observed/unknown markers;
3. current agent/session and task status; next responsible humans;
4. impacted requirements, cases/models, policies, manuals, files, issues and skills with version/diff status;
5. verification scope and actual results/evidence/known target;
6. blocked/unconfirmed links, risk, decision trail and pending approvals;
7. release-readiness reasons and post-deploy monitoring/incident follow-through.

The same canonical records support role-appropriate developer, solo coder, QA, BA, PM, policy/security, operations and executive views. A high-level release view must **not** reveal private document history or raw tool trace content. `Blocked`, `Awaiting approval`, `Unknown` and `Observed success` remain visibly distinct; users can drill into the proof.

### 13. Composite MCP operations and compact context — Qase precedent
**Reuse:** Existing `McpService` JSON-RPC engine/project tokens and `mcp.tools.ts`, native LegacyService, case/KB/cycle/Bug/project routines, Zyra reviewed drafts, graph history and RBAC. More tool names are not automatically better; a **small discoverable set of task-oriented operations** may improve agent reliability without duplicating native writers.

Conceptual adapters (not yet implemented):
- `get_quality_context` authoring profile (the earlier conceptual `get_project_authoring_context` is an alias, not a second owner): bounded read of permitted project scope, active governed skills, applicable approved requirement/policy references, current cases, live source binding and ability/limitation flags; pagination/cursors for large projects. Caller cannot choose a different project.
- `propose_change_bundle`: permissioned creation or revision of a Change Packet, a native requirement candidate, linked testcase candidate(s), and optional manual/task/policy applicability dispositions. Each operation explicitly records its base revision, governing skill version and approval state.
- `submit_verification_bundle`: record only actually observed run receipts/evidence against existing native cycles/executions, with independent agent report status and optional Bug candidate triage.
- `get_change_readiness`: compute linked source, case, approval, verification and risk/unknown read model without any write or implicit approval.

Tool selection/discovery should advertise capability/schema versions, permission boundaries, scoped mutation classes, size/latency budget and required manual approvals. Do **not** create an arbitrary REST escape hatch that bypasses native writers; alias and legacy endpoint paths must share authorization. Candidate staging and external handoffs can be partial and must expose `committed|failed|not_attempted|uncertain` per item. This does **not** weaken P-07: selected protected native apply is atomic within a real shared transaction or is refused before official publication. Exact duplicate commands read the logical receipt; an explicit resume uses an expected journal revision and new resume-attempt identity after readback/reauthorization. Changed intent gets an attributable new proposal revision without replaying committed logical operations. See ASER-C03–05 for the complete contract.

### 14. Cross-artifact consistency and independent truth — Spec Kit precedent
A read-only cross-artifact analyzer operates on typed **approved source obligations and their known revisions** plus code/source/graph observations, case/model links, docs, issue tasks and run evidence. Correct semantic disagreements at the owning artifact, never silently change the authoritative policy to match current code.

**Classification:** `confirmed_conflict`, `unresolved_conflict`, `missing_link`, `stale_reference`, `unknown_source`, `not_applicable`, `no_detected_issue`; the last classification means **only** that this bounded analysis found no supported discrepancy. A source diff can propose a new requirement interpretation, but it cannot itself become a normative oracle. Semantic comparisons require rationale, evidence tier, uncertainty and responsible reviewer, not a blanket LLM pass.

**Completeness boundaries:** first inventory material user goals, actors, states, interfaces, upstream/downstream consumers and negative/recovery paths. Maintain a denominator of assessed vs missing/unverified scope. All change candidates point to canonical records and existing graph; none automatically reclassifies historical executions. Report coverage separately for authored cases, approved cases, execution, deployed target validation and currently reviewed requirement revision. Re-run bounded consistency on relevant source/policy/requirement/skill head changes.

### 15. Release readiness, after-release outcomes and DORA-style metrics
**Reuse:** existing runs/executions/bugs, reports/dashboards, project releases and Graph/Zyra change review as applicable; extend one project-level role-sensitive reporting projection. Do **not** invent a new release-authority database or allow an LLM to determine whether production is "safe."

**Proposed readiness evidence dimensions:**
- source PR/commit and signed/observed target deployment identity;
- applicable current approved requirements and policies; missing or conflicting obligations;
- case candidates vs approved revisions and selected run manifest;
- actually run tests, pass/fail/block status, independent evidence bytes and environment/build;
- active high-severity Bugs, change/regression scope, unresolved impact and known exclusions;
- outstanding role approvals, rollback/forward plan, responsible human and accepted risks;
- post-deployment smoke/monitoring/incident visibility and freshness.

**Readiness vocabulary:** `not_assessed`, `insufficient_evidence`, `blocked`, `ready_for_authorized_decision`. Deployment and human decision are separate axes under ASER-C01. `released_with_known_risks` is a derived observed-release label, not a readiness value. Pre-deployment assessment uses the tested candidate build; post-deployment acceptance requires the observed deployed build. This prevents both fabricated production verification and a circular requirement for production evidence before initial deployment approval. A release authority approves a fixed readiness snapshot, candidate build and risk set. Changed evidence after approval creates a new decision context, never silently replaces the historical approval. Unknown deployment/monitoring is not marked passed.

**Five evidence-backed delivery measures:** change lead time (commit to successful production deployment), deployment frequency (qualifying successful production deployment/activation events per interval under a versioned provider-normalization rule; a later smoke failure or incident does not remove that deployed change), failed-deployment recovery time (duration to restore after a production change failure), change fail rate (qualifying failed production changes / qualifying production changes), deployment rework rate (unplanned remediation deployments / deployments, under an explicitly documented measurement rule). Source IDs, service/production-environment scope, time zone, observation window, denominator, normalization version and missing/censored data are visible. Distinguish pipeline attempts that never reached production from deployed changes that subsequently fail. Deduplicate delivery events, retain rollbacks/remediation as qualifying changes under the declared rule, and leave unresolved recovery intervals censored. Do not exclude a production failure to improve an apparent rate. These two outcome groups—throughput and instability—must not be collapsed into a misleading single score. A configured project without deployment integration gets `NO_DATA` not zero failures. Improvements in those figures do not alone establish a causal effect of Tesbo.

**Human oversight measures:** time to understand/approve a change, review cycles, unverified-agent-assertion corrections, stale-manual/requirement detection, duplicate artifact rate, incident escape and cost per synchronized change. Collect only what the user/organization authorizes, and avoid incentive gaming (e.g., fewer tests to improve apparent lead time).

### 16. Architecture invariants and release-blocking failure injections
| ID | Injection/contradiction | Expected invariant |
| --- | --- | --- |
| D-ASE-OBS-01 | Kiro hook never runs; webhook delivered later | No fabricated `synchronized` status; rescan/provider gap detects unobserved scope |
| D-ASE-OBS-02 | Duplicate/out-of-order PR and agent events | One bounded source revision identity, replay-safe graph captures |
| D-ASE-ACT-01 | Agent claims it ran tests, but no runner receipt exists | Timeline says `agent_reported`, release verdict unverified |
| D-ASE-ACT-02 | BA/QA/PM inspect same change | Common canonical IDs and independent permitted visibility |
| D-ASE-MCP-01 | Composite proposal partially fails then retries | Exact per-item receipt and zero duplicate or unauthorized publication |
| D-ASE-CONS-01 | Code implements behavior disallowed by approved policy | Conflict rather than a new, automatically approved requirement |
| D-ASE-REL-01 | PR merged, no target deploy observation | Production remains unverified and DORA deployment count unchanged |
| D-ASE-REL-02 | Smoke fails after deploy; rollback succeeds | Original CI result remains historical; incident/recovery tracked on correct build |
| D-ASE-GOV-01 | Native Copilot in owner browser session tries assigning skill | Server denies delegated action lacking exact interactive human consent |
| D-ASE-PRIV-01 | PM views general release status | No private prompt, secret, legal attachment or draft history leak |

**Minimum proof:** backend authorization/db/queue checks + real project MCP and native UI, provider event fixture, source/deploy identity, independent QA observed evidence and at least two role-specific user journeys. Executed proof and independent assurance-team review remain separate from this proposed design.

### 17. Interoperability and competitor-informed implementation limits
Kiro hooks are one optional event adapter, not a Tesbo dependency; GitLab audit methods inform evidence tiering, not imported audit authority; Qase composite tools inform MCP ergonomics, not permission shortcuts; Spec Kit analysis informs read-only semantic checks, not mandatory model-first behavior. The DORA measures are a method for measuring project outcomes, not a substitute for human release risk decisions. Reuse existing Tesbo components first, then evaluate external libraries/plugins and licenses against a proven gap.
**Primary external references:** [Kiro hooks](https://kiro.dev/docs/hooks/), [GitLab AI Governance](https://docs.gitlab.com/user/ai-governance/), [Qase MCP](https://docs.qase.io/en/articles/14984302-qase-mcp-server), [Spec Kit analysis](https://github.github.com/spec-kit/reference/agentic-sdd.html), [DORA metrics](https://dora.dev/insights/dora-metrics-history/).

**Canonical reconciliation:** the same original eight files now contain revision 1.4.28. This section is part of that proposed integration baseline; P-07 and P-18 remain unchanged. Formal freeze and runtime admission depend on the separate assurance and implementation gates.

### 18. Canonical convergence, source gaps and controlled implementation

#### 18.1 Owner and axis decision

The following is the explicit integration allocation. Existing logical canonical names do not assert that every table or API is built. Read the same current contract in canonical 03/04; historical alternatives such as a standalone `QualityImpactModule` are not instructions to create a competing owner alongside today's `behavior-graph` services.

| Truth / label | One authoritative owner and canonical work | Integration decision |
| --- | --- | --- |
| Change Packet / Change Workspace | FR-115/T-455 changeset + immutable events; FR-119/T-457 impact obligations | Packet is a composed view of `changesetId`, not another mutable completion/approval entity. Source observations may create or relate to a changeset; graph capture alone never accepts behavior. |
| Candidate and human decision | FR-027–037, T-301–306 shared staging/review/apply | Stable logical operations and immutable revisions; exact selected dependency-closed apply. A candidate is not a native Draft row. |
| Native requirements / criteria | Existing project KB identity and typed governed content, surfaced by Requirements; FR-110/112, work package A | Extend immutable submitted/accepted revision and criterion identity, never copy a second wiki. External provider requirements retain provider identity and provenance. |
| Cases / definitions / approval | Native Test Cases, existing version and approval services; T-103/104/305/430 | Extend shared principal and exact semantic revision checks across all writers. Custom fields, reference images and material relationship dependencies participate in the reviewed manifest. |
| Runs / actual attempts / results | Native Runs and execution owners; T-207/433/459 | Selection, actual observation and reviewed correction are distinct. Preserve original attempts and frozen definitions. A Bug link cannot supply execution evidence. |
| Manuals / decisions / policies | Project KB content/version owner + shared review; work package B / T-438 | Typed governed snapshots, authority and effectivity metadata; audience/exposure/authority remain independent. Ordinary draft autosave may continue. |
| Skills Library / Assignments | T-422 / D-14 QA Standards & Playbooks; FR-076/077/106–113; T-448–453 | Extend the same guide/asset identity, workspace/project bindings and one effective-method resolver. Library and assignment controls are subviews of existing settings, not a new top-level app. |
| Global pack versus local guidance | Platform-approved guide revision, workspace pin, project KB overlay | Platform authority does not live in a fake project. Reuse narrow existing bindings; a new relation is justified only for an unrepresented invariant. No per-project core copies. |
| Tasks / work / generation jobs | Existing Tasks service/shell and planned T-201/203/206/306 extensions; Bugs own defects; impacts own QA obligations | General work has a typed task identity, assignee and its own completion criteria; generation completion does not close it. Link distinct independently accepted work rather than overloading one `done` flag or copying impact state. Exact current table fit remains a source/implementation gate. |
| Files / report evidence | Existing storage, KB Files and native attachments; T-204/205/443 | Immutable references and verified bytes where available; no new upload service. Raw ingestion is not automatically authored content. |
| Typed relationship / trace | FR-118/T-426, extended with current graph/native link owners | One typed relationship owner; history pins exact revisions/occurrences. Source citations, accepted coverage mappings and observed graph edges retain distinct meanings. |
| Source binding / capture | Existing `project_source_bindings`, graph capture/history and provider adapters; T-455/456 | Extend stable binding/configuration history and multi-source capability. Preserve current server-provisioned checkout boundary and historical capture fingerprints. |
| Agent activity / session | Existing Zyra sessions/tasks/activity and authenticated receipts | Timeline is a permission-filtered projection; no separate assistant or implied record of unobserved tool use. |
| Release decision / deployment / readiness | Shared human review/audit records a typed decision; provider owns deployment facts; T-461 reports derive readiness | Fixed candidate/evidence/risk scope per decision. Readiness is computed, never another writable release-authority status. One source change may participate in several independently decided releases. |

#### 18.2 Existing substrate needs specific extensions

At the pinned input source, MCP exposes caller-supplied case status and optional row revision; native generic writers can preserve Approved, and new-run admission checks status. Dedicated approval does have CAS and a receipt, but its controller passes issuer `userId` without the machine-principal distinction. Its hash does not cover every independent custom/tag/link value. Reuse those owners and extend their shared authorization, semantic dependency manifest and final-write guards; do not call their present state universal P-07 enforcement.

Ordinary KB history coalesces edits in a 15-minute window, updates the latest cached diff and lacks a caller expected-revision condition in the inspected writer. Preserve draft autosave behavior, but create immutable submitted/accepted governed snapshots with CAS and complete semantic metadata at reliance. KB recent/folder/RAG consumers must distinguish candidate data from effective instructions; ordinary project visibility is not proof of the new classification policy. No historical exact approval or skill usage may be backfilled by guess.

The inspected MCP request chain verifies project, current membership and read/write scope, but does not establish P-18 project opt-in/named-client enforcement. T-411/T-439 must close both aliases, initialization/discovery, calls and cached-client bypasses before this integration is exposed. Existing provider event intake can remain separately authorized when external MCP is OFF; that is not an MCP bypass.

`createBug`/`addBugLink` currently reach `failLinkedExecutions`, which can change status, execution time and actor for manual/open automated runs; finalized automated runs have a narrower protection. A side-finding association must retain independent result truth. T-307/T-207/T-433 must separate association from explicitly authorized correction, including composite triage and native writers. This is a source-supported integration prerequisite, not an executed deployed defect report.

The Requirements page's linked-provider reads convert failures to empty keys/counts/tasks in the inspected source. Before that projection informs reuse/coverage/readiness, retain successful-empty versus unavailable/stale/denied/partial states at the existing owner and preserve project/request identity across responses. A failed lookup must not prompt duplicate authoring or certify zero coverage.

Current source-binding storage has one mutable project-keyed row; preserve the actual server-provisioned checkout guard while extending immutable historical identity and declared multi-source scope. Inspect migrations and all consumers before implementing the transition. The specific source anchors and independent receipts are in the existing review record, not a claim of exhaustive source/runtime assurance.

#### 18.3 Invariants and migration boundary

ASER-C01–06 in the canonical API file define state vocabulary, identity/cardinality, staged-to-native publication, immutable governed snapshots, receipt/resume, derived completion and reader/writer coverage. These contracts take precedence for this amendment's field meanings; they do not supersede unchanged P-07/P-18 or invent new model/run/guide owners.

Before enabling a governed writer, record its actual entrypoint → principal/permission → native transaction/validation → persisted revision → outbox/index/cache → read/UI/export consumers. Include imports, bulk, clone, restore, legacy endpoints, SDKs, automation, Zyra and maintenance. For each, record reuse/extension, legacy policy, positive and denied-effect tests, and rollout boundary. Unknown legacy approvals/provenance remain UNKNOWN. A read-only pilot may precede authored-domain rollout; a required manual/policy/task capability that is not yet supported remains a blocker or explicit accountable exception, not a silent I8 deferral.

Root meta-skill approval/recovery quorum, native requirement/policy/release authority assignments, narrow no-skill exceptions, retention/holds and measured operating limits remain **named policy/implementation gates**. The safe default is no governed promotion without the required authority, no script execution from a skill, and no claim beyond observed scope. No proposed rule grants an agent emergency authority. The existing task/decision record must identify the accountable human before enabling the affected action.

### Governed Skills contract within T-422

**State:** Proposed contract for specification review, not implemented. **Scope:** Tesbo project/workspace authoring governance; no change to authoritative product behavior until explicit approval and implementation.
**Relationship to existing work:** Reconciled at the logical-contract level in the same eight canonical files, revision 1.4.28, with `docs/reviews/governed-asset-evolution-reconciliation.md` (noncanonical v0.5), the eight original Tesbo canonical specs, existing Knowledge Base/versioning, case approval, Zyra and MCP. This is an ASER proposal, **not** a new ninth canonical spec, a second AI agent, or an independent skill database.

### 1. User jobs, actual categories and orthogonal axes
A human project/workspace owner assigns governed instructions to the modules and narrower contexts that agents author. Agents consult those instructions when proposing requirements, test cases, manuals, policies, tasks/issues, and files/evidence. Humans govern which instructions are active. Skills themselves are also authored under a *skills-authoring meta-skill*.

**Classification dimensions must not be conflated:**
- `module`: requirements | test_cases | user_manuals | policies | tasks_issues | files_evidence | skills.
- `subtype` within a module: requirements functional/nonfunctional/business/technical/regulatory; tests manual/automated/API/security/performance/accessibility; manuals end-user/staff/admin/support/developer/operations; policies product/business/organizational/security/regulatory/customer-facing; tasks work/bug/investigation/change; files evidence/source/test data/attachments; skills authoring/distillation/evaluation/maintenance.
- `audience`: internal, external, partner, public, mixed (multiple audience bindings allowed).
- `authority_origin`: internal decision, contractual, regulator/statute, standard, external provider; **not** synonymous with whether a policy is externally published.
- `exposure`: private/restricted/shared/public, independently governed by native authorization and information classification.
- `applicability`: workspace/project, system/module/feature, actor, operation, jurisdiction/locale, environment, phase and product domain, as supported/verified.
Examples: an internal operator manual with an external legal source; an external-facing privacy policy that is internally approved; a customer manual for administrators only. A label must not grant public access or normative authority.

### 2. Canonical owner and records
The canonical governed-guide/skill owner is **T-422 / D-14 QA Standards & Playbooks**, extended by FR-076/077/106–113 and T-448–453. One resolver serves native UI, Zyra, REST and MCP. Project-specific authored text reuses current KB document/attachment identity with an explicit immutable submitted/accepted snapshot extension. Ordinary coalesced edit history alone does not meet that invariant. The platform-approved pack and workspace pin retain their distinct scopes; no fake project or copied global core content is permitted. Add typed governance metadata and indexed assignment relations only where necessary. Never duplicate byte stores or let a graph projection become the authority.

Each **skill identity** has stable `skillId`, name, purpose, origin (native/imported), provenance, owning scope, owner, compatibility constraints and zero or more immutable version records. Each **skill version** has `skillVersionId`, parent/head reference, revision number/content digest, normative instructions, references/assets, creation actor and source evidence, supported modules/subtypes, applicability predicate, dependencies, anti-patterns, examples/counterexamples, required input/output contract, validation/evaluation evidence, and status. A newly created skill is a **candidate**, not an active instruction. Version sequence and draft-iteration sequence are distinct; rejected/abandoned candidates never become published versions.

A **skill assignment** is a *separate governed record*: `assignmentId`, exact `skillId+approvedVersionId`, target workspace/project/module/subtype/context predicate, priority or composition rule, active/inactive state, effective interval, assignment policy/approval receipt, actor and immutable history. Disabling one assignment does not delete/inactivate the underlying skill or silently disable its use in other contexts. Global skill availability, version approval, binding activation, and per-project applicability are four different facts.

An artifact revision and Change Packet record the exact **resolved effective skill set**: assignment IDs and versions, skill version IDs, digests, resolution outcome (matched/not applicable/conflict/unavailable) and timestamp/revision. A later skill or assignment change cannot rewrite historical provenance.

### 3. Authorized operations: separate creation from governance
| Operation | Agent via project MCP | Authorized interactive human |
| --- | --- | --- |
| `list_skills`/`get_skill`/read approved and allowed candidates | YES, per visibility | YES |
| `resolve_effective_skills` for its bound operation/context | YES, read-only | YES |
| `create_skill_candidate` (new identity, draft only) | YES, least-privilege | YES |
| `propose_skill_version` (successor/branch, draft only) | YES, with base-version precondition | YES |
| Alter an existing skill-version payload, including one's own submitted candidate | **NO**; create another candidate/draft-iteration record | **NO**; immutable revisions |
| Approve/publish skill candidate or its successor | **NO** | YES with separate trusted review action |
| Assign/reassign a module to a skill/version | **NO** | YES with review |
| Activate/deactivate an assignment, default, precedence or policy | **NO** | YES |
| Change meta-skill, governance constraints, trust/role policy, or revoke approvals | **NO** | Governance administrator through an authorized independent process |

**Hard boundary:** MCP bearer tokens and any agent-operable REST token must have *no mutation path* to approve, assign, activate/deactivate, retire/revoke, reorder/priority-change or edit historical skill versions, including a token issued by a human owner. A human-owned service token is not proof of interactive human assent. Publish/assignment methods require separate trusted interactive authorization and durable review receipt, including CSRF/session/re-authentication or equivalent controls appropriate to the action, plus separation of duties where policy requires. Do not rely on a client-provided `isHuman`, role name, header, review flag, or a prompt instruction.

MCP may expose only additive candidate submissions, strictly project-scoped and audited. Submitted candidates are inert for effective-skill resolution, including when an agent explicitly references their IDs. Candidate display/preview never makes them authoritative. Skill proposals may be rejected/withdrawn without deleting history. An agent may be granted access to propose skills but never to promote or route them.

### 4. Governing Skills itself: protected bootstrap
A governed **skill-authoring meta-skill** tells agents how to structure a candidate: goal, scope/trigger, reusable principle, context-specific application, required evidence, invariants, prohibited assumptions, input/output examples and counterexamples, admissible exceptions, validation/evaluation and review receipt. **Principle-based generalisation** means distilling the transferable reasoning/failure mechanism, not importing application-specific conclusions or merely accumulating incident instructions.

The root meta-skill plus its promotion rules are **human-governed and server-protected**. Changes use a separately reviewed successor with independent approver(s), version pin, executable negative fixtures and a non-self-referential trust anchor (e.g. reviewed release/security policy). An agent-created meta-skill candidate cannot validate, approve, supersede, enable or assign itself. There is no automatic `skills -> skills -> ...` recursion: resolve the designated approved root once per authoring operation; reject unresolved cycles or self-dependencies.

Projects may extend the portable core with versioned, lower-precedence project adapters. Adapters cannot relax root security, provenance, required evaluation or approval constraints. An external agent instruction (`AGENTS.md`/`CLAUDE.md`) is only a trigger; it never supersedes the server-enforced effective assignment.

### 5. Resolution, composition and changes mid-flight
The effective-skill resolver takes **server-verified** project/workspace, module/subtype, operation, audience, context/scope, current authority version and principal. It returns immutable skills in a deterministic order and an input digest. Candidate-only, inactive, expired, revoked, inaccessible, incompatible-engine or unrelated-context skills do not become active. If no skill is assigned, record `UNASSIGNED` (and refuse governed writes where the module policy requires a skill); never silently select a library "latest".

Multiple active skills are legal only when their *composition* is explicitly approved: e.g. portable testing core + project adapter + security specialization. Encode precedence, applicability, required vs optional, compatible versions and conflicts. Validate no contradictory required rules, invalid inheritance, cycles, duplicate effective owners or privilege-escalating adapter. Ambiguous matches fail closed with `SKILL_ASSIGNMENT_CONFLICT`, not arbitrary lexicographic selection.

A proposal pins the effective skill set at creation. Recheck at submission, approval and publication. If an assignment changes or a version is revoked during work, leave the candidate/revision and evidence intact; mark `SKILL_CONTEXT_STALE` and require reassessment/rebase or an independently authorized, scoped and expiring exception under actual project policy. Historical records remain bound to the versions actually used. For exceptional urgent disabling/revocation, policy defines effect on in-flight proposals, downstream agents and previously published artifacts; no silent retroactive rewrite.

### 6. Trust, confidentiality and external inputs
Read governing Skill components as *instructions only if* they come from an approved, assigned version. Imported skills, reference examples, linked files and KB content are **untrusted data**, including content that claims to be a higher-priority policy. Quarantine candidate uploads and prevent them from injecting secret-exfiltration instructions, tool calls, hidden overrides, network destinations or capability expansion into active agent contexts. A formatter or preview must not execute embedded code, scripts, HTML or untrusted tool invocations. Keep secrets out of prompts, audit and exported receipts.

Use separate authenticated project/org scope for listing, creation, reading and assignment management. A public manual or policy label must not expose private source notes or history; review access to candidate drafts and diff metadata separately. Audit actor/source, exact before/after assignment, version hash, reviewer decision, and rejected authorization attempts. Validate cache keys/ETags against project, context, assignment-head and role; invalidate on approval/assignment/revocation events. Explicitly expire offline copies.

### 7. User interface and API surface
**Skills Library**, inside existing D-14 QA Standards & Playbooks settings (not new top-level navigation): categorized search/filter by module/subtype/audience/owner; skill detail with stable ID, version timeline, source and artifacts, draft comparisons, effective usage/assignments, review status, evaluation evidence and dependencies; create-candidate and propose-next-version surfaces for permitted actors. Never make an active binding editable from the agent-facing library UI.

**Skill Assignments**, a separately permissioned subview of that same settings owner: project/workspace module rows (including manual internal/external and policy internal/external), exact pinned version, effective rules, active toggle, precedence, compatibility warnings, preview of the resolved skill set, provenance, change history, staged approval. This is human-only. Provide a clear `No active skill` state, not misleading "configured" or defaulting to draft.

**MCP proposal (not yet implemented)**: read-only `list_skills`, `get_skill`, `resolve_effective_skills`, `list_skill_versions`; additive write `create_skill_candidate`, `propose_skill_version`. No MCP assignment or promotion tools. REST/GraphQL other endpoints must also enforce this boundary server-side. Pin version/digest on `create_requirement_draft`, `create_testcase_candidate`, `propose_manual_revision`, `propose_policy_revision`, `propose_work_item`, `attach_evidence`, and Change Packets where applicable. Reuse Tesbo's existing native writer/approval services; these are conceptual contracts, not claims of current endpoint names.

**Compatibility and progress:** project tokens may currently expose broad `read/write` and some KB/case writers can save directly. Do not claim skill governance is safe by adding new MCP tools while older REST/MCP writers bypass it. Inventory every entry point and sequence enforcement rollout/migration, including existing draft/publication paths, integrations, imports, background jobs, Zyra, third-party adapters and old clients.

### 8. Evaluation and quality without self-certification
Every candidate skill should carry a testable sample set: conforming, nonconforming, adversarial input, counterexample and valid not-applicable case; version-to-version diff; expected vs observed results; who evaluated and where. Score improvements on quality and false positives, omission/novel harm, format validity, source fidelity, agent ability to comply, cost/latency and dependency drift. A candidate passing template checks is **not** proof of effectiveness. Promotion criteria and thresholds are set by governed human policy, not by the candidate itself. Held-out evaluation must not be contaminated by the authoring agent's examples; record UNKNOWN where evidence is unavailable.

### 9. Skills acceptance owner

SK-E2E-01–28 definitions are in canonical 05 revision 1.4.28; they are planned, NOT RUN.

### 10. Reconciliation/implementation gates
1. Prove reuse against prior Tesbo governed-asset evolution spec, eight canonical specs, native KB history and MCP writer surfaces, and any existing "skills" concepts. Document exact reuse/extend/new decision per invariant.
2. Preserve per-item stable identity, independent revisions, granular field/link audit and approved current state.
3. Write human-only authorization boundary **before** exposing candidate skills via MCP; test against human-owned machine tokens and alternative REST paths.
4. Implement deterministic resolver, including conflict, missing, revoked and stale paths; derive cache invalidation from actual assignment owner.
5. Integrate active-version pins and invalidation with existing Change Packet, Zyra review, graph history and notifications.
6. Add UI and accessibility support for library/version/assignment management and manual/policy subtypes, preserving current native component patterns.
7. Run backend DB/permission tests, actual UI tests, and disposable-project MCP create->read->propose->review lifecycle on same known deployment/tool catalog. No production writes for verification.
8. Independent assurance teams review this **specification**; implementation/release sign-off requires separate actual test evidence and White/Graph closeout.

### 11. Decisions needing authoritative specification review
- Exact canonical storage choice and whether current KB version snapshots can be immutable at publication without a shadow skill table.
- Approved precedence/combination grammar and rule conflict detection (machine-validatable subset vs human review for semantic contradictions).
- Whether a project is allowed to operate with no active assigned skill, and per-module default behavior.
- Human-only interactive approval design; independent authority boundaries for root-meta changes and initial bootstrap.
- Controlled migration path for existing authored cases and documents with no historical skill pin.
- Historical export/retention and allowed read visibility across workspace/global/project scopes.

### 12. Source-challenge clarifications (2026-11-18)
The specification's reviewer-operated preliminary risk record is [reviews/2026-11-18-charter-guided-spec-challenge.md](https://github.com/1alextest/Tesbooboo/blob/docs/aser-canonical-team-reconciliation-20261118/docs/specs/agent-synchronized-engineering/reviews/2026-11-18-charter-guided-spec-challenge.md). This section adds **testable corrections**, not independent team sign-off.

#### 12.1 Candidate repair without mutable history
An agent may create one new skill candidate or propose successor version under a stable skill identity; after submission, its specific content snapshot/digest is immutable. Repair requires an explicit **new candidate iteration/version proposal**, referencing its predecessor and base revision, or withdrawal/abandonment of the candidate; no overwrite of the same accepted/submitted snapshot, no fabricated published version, no duplicate skill logical identity for a retry. The UI/MCP must expose these states, provenance, revision guards, idempotency and deterministic conflict receipts. Only accepted publication increments the public version sequence.

#### 12.2 Separate Skills promotion from case/document publication

Skill approval, assignment, activation, precedence and root-meta promotion require protected human governance. Other protected artifacts follow their own native authorization and P-07 exact human review/apply. A proposal for bounded automatic asset publication is **not adopted** by this amendment and cannot override P-07. Skill resolution establishes authoring provenance; it grants no publication or execution authority. Candidate creation/ingestion, ordinary draft editing, exact human decision, native publication and case run eligibility remain separate facts. UI can combine explicitly selected permitted actions without collapsing their receipts or inventing extra mandatory ceremony.

#### 12.3 Machine-checkable rules versus semantic review
The server can enforce a deterministic rule grammar, matching, version compatibility, dependency/precedence DAG, authorization, immutable hashes and explicit required fields; it **cannot reliably decide whether every pair of free-text skills has contradictory normative meaning or malicious instructions**. Treat unsupported semantic consistency as UNKNOWN/REVIEW REQUIRED; no claim that lint, static scan or a generated safety summary proves malicious content impossible. Protect execution with provenance+review, least-privilege tools and containment, safe rendering, separate secret/tool permissions, and a controlled declassification/publishing workflow. Reject definite schema/authorization violations mechanically.

#### 12.4 Proper evidence ownership
Files that merely contain externally sourced data or raw evidence are **not necessarily authored under a Tesbo skill**. Where an agent transforms, classifies or reports on them, capture the applicable skill/assignment; otherwise mark skill `not_applicable` with an explanation and preserve independent provenance, bytes hash, chain-of-custody and inspection status. No skill association proves target runtime authenticity, evidence completeness or test passage.

#### 12.5 Root skill recovery and extraordinary operations
Initial trusted root meta-skill installation, emergency revocation, replacement, loss of all active bindings and break-glass governance need an independently authorized human recovery mechanism with durable audit, explicit scope/expiry and post-event review. No agent may create its own emergency exception, no offline writer may promote a stale binding, and no implicit "latest" assignment is an emergency fallback. The exact decision owner, approval quorum and normal/emergency behavior must be resolved from Tesbo's approved project policy before implementation.

#### 12.6 Cross-workspace access and history visibility
Sharing a skill across projects does not share all its candidate files, audit history, external references, secret source material or internal documents. Resolve effective assignments and read visibility at each scope; losing access to the parent/global skill makes affected project bindings invalid/unavailable, without fabricating a replacement. Historic version identifiers remain durable but payload and confidential metadata require original/access-policy authorization.

#### 12.7 Truthful implementation/evaluation limits
Before shipping, specify actual workload inputs (scale, peak concurrent agents, assignment fanout, dependency depth), bounded resolver/cache/dependency limits, measured response-time targets and fallback/error budgets. Do not manufacture SLO values. The first authenticated production-like disposable-project tests must include a denied admin-owned MCP approval and alternate REST route, a real interactive human promotion, and rerunning a stale agent client against the new effective assignment.

### 13. Skills within the connected delivery assurance workflow
The governed Skills Library exists to make the **entire Tesbo human-and-agent delivery lifecycle more trustworthy**. It is not itself the product's only objective or a substitute for the native requirements, QA, manual, policy and task services.

#### 13.1 Role of skill versus role of tool/event
- A **skill** prescribes a reviewed authoring/evaluation method for an applicable module, versioned and assigned only through human governance.
- An **agent hook** is an optional client-side event producer (e.g. Kiro-style task/file events), never a module-skill assignment tool, evidence of full external agent behavior or official write approval.
- A **source/CI provider event** is a scoped, separately authenticated observation of code/build/deployment state, not a request to invent requirements from observed code.
- A **composite MCP tool** invokes several native Tesbo domain actions under the same effective skills and role/approval checks; it has no elevated governance authority simply because it is one call.
- A **consistency analyzer** compares observed/inferred behavior against independently authorized requirements/policies; its output is a review candidate, not a newly approved normative source.
- A **release-readiness calculation** combines independently sourced status/evidence and human decisions, never an AI certification or automatic proof of defect-free software.

#### 13.2 Governing skill resolution in a multi-step composite workflow
Before authoring, the agent retrieves approved effective skill IDs, immutable version IDs and digests per **applicable** module and subtype. Server-side compound operations check each sub-operation's skill constraints, project scope, changed content revision and native writer. A requirements skill cannot silently govern test-case publication, and the skills-authoring meta-skill cannot override project P-07 approval, P-18 external MCP consent or actual run evidence.

A partial transaction preserves skill provenance for items that committed and leaves all other items explicitly failed, uncertain or not-attempted. An exact duplicate reads the existing logical receipt; explicit resume follows ASER-C04 and never replays committed operations. On resume, changed effective skill heads require conflict/reassessment; restoring client cache alone cannot authorize stale publication. A raw provider/agent event does not become a newly skill-authored artifact solely because it was observed.

#### 13.3 Source-package interoperability and safety boundary
Evaluate the portable [Agent Skills](https://agentskills.io/specification) `SKILL.md` format and auxiliary `references/`, `assets/` and optional `scripts/` as interchange representations rather than inventing a Tesbo-exclusive skill syntax. Library records must preserve a versioned package digest, attachment hashes, supported agent/engine capabilities and dependency/version constraints. **Executable skill resources are disabled by default** until independently authorized sandbox execution and scan/policy controls are implemented. A human approving skill text does not grant executable scripts/network/MCP tool privileges.

An imported skill is an inert candidate. It does not become active because an external agent includes it in its local context or uploads it to KB. Only explicitly approved Tesbo assignment records govern the module.

#### 13.4 Quality and learning boundaries
Compare candidate skills using held-out task fixtures, failure patterns, omission rates, evidence fidelity, false positives, human corrections and cost/latency, without letting agent-authored evaluation examples self-prove improvement. Correlate project changes with DORA throughput/instability and review effort only as a measurement **hypothesis**, never as direct proof that a specific skill reduced defects. Skill effectiveness should use actual authoring and QA outcome receipts.

#### 13.5 Skills-and-integration acceptance

SK-E2E-23–28 integration scenarios are defined with the complete Skills suite in canonical 05; no runtime pass is implied.

**Implementation boundary:** P-14 remains authoritative. Canonical revision 1.4.28 now contains these proposed contracts in the same eight files; this view is not an independent specification owner. Undecided authority/root recovery and operating policies still gate implementation. No actual MCP/REST capability or skill authority is granted by this text.

### 14. Integration of all authoring and retrieval consumers

Use ASER-C01–06 (canonical 04) for state, immutable submission, exact human review, atomic selected apply, explicit resume and raw-observation exceptions. Candidate read access is distinct from governing authority. List/get/history/search, recent/folder snapshots, RAG keyword/vector retrieval, native Zyra fallback, graph/export/report projections and caches must carry truthful server-owned authority/visibility metadata. A candidate may be inspected as untrusted data when authorized; it must not enter the effective manifest merely because it is readable, its document type is not `ai_memory`, or its text claims approval.

The global/workspace/project bindings extend the same T-422 owner and use CAS/immutable history. Approval and current assignment are independent. Snapshot digests cover the relied-on text/package and material semantic metadata, attachment hashes, dependency versions and usage manifest; metadata corrections cannot silently alter prior accepted meaning. A change of required skill blocks the affected authored candidate's promotion, while authorized raw source events and failure evidence continue under their own grants and provenance.

The existing all-writer/read-consumer inventory and the same native review transaction are release gates. This includes old endpoints, bulk/import/clone/restore, settings, jobs, integration callbacks and generated summaries; adding a new resolver alone is insufficient. Exact mapping to current role/ownership checks is explicit and deny-by-default where undecided. Required root recovery/quorum and no-active-skill exceptions must be decided by the accountable human before enabling those paths, not inferred from a candidate or an administrator-owned token.

## Revision 1.4.29 — graph reasoning and feedback over existing owners

**Proposal, not installed capability.** Extend the existing FR-115/116/117/118/119 and T-422 owners, Model Studio and native case/run/review services. No new graph, Skill, runner, approval or experiment database is implied. Existing code at the source pin supplies only its evidenced capabilities; desired future contracts below require implementation admission. Canonical 04 owns the API/security boundary, 05 owns acceptance definitions and 06 owns portable method distillation.

### GEX-01/02 extension — observe, index and reconcile without new graph ownership

Use the existing `ProjectSourceGraphCoordinator`, `project-source-binding`, `LocalPinnedGitSourceReader`, `implementation-source-verifier`, `current-cache-graph.history` and `graph-comparison-gate` as their true currently implemented owners. The present authorized capture reads pinned local Git; it is **not** an always-running local watcher or general per-project code semantic graph. Extend the existing binding/history and event/queue adapters rather than install a second graph database or alternate recording authority.

Maintain three independent origins: (A) optional working-tree event, marked provisional/possibly uncommitted; (B) authenticated repository/CI/deploy provider event bound to the original stable source-binding configuration generation; (C) server-authorized immutable pinned-Git byte capture, after binding/membership/ref revalidation. Only (C) supplies verified Git bytes; neither (A) nor (B) approves expected behavior or target test outcomes. Local watchers have explicit opt-in, scoped permission, ignore/race/debounce constraints and no ability to select server filesystem roots.

For a declared supported parser/language profile, source observations may project imports, calls, symbols, data dependencies, API/routes, event consumers and test reference declarations. Node/edge origin records project/repo/binding generation/ref/commit/tree, parser and schema version, exact file/line/digest and observed-vs-inferred classification. Handle dynamic/reflection edges as UNKNOWN, not absent. Re-index bounded changed source with dependency invalidation and periodically reconcile from the last verifiable provider/revision checkpoint; support a bounded full rebuild. Deletes/renames, changed source selections, branch rewrites, restart, missed events and unknown inventory completeness produce explicit discontinuity or gap records. No zero-impact conclusion follows from a partial index.

### GEX-03..07 extension — one implementation/behavior/evidence graph composition

**One existing set of owners; three logical views:** implementation/source observations (FR-116), human-accepted expected behavior (FR-117 Model Studio), and canonical typed relationships plus QA/evidence records (FR-118/119 and native cases/runs/tasks/bugs/files). Compose authorized reads by exact project/revision; do not store equivalent source, requirement, model, test execution or Bug facts in new independent tables. Each edge has a type/direction, originating owner and version, provenance/trust tier, lifecycle, ACL and freshness. Proposed/inferred `could_affect`, source-declared `calls` and human-accepted `maps_to_model` do not become verified `covers` edges through traversal.

**Impact:** compare only comparable source scope, follow justified direct and transitive dependency paths and bridge to a native case only through a verified/accepted mapping. Keep source-only changes and unlinked modules visible as gaps. The current `qa-review-candidates.ts` uses changed cached requirement and case references, not a general source-to-test dependency map. Tesbo's internal `scripts/test-impact.mjs` remains a separate CI selection heuristic; treat its output as comparative selection evidence, not canonical source graph truth. Optional weighted ranks need versioned rationale, calibration, and an independent missed-regression benchmark; they must not silently prune unknown, critical or policy-required tests.

**Model semantics:** reuse immutable model revisions, `ModelStudioPreview` and `model-studio-generator`. The current sequential parser rejects guards/effects, so richer guarded conditions, constrained variable/data effects, negative/recovery obligations and composable submodels need versioned syntax and deterministic safe evaluation. Model expressions are bounded inert data, never arbitrary scripts/network/credentials. Define initial/exit/shared state and model identity before cross-model traversal. Concurrent/time/distributed semantics remain unsupported unless separately proved. Proposed behavior inferred from code must not self-authorize the oracle. Bound path count, depth, state/data explosion and runtime, report incomplete exploration and preserve input/seed/strategy/digest for replay.

**Discovery and execution:** match proposed cases against native case identities and reviewed semantic basis; a model path is not a new case until human-approved native publication. Governed `run_behavior_model` dispatch creates a native Run with manifest, **not a target execution**. Reuse I3-Q's existing assigned executor/driver → original immutable report/evidence → analysis → distinct retest → human-selected apply. For model-guided execution require supported action resolver, fixture/data setup, assertion/oracle, exact tested build/environment and actual runner observation; unsupported adapters yield blocked/unverified, never fabricated Passed/Failed.

**Coverage:** key the denominator to accepted model revision, obligation (state/transition/guard/data/journey), target build, environment and relevant actor/fixture scope. Report structurally modeled, mapped, selected, attempted, independently witnessed conformant, failed, historical, stale and unknown separately. A native result alone is not verified model conformance; a previous Passed result is historical for a new source/model revision. Evidence-byte availability, actual assertion, human approval and build provenance remain independent axes. Preserve `coverageAssertion: none` until a capability-specific proof actually supports a narrower assertion. Never mutate an old attempt or auto-change a Bug-linked execution verdict.

### GEX quality and learning — manual-first execution and versioned feedback (cross-cutting proposal)

**Source-free QA first:** Tesbo must author **native manual Test Cases** when inputs are approved requirements, policies, user journeys, UI/UX descriptions, domain rules, QA interviews or genuine observed defects. Source-code dependencies, a CI selector or a manually prepared behavior model are optional. The graph derives **candidate obligations**, explores distinct positive/negative/forbidden/data/role/state/recovery scenarios and links to existing Cases/Suites, rather than creating a separate "graph test" entity. Existing FR-027–037 staging, Case Cascade, step Action/Expected Result, Markdown/Fields and human review/apply own publication. Human-executable tests require explicit setup/data, actions and observable Expected Results; this detailed output **does not** authorize scripting the independent assurance teams' discovery procedures.

**One case, several execution modes:** A native Approved Test Case revision may be executed by an authenticated human in an ordinary Run, by an authorized delegated executor/driver with its original report/evidence, or through verified CI integrations. Preserve separate attempts, actor trust classes, exact case and expected-behavior revision, target build (or UNKNOWN), actual/result, defects, optional evidence and independently governed corrections. **Human manual observation is real execution evidence without a machine receipt**; an AI's assertion of a manual action is not. Model `run_behavior_model` merely dispatches a native Run until the target is actually acted upon and an observation exists. Side findings open their own reviewable issue/case path and cannot silently turn an unrelated Passed case into Failed.

**The graph's four learning roles:** (1) deterministic reconciliation of code/UI/requirements/model/relationship changes; (2) observation-derived but **unapproved** behavior-model hypotheses, including safe optional exploratory trails and forbidden-transition questions; (3) test-design quality and pattern learning from QA accepted/rejected edits, stronger oracles, duplicates, side findings, real root causes and staleness; (4) optional, independently calibrated ranking from real defect/test outcomes, costs and risks. Reuse current graph/Model Studio, FR-118 links, FR-119 impact, native Case/Run/Bug/Task/Evidence and T-422 effective-skills governance. Proposed predictions may be query/read projections or new versioned derivation metadata only where existing owners cannot represent them: **no competing graph database, skills evaluator, oracle writer or native test runner**.

**Trust and review:** Preserve typed provenance (tenant, accepted source/revision, human observation vs authentic executor vs self-report, model/source/feature version, consent, time, correction reason, training label and evidence availability). Feed native record histories into a **propose → review → compare → adopt/reject → evaluate/rollback** cycle; never upgrade an inferred/observed implementation behavior into an approved requirement or autonomous test result, even if repeated, highly scored or model-predicted. Feedback may be wrong, flaky, biased, incomplete, privacy-restricted or circularly self-generated; therefore classification of setup/flake/confirmed bug, cold start, disputed expectations and false negatives is mandatory. Preserve original manual and automated execution receipts and declined proposals. Transfer cross-project lessons only as explicitly permitted generalized governed skills, not copied private cases or trace data.

**Test-quality and learning acceptance:** Use separate explainable dimensions for normative relevance, oracle strength, scenario novelty/uniqueness, state/role/data/forbidden/recovery coverage, human executor clarity/feasibility, actual defect discovery when evidenced, reproducibility, maintenance and accessibility. Evaluate graph gap detection on human-reviewed expected obligations, not implementation coverage alone; a 100%-covered code path may still omit a documented behavior. More high-quality cases can improve defect discovery; fewer duplicate cases can also help. A learned score or case count never grants authority to remove or skip a high-risk manual test.

**Adaptive methods are opt-in and bounded:** Start with trusted rules and human-reasoned feedback, which work from zero prior test results. ML risk prediction, active automata learning and runtime journey inference require permissioned source scope, disposable/resettable target, data/privacy review, query/time budget, tested version, model uncertainty, recorded generation settings/seed where supported, held-out human labels and separate real-fault/mutant evaluation. The resource envelope must be justified by a bounded target-specific evaluation; no method may silently run unbounded active exploration in a production application. Benchmark learned vs unlearned graph on equivalent cases; if quality decreases or false-negative rate grows, refuse promotion and retain original approved method. A "learned model" is a hypothesis, not a completed approved specification.

**Research leads:** [test-case quality](https://doi.org/10.1007/s11219-024-09698-w), [behavioral-gap preprint](https://arxiv.org/abs/2606.10417), [industrial active learning](https://doi.org/10.1007/978-3-319-25423-4_5), [ML testing review](https://doi.org/10.1002/stvr.1845), and [oracle research](https://doi.org/10.1109/TSE.2014.2372785). Verify primary-source contents and applicability before empirical claims or dependency decisions. These links do not establish implemented Tesbo efficacy.

### AI-powered graph insight with governed Skills — no new graph or approval authority (GEX-03/04/05/07/08)

**Why AI:** static graph traversal finds paths; a grounded AI analysis can ask what a relationship *means* in the user's workflow, how an upstream record reaches a downstream consumer, which roles/data/states/negative transitions matter, which approved expectation is missing, and what a **human or delegated test executor** should verify. The AI receives an **outcome brief and authorized graph context**, not a preselected bug checklist or generated conclusions, then reasons autonomously but must cite its edges, expected-behavior authority and uncertainty. Its conclusions are proposals until independently accepted. The eventual human-executable Case intentionally contains precise Action↔Expected Result steps; this is distinct from giving an independent analysis team prescribed discoveries.

**T-422 effective method composition (proposed):** Extend the existing canonical guidance owner with the specified governed Skill Library and meta-skill; verify actual implemented capabilities before invocation. The prior `manual-test-authoring` (525-line revision) covers A–H workflows, role-split/All-Roles cases, state transitions, BVA/EP/decision tables, cross-cutting concerns, permission traceability, reproducible manual steps and `IMPROVEMENTS.md`. Its source has an important contradictory rule about trusting shipped behavior over requirements; reconcile that against the accepted-oracle boundary before making it a proposed active version. The Nesberry-local `product-testing` and Primary User Type → Module → Context journey method are **candidate research inputs** with uncertain repository/commit status, not automatically installed reusable Skills. Prefer extending existing method or composing an independently justified graph-reasoning profile (e.g. `graph-qa-reasoning`) over *existing* test_cases/Requirements/Model Studio contexts, via one resolver; only create a distinct skill identity for a genuinely separate method with documented scope and precedence.

**Reasoning runtime and changeable behavior:** The **code/server** owns project scope, authentication, immutable revisions, graph schema, parser/index capability, node/edge/actor validation, execution/approval gates and tool authorization. The **effective Skill** may change how already permitted AI capabilities choose query lenses and hypotheses, analyze user context, inspect state/role/upstream/downstream relationships, choose which test technique best applies, evaluate case strength, produce manual-versus-agent scenario candidates and narrate gaps. **AI model/version** is a separately recorded execution dependency; switching it is neither an automatic skill revision nor a native graph migration. A skill must not declare a nonexistent tool, open an arbitrary network endpoint, load an unreviewed script, change a SQL query/schema or command an agent to mark an execution passed. A controlled Skill-version rollout changes behavior *within implemented contract capabilities*, without redeploying code for every wording/heuristic adjustment.

**Choose the change boundary from evidence:** Apply the [principle-first method](06_IMPLEMENTATION_AGENT_BRIEF.md#portable-method-for-discovery-and-principle-distillation) before selecting a mechanism. Where the intended behavior is exact, stable and already representable, prefer the existing deterministic contract or configuration. Where contextual interpretation is material, bounded skill-guided AI may propose useful alternatives if grounding, cost, error handling and human review fit the task. A missing parser/tool/permission needs an implementation or authority decision, not stronger prompting. Pin inputs and retain outputs for comparison; repeated LLM calls may vary even when the input manifest is unchanged.

**Minimal trusted input/output contract:** Input binds principal/project and request intent, task mode, effective Skill IDs/version hashes and composition order, known target model/source/build context when applicable, *selected authorized graph subgraph* with exact revisions and truncated/missing edge disclosure, current native Case/model/requirement IDs, explicit expected-oracle authority and resource budget. Output is a **bounded structured proposal**: testable user outcome, relevant actors/context, traceable known edges and hypothesis edges separately, lifecycle/transitions including forbidden effects, upstream and downstream ripple, candidate missing/weak conditions, existing Case matches, manual/automated execution feasibility, evidence/source links and uncertainty flags. Each fact cites a retrievable canonical owner; hallucinated links are quarantined, not auto-written. No large unrestricted raw graph dumps; use permission-filtered, selective bounded retrieval and cached snapshots with freshness.

**Learning/proposal loop:** Capture original QA corrections/rejected duplicate case reasons, actual manual/agent results, verified defect outcomes, revised model predictions and source change observations. Material changes yield an **immutable candidate skill version, graph hypothesis or native Case/model proposal**, each tied to feedback/evidence, accepted source rules and project scope. A candidate cannot promote itself, re-author its own gold labels or treat observed bad behavior as expected. Human owner decides applicability; held-out, project/temporal-split trial compares candidate/champion on missed critical scenarios, test clarity/oracle precision, semantic duplicate rate, actual defect finds where proven, downstream/negative coverage, user effort and confidentiality. Keep exact graph/prompt/LLM/Skill/evaluation versions and rollback on drift; not every local feedback item becomes a universal rule. Add no parallel experiment/run/case data store without verified absence of a suitable current record owner.

**Failure modes:** grounding absent → explicit unknown; prompt injection in source/doc/graph text → inert data and native tool constraints; excessive graph expansion → bounded partial result; stale model/Skill → revision conflict and review; contradictory effective Skills → conflict rather than arbitrary precedence; repeated low-value suggestions → detect semantic duplication and learn rejections without altering old cases; forged agent report → no human/manual result claim; output with no accepted oracle → clarification not expected-result fabrication. Source event truth, approval boundary, model-run dispatch, original evidence and P-07/P-18 permissions remain unchanged. Original independent team charters remain unchanged. The same eight canonical files receive the 1.4.29 amendment; this subordinate view does not replace them.

### Evaluation reproducibility and abstention

Pin authorized input snapshots, retrieval/tool manifests, accepted oracle, effective method versions/digests, model identifier/configuration, sampling settings where available and captured outputs. Re-evaluation can compare the same input conditions; identical language-model output is not guaranteed. A deterministic structural generator's repeatability must not be attributed to stochastic semantic analysis. Do not reconstruct inaccessible historical content or expose private material solely to reproduce a prior result.

Cold start can use ordinary approved rules and human test-design judgment. AI absence, insufficient evidence or a valid simpler mechanism must yield a truthful bounded outcome. Before adoption, compare the proposed method with the smallest adequate existing workflow and test its limits. Separate observed correlation from a claim that a method caused fewer defects. Apply the operational principles in canonical 06 through the existing governed method owner; they are not a self-activating platform pack.


## Revision 1.4.30 — bind portable guidance to Tesbo

The reusable method lives in canonical 06. The older draft discovery manifest's user-type, module and context keys are optional Tesbo lenses, not portable input requirements. Resolve actors, events, boundaries and decisions from the authorized target evidence. Preserve existing Tesbo review and activation owners. Bind approved audience and purpose to evaluation inputs and derived outputs, including across projects. Where persistent content cannot be retained, use a permitted reference or redacted receipt and surface evidence loss. Keep immutable history subject to the applicable retention and access policy.

Before admitting either candidate source Skill, pin its exact source and dependencies and reconcile its oracle guidance. Accepted requirements or policy establish normative expectations. Shipped behavior establishes observations. Contradictions require clarification or an authorized decision. For active governed guidance, define degradation signals, a responsible responder, a stop or rollback action, and a check that the fallback actually took effect.


## Revision 1.4.31 — graph contracts and assurance findings

Model dispatch resolves the active approved revision and its assignment generation in the native owner. A new draft leaves that pointer intact. The pinned latest-head-only MCP implementation is an interim limitation. Until changed and verified, do not claim dispatch of an active older revision.

Skill rollback creates a new assignment generation referencing a still-eligible immutable version. The generation is pinned to queued work and rechecked at start, resume, result delivery and protected apply. An obsolete generation cannot publish current output. Retained results are historical where permitted. Select a compatible authorized fallback or pause governed reliance. Ordinary observations remain independently retainable. Use scope-specific signals, predeclared thresholds and windows, a responder and escalation route. Verify convergence of the resolver, caches, queues and user surfaces. Reference attachments remain data even when bundled; independently approved governing components must be typed and pinned separately.

Indexes bind repository generation, durable provider cursor and extraction profile. A rebuild publishes only after a fenced compare-and-set against current generation and verified catch-up. Detect lost or stale cursors in the background and label incomplete results. Cross-profile diffs are labeled extraction changes unless both snapshots are recomputed comparably.

Coverage: bind model revision, cohort, eligible obligations and evidence stage. Report unique covered nodes, transitions, guard outcomes and a declared finite path set separately as numerator/denominator. Zero eligible obligations is N/A. Report unknown, excluded, unreachable with justification, and unexamined scope. Bound search by depth, cycle visits, states, paths and resource budget. Preserve deterministic enumeration, stop reason and frontier. AI may prioritize eligible obligations with a rationale; the engine enforces bounds and computes coverage.

Diagnosis: tie hypotheses to exact builds, attempts, edges and competing explanations. Flakiness requires mixed outcomes in a sufficiently comparable cohort with case/build/configuration/environment and retry lineage preserved; exclude or separately label infrastructure failures and sparse cohorts. Defect-risk models require point-in-time inputs, temporal holdout, baseline, calibration, precision/recall and minimum sample policy. Keep uncalibrated or insufficient-evidence results advisory and explicit.
