#!/usr/bin/env python3
"""Build the exact eight-file Tesbo v1.4.35 normative ZIP, without edits."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile


FINAL_INPUT = "input-v35-candidate3"
EXPECTED_MANIFEST_SHA256 = "346d0452c9d722869f7c1e0ef57fb5fb498aba7e646f89c3e987ee78b41c52c6"
CANONICAL_NAMES = (
    "00_README.md",
    "01_PRODUCT_REQUIREMENTS.md",
    "02_WORKFLOW_AND_UX_SPEC.md",
    "03_TECHNICAL_DESIGN.md",
    "04_MCP_API_CONTRACTS.md",
    "05_IMPLEMENTATION_BACKLOG_AND_TEST_PLAN.md",
    "06_IMPLEMENTATION_AGENT_BRIEF.md",
    "07_UI_DESIGN_TASKS.md",
)
ARCHIVE_RELATIVE = "deliverables/Tesbo_Specifications_v1.4.35.zip"
RECORD_RELATIVE = "verification/final-artifact-inputs.json"
FIXED_ZIP_TIME = (2026, 11, 19, 0, 0, 0)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def safe_relative(value: str) -> str:
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or path.as_posix() != value:
        raise ValueError(f"Unsafe or noncanonical relative path: {value!r}")
    return value


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f".{path.name}.", delete=False) as tmp:
        temp_path = Path(tmp.name)
        tmp.write(data)
    try:
        temp_path.chmod(0o644)
        temp_path.replace(path)
    finally:
        temp_path.unlink(missing_ok=True)


def verify_snapshot(root: Path, directory: str, expected_manifest_sha256: str | None = None) -> dict:
    snapshot = root / safe_relative(directory)
    manifest_path = snapshot / "manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    manifest_hash = sha256(manifest_bytes)
    if expected_manifest_sha256 is not None and manifest_hash != expected_manifest_sha256:
        raise ValueError(f"Manifest identity mismatch: {directory}")
    manifest = json.loads(manifest_bytes)
    rows = manifest["files"]
    paths = [safe_relative(row["path"]) for row in rows]
    if len(paths) != len(set(paths)):
        raise ValueError(f"Duplicate paths in {directory}/manifest.json")
    actual_files = set()
    for item in snapshot.rglob("*"):
        if item.is_symlink():
            raise ValueError(f"Symlink not allowed in frozen snapshot: {item}")
        if item.is_file():
            actual_files.add(item.relative_to(snapshot).as_posix())
    expected_files = set(paths) | {"manifest.json"}
    if actual_files != expected_files:
        raise ValueError(f"Unexpected snapshot file set for {directory}: {sorted(actual_files ^ expected_files)}")
    checked = []
    for row in rows:
        data = (snapshot / row["path"]).read_bytes()
        actual = {"path": row["path"], "bytes": len(data), "sha256": sha256(data)}
        if actual["bytes"] != row["bytes"] or actual["sha256"] != row["sha256"]:
            raise ValueError(f"Frozen input byte mismatch: {directory}/{row['path']}")
        checked.append(actual)
    return {
        "directory": directory,
        "manifest": {"path": f"{directory}/manifest.json", "bytes": len(manifest_bytes), "sha256": manifest_hash},
        "file_count": len(checked),
        "payload_bytes": sum(row["bytes"] for row in checked),
        "files": checked,
    }


def build_archive_bytes(root: Path, final_input: str = FINAL_INPUT, expected_manifest_sha256: str = EXPECTED_MANIFEST_SHA256) -> tuple[bytes, dict, list[dict]]:
    snapshot = verify_snapshot(root, final_input, expected_manifest_sha256)
    canonical_rows = [row for row in snapshot["files"] if row["path"].startswith("canonical/")]
    if sorted(row["path"] for row in canonical_rows) != [f"canonical/{name}" for name in CANONICAL_NAMES]:
        raise ValueError("The final input must contain exactly the eight named canonical Markdown files")
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.comment = b""
        for name in CANONICAL_NAMES:
            info = zipfile.ZipInfo(name, date_time=FIXED_ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.extra = b""
            info.comment = b""
            archive.writestr(info, (root / final_input / "canonical" / name).read_bytes(), compresslevel=9)
    archive_bytes = output.getvalue()
    canonical = []
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        if archive.namelist() != list(CANONICAL_NAMES) or archive.testzip() is not None:
            raise ValueError("ZIP member or CRC verification failed")
        for name in CANONICAL_NAMES:
            data = archive.read(name)
            if data != (root / final_input / "canonical" / name).read_bytes():
                raise ValueError(f"ZIP input byte mismatch: {name}")
            canonical.append({"path": name, "input_path": f"{final_input}/canonical/{name}", "bytes": len(data), "sha256": sha256(data)})
    return archive_bytes, snapshot, canonical


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--version", default="1.4.35")
    parser.add_argument("--input", default=FINAL_INPUT)
    parser.add_argument("--manifest-sha256", default=EXPECTED_MANIFEST_SHA256)
    parser.add_argument("--record", help="Override the artifact-record relative path; later versions default to a versioned record")
    args = parser.parse_args()
    root = args.workspace.resolve()
    archive_relative = safe_relative(f"deliverables/Tesbo_Specifications_v{args.version}.zip")
    record_relative = safe_relative(args.record or (RECORD_RELATIVE if args.version == "1.4.35" else f"verification/final-artifact-inputs-v{args.version}.json"))
    archive_bytes, snapshot, canonical = build_archive_bytes(root, args.input, args.manifest_sha256)
    archive_record = {
        "path": archive_relative,
        "bytes": len(archive_bytes),
        "sha256": sha256(archive_bytes),
        "member_count": len(canonical),
        "uncompressed_member_bytes": sum(row["bytes"] for row in canonical),
    }
    record = {
        "record_kind": "Deterministic artifact assembly and exact-byte verification; not an assurance signatory or runtime acceptance",
        "revision": args.version,
        "input": snapshot,
        "normative_file_count": len(canonical),
        "normative_file_bytes": sum(row["bytes"] for row in canonical),
        "canonical_files": canonical,
        "archive": archive_record,
        "recipe": {
            "script": "verification/build_specifications_archive.py",
            "member_order": "CANONICAL_NAMES in numeric filename order",
            "member_paths": "Exactly eight Markdown files at ZIP root; no directories or extra files",
            "timestamp": "2026-11-19T00:00:00; fixed ZIP metadata, not a claim about source creation time",
            "mode": "regular file 0644; Unix creator; empty comments and extra fields",
            "compression": "Python standard-library ZIP_DEFLATED, compression level 9",
        },
        "checks": {
            "final_manifest_matches_required_sha256": True,
            "every_manifest_record_matches_exact_input_bytes": True,
            "snapshot_has_no_unlisted_files": True,
            "exactly_eight_canonical_markdown_files": True,
            "zip_members_match_input_bytes": True,
            "zip_crc_valid": True,
        },
    }
    atomic_write(root / archive_relative, archive_bytes)
    atomic_write(root / record_relative, json_bytes(record))
    print(json.dumps({"archive": archive_record, "record": record_relative, "record_sha256": sha256(json_bytes(record))}, indent=2))


if __name__ == "__main__":
    main()
