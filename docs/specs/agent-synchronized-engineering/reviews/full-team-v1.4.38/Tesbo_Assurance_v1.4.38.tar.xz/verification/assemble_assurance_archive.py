#!/usr/bin/env python3
"""Deterministically assemble Tesbo review evidence; never change its inputs."""

from __future__ import annotations

import argparse
import io
import json
import lzma
from pathlib import Path
import tarfile

from build_specifications_archive import (
    ARCHIVE_RELATIVE as SPECIFICATIONS_ARCHIVE,
    CANONICAL_NAMES,
    EXPECTED_MANIFEST_SHA256,
    FINAL_INPUT,
    atomic_write,
    build_archive_bytes,
    json_bytes,
    safe_relative,
    sha256,
    verify_snapshot,
)


ORIGINAL_WORKSPACE = "/workspace/scratch/40f0abd3bdbc"
REPORT = "publish/2026-11-19-full-team-continuation.md"
ARCHIVE = "deliverables/Tesbo_Assurance_v1.4.35.tar.xz"
DETACHED_MANIFEST = "verification/assurance-archive-inputs.json"
PLAN = "verification/assurance-archive-plan.json"
README_TEMPLATE = "verification/assurance-archive-README.md"
EXPECTED_SNAPSHOTS = {
    "input-v30": "ae3db8d23eb916c1b6f403050d073ca6c6a95aad506e7b4a4bfacc100eb004ed",
    "input-v31": "b628462508a61355954bc3701142b7ca5e244c73fc622bb8407f7f1886734c0a",
    "input-v31-candidate2": "6a7c4604a53ab86be8a864e1feef7a1c9fd7983482148e34e86c881cc548694c",
    "input-v31-candidate3": "7af22eba9961a157916cdcca8cd1692ddf6848df4c75342bda00fc8f95bb7804",
    "input-v32-candidate1": "4f406b91251b85b2cd0def05fef9ce950481daa6b7b030762aed49998ac747f9",
    "input-v32-candidate2": "e531935a62da0cabe61085f9f21696e8c2ab5a2c8a6a6f80fc4cbd68995ad9c0",
    "input-v35-candidate1": "b5cb419188c3525c6a8bef56aba3beb57e0bacb13f3ce5783f4d44b94df1203d",
    "input-v35-candidate2": "311423fa8cdafc3c94d9a6df62280ec9c6fcf7e350583ad46c15cbe757362a82",
    "input-v35-candidate3": "346d0452c9d722869f7c1e0ef57fb5fb498aba7e646f89c3e987ee78b41c52c6",
    "baseline-latest": "441fad307dfa4235785aad43fe9d852f9781ef1a3de466460da266f71b9d9db3",
}
VIEW_NAMES = (
    "AGENT_RULE_TEMPLATE.md", "README.md", "design.md", "implementation-plan.md",
    "requirements.md", "skills-governance.md",
)
METHOD_MANIFESTS = (
    "method-inputs/manifest.json",
    "method-inputs/repository-d83549c8/manifest.json",
    "method-source-supplement/manifest.json",
    "method-source-supplement/graph-indirect-manifest.json",
    "verification/method-charter-source-manifest.json",
)
REQUIRED_VERIFICATION = (
    "README.md",
    "source419-scope-note.md",
    "verify_spec_package.py",
    "verify_spec_package_v2.py",
    "verify_spec_package_v3.py",
    "build_specifications_archive.py",
    "assemble_assurance_archive.py",
    "candidate1-document-check.json",
    "candidate2-document-check.json",
    "candidate3-document-check.json",
    "candidate32-document-check.json",
    "candidate32-final-document-check.json",
    "candidate35-final-delta.json",
    "candidate35-final-document-check.json",
    "candidate35-final2-document-check.json",
    "candidate35-final3-delta.json",
    "candidate35-final3-document-check.json",
    "canonical-library-reconciliation.json",
    "canonical-link-audit.json",
    "commit-citation-rule-reproduction.json",
    "early-view-copy-provenance-correction.json",
    "elephant-invocation.json",
    "final-artifact-inputs.json",
    "graph-v32-charter-integrity.json",
    "graph-v32-document-check.json",
    "graph-v32-input-integrity.json",
    "green-document-check.json",
    "green-supplement-check.json",
    "green-v32-final-document-check.json",
    "green-v35-candidate1-document-check.json",
    "green-v35-document-check.json",
    "implementation-ci-b07-observation.json",
    "implementation-ci-e3d0-observation.json",
    "implementation-e3-to-b07-comparison.json",
    "implementation-tree-419c2efa.json",
    "implementation-tree-b07def32.json",
    "implementation-tree-e3d0ebcb.json",
    "incoming34-ac49-preservation-check.json",
    "initial-v31-structure.json",
    "merge35-ledger-initial.json",
    "merge35-resolution-ledger.json",
    "method-charter-source-manifest.json",
    "remote-ac49-b07-inputs.json",
    "remote-delta-inputs.json",
    "remote-impl-compare.json",
    "remote-reconciliation-ledger.json",
    "remote-spec-compare.json",
    "security-v32-document-check.json",
    "security-v32-source-integrity.json",
    "source419-frontend-manifest.json",
    "source419-manifest.json",
    "working-document-check.json",
    "working-v32-document-check.json",
    "working-v35-document-check.json",
)
OPTIONAL_VERIFICATION_GLOBS = (
    "graph-v35-*.json", "white-v35-*.json", "green-v35-*.json",
    "documentation-ci-*-observation.json",
)
PROHIBITED_PREFIXES = (
    "source419/", "source419-frontend/", "source-b07-delta/", "source-e3d0-delta/",
    "library-helper/", ".codex/", "working/", "working35/", "merge35/",
    "method-inputs/repository-d83549c8/product-testing/", "method-source-supplement/docs/",
)
SPECIFICATIONS_RECORD = "verification/final-artifact-inputs.json"
ADDITIONAL_BASELINES: list[str] = []
ADDITIONAL_VERIFICATION: list[str] = []
ASSEMBLY_CONFIGURATION: dict = {}


def member_row(path: str, data: bytes, source: str | None = None) -> dict:
    row = {"path": path, "bytes": len(data), "sha256": sha256(data)}
    if source:
        row["original_absolute_path"] = f"{ORIGINAL_WORKSPACE}/{source}"
    else:
        row["origin"] = "Generated deterministically by the evidence assembly script"
    return row


def collect_payload(root: Path) -> tuple[dict[str, bytes], dict[str, str | None], dict]:
    payload: dict[str, bytes] = {}
    origins: dict[str, str | None] = {}

    def add(relative: str, archive_name: str | None = None) -> None:
        relative = safe_relative(relative)
        archive_name = safe_relative(archive_name or relative)
        if relative.startswith(PROHIBITED_PREFIXES):
            raise ValueError(f"Excluded source body or workspace content selected: {relative}")
        path = root / relative
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Expected a regular evidence file: {relative}")
        data = path.read_bytes()
        if archive_name in payload and payload[archive_name] != data:
            raise ValueError(f"Conflicting member selection: {archive_name}")
        payload[archive_name] = data
        origins[archive_name] = relative

    snapshots = []
    for directory, expected in EXPECTED_SNAPSHOTS.items():
        checked = verify_snapshot(root, directory, expected)
        snapshots.append({key: value for key, value in checked.items() if key != "files"})
        for row in checked["files"]:
            add(f"{directory}/{row['path']}")
        add(f"{directory}/manifest.json")

    baseline_paths = [f"baseline-v34/canonical/{name}" for name in CANONICAL_NAMES]
    baseline_paths += [f"baseline-v34/views/{name}" for name in VIEW_NAMES]
    actual_baseline = {p.relative_to(root).as_posix() for p in (root / "baseline-v34").rglob("*") if p.is_file()}
    if actual_baseline != set(baseline_paths):
        raise ValueError("baseline-v34 does not contain exactly its eight canonical and six view files")
    for relative in baseline_paths:
        add(relative)
    additional_baseline_paths = []
    for directory in ADDITIONAL_BASELINES:
        if not directory.startswith("baseline-") or "/" in directory:
            raise ValueError("Additional baseline must be a top-level baseline-* directory")
        paths = [f"{directory}/canonical/{name}" for name in CANONICAL_NAMES]
        paths += [f"{directory}/views/{name}" for name in VIEW_NAMES]
        if (root / directory / "manifest.json").is_file():
            paths.append(f"{directory}/manifest.json")
        for relative in paths:
            add(relative)
        additional_baseline_paths.extend(paths)

    for directory in ("receipts", "prior-receipts"):
        paths = sorted((root / directory).glob("*"))
        if not paths:
            raise ValueError(f"Required receipt directory is empty: {directory}")
        for path in paths:
            if not path.is_file() or path.suffix not in (".md", ".json"):
                raise ValueError(f"Unexpected item in receipt directory: {path.name}")
            add(path.relative_to(root).as_posix())

    for filename in REQUIRED_VERIFICATION:
        add(f"verification/{filename}")
    add(SPECIFICATIONS_RECORD)
    for relative in ADDITIONAL_VERIFICATION:
        if not relative.startswith("verification/") or Path(relative).suffix not in (".json", ".md", ".py", ".diff"):
            raise ValueError("Additional verification input must be an explicitly named verification record or script")
        add(relative)
    for pattern in OPTIONAL_VERIFICATION_GLOBS:
        for path in sorted((root / "verification").glob(pattern)):
            add(path.relative_to(root).as_posix())
    for relative in METHOD_MANIFESTS:
        add(relative)
    add("method-inputs/README.md")
    add(REPORT)
    readme_source = README_TEMPLATE if (root / README_TEMPLATE).is_file() else "README.md"
    add(readme_source, "README.md")
    # Retain the historical source path even when rebuilding from an extracted archive.
    origins["README.md"] = README_TEMPLATE

    correction = json.loads(payload["verification/early-view-copy-provenance-correction.json"])
    for row in correction["files"]:
        relative = f"remote-264380/views/{row['file']}"
        add(relative)
        remote = payload[relative]
        reviewed = payload[f"input-v30/views/{row['file']}"]
        if sha256(remote) != row["exact_remote_sha256"] or sha256(reviewed) != row["review_input_sha256"] or reviewed != remote + b"\n":
            raise ValueError(f"Recorded terminal-LF correction does not reproduce: {row['file']}")

    remote_entries = json.loads(payload["verification/remote-ac49-b07-inputs.json"])
    for entry in remote_entries:
        if entry["path"].startswith("remote-ac49/reviews/"):
            add(entry["path"])
            data = payload[entry["path"]]
            if len(data) != entry["bytes"] or sha256(data) != entry["sha256"]:
                raise ValueError(f"Incoming review identity mismatch: {entry['path']}")
    for entry in remote_entries:
        if entry["path"].startswith("remote-ac49/") and "/reviews/" not in entry["path"]:
            data = payload[f"baseline-v34/views/{Path(entry['path']).name}"]
            if len(data) != entry["bytes"] or sha256(data) != entry["sha256"]:
                raise ValueError(f"Parent ac49 view identity mismatch: {entry['path']}")

    charter_manifest = payload["verification/method-charter-source-manifest.json"]
    if sha256(charter_manifest) != "9b6b125d3eee2738f07d89c6a1c8bd6df04e9558a295682a821dac92087c7b2f":
        raise ValueError("Recovered method identity manifest changed")

    artifact_record = json.loads(payload[SPECIFICATIONS_RECORD])
    expected_archive, _, _ = build_archive_bytes(root, FINAL_INPUT, EXPECTED_MANIFEST_SHA256)
    if artifact_record["archive"]["sha256"] != sha256(expected_archive) or artifact_record["archive"]["bytes"] != len(expected_archive):
        raise ValueError("Canonical artifact record no longer matches reproducible final ZIP")
    if artifact_record["input"]["manifest"]["sha256"] != EXPECTED_MANIFEST_SHA256:
        raise ValueError("Canonical artifact record targets the wrong frozen input")
    if (root / SPECIFICATIONS_ARCHIVE).exists() and (root / SPECIFICATIONS_ARCHIVE).read_bytes() != expected_archive:
        raise ValueError("Existing normative ZIP differs from its deterministic reconstruction")

    final_manifest = json.loads(payload[f"{FINAL_INPUT}/manifest.json"])
    identities = {
        "record_kind": "Assembly-derived identity index; original source manifests remain unchanged",
        "original_workspace": ORIGINAL_WORKSPACE,
        "final_input": FINAL_INPUT,
        "final_input_manifest_sha256": EXPECTED_MANIFEST_SHA256,
        "frozen_snapshot_manifests": snapshots,
        "baseline_v34": {
            "identity_kind": "Assembly-derived listing of preserved baseline files, not a pre-existing review manifest",
            "canonical_revision": "1.4.34",
            "parent_library_version": 14,
            "parent_archive_sha256": "ac55077842806781223c83c64869b2f55a992155ec12bb9ae4689459961f11f9",
            "subordinate_view_parent": "ac49fa64d87723c9c1be4491a6fe06c7672e3af6",
            "files": [member_row(path, payload[path], path) for path in sorted(baseline_paths)],
        },
        "final_input_metadata": {key: value for key, value in final_manifest.items() if key != "files"},
        "additional_baseline_files": [member_row(path, payload[path], path) for path in sorted(additional_baseline_paths)],
        "source_and_method_manifests": [member_row(path, payload[path], path) for path in sorted(set(METHOD_MANIFESTS) | {
            "verification/source419-manifest.json", "verification/source419-frontend-manifest.json",
            "verification/remote-delta-inputs.json", "verification/remote-ac49-b07-inputs.json",
            "verification/implementation-tree-419c2efa.json", "verification/implementation-tree-e3d0ebcb.json",
            "verification/implementation-tree-b07def32.json",
        })],
        "original_method_manifest": {
            "absolute_path": "/workspace/scratch/ce8c3109f396/assurance-source-recovery/verified-source-manifest.json",
            "archive_path": "verification/method-charter-source-manifest.json",
            "sha256": sha256(charter_manifest),
            "bytes": len(charter_manifest),
        },
        "omitted_bodies": "Application source, private method-source bodies, full third-party charters and playbooks, raw CI logs, helpers, credentials and tool stores are not archive payloads",
    }
    payload["SOURCE-IDENTITIES.json"] = json_bytes(identities)
    origins["SOURCE-IDENTITIES.json"] = None
    return payload, origins, identities


def completion_record(args: argparse.Namespace, payload: dict[str, bytes]) -> dict | None:
    if not args.freeze:
        return None
    if args.completion_file:
        completion = json.loads(args.completion_file.read_bytes())
        if completion["candidate_manifest_sha256"] != EXPECTED_MANIFEST_SHA256:
            raise ValueError("Completion file targets a different candidate")
        report = completion["report"]
        receipt_rows = completion["final_receipts"]
        if {row["assembly_input_label"] for row in receipt_rows} != {"White", "Graph"} or len(receipt_rows) != 2:
            raise ValueError("Completion file must bind exactly one White and one Graph receipt input")
    else:
        if not (args.white_receipt and args.graph_receipt and args.report_sha256):
            raise ValueError("Final assembly requires completed White/Graph receipt paths and the exact report SHA-256, or --completion-file")
        report = {"path": REPORT, "sha256": args.report_sha256}
        receipt_rows = []
        for label, path in (("White", args.white_receipt), ("Graph", args.graph_receipt)):
            path = safe_relative(path)
            if not path.startswith("receipts/") or path not in payload:
                raise ValueError(f"Final {label} receipt is not a selected receipt member")
            receipt_rows.append({"assembly_input_label": label, **member_row(path, payload[path], path)})
        completion = {
            "record_kind": "Coordinator-designated completed inputs for artifact assembly; not an assurance sign-off",
            "candidate_manifest_sha256": EXPECTED_MANIFEST_SHA256,
            "assembly_configuration": ASSEMBLY_CONFIGURATION,
            "report": {**report, "bytes": len(payload[REPORT])},
            "final_receipts": receipt_rows,
        }
    if report["path"] != REPORT or sha256(payload[REPORT]) != report["sha256"]:
        raise ValueError("The report bytes changed or do not match the coordinator's completion input")
    if len({row["path"] for row in receipt_rows}) != 2:
        raise ValueError("White and Graph must bind distinct receipt files")
    for row in receipt_rows:
        path = safe_relative(row["path"])
        if not path.startswith("receipts/") or path not in payload or sha256(payload[path]) != row["sha256"] or len(payload[path]) != row["bytes"]:
            raise ValueError(f"Final receipt bytes changed: {path}")
    return completion


def manifest_payload(payload: dict[str, bytes], origins: dict[str, str | None]) -> dict:
    rows = [member_row(path, payload[path], origins[path]) for path in sorted(payload)]
    return {
        "record_kind": "Exact payload-member index; MANIFEST.json itself is covered by the detached all-member manifest",
        "final_input": FINAL_INPUT,
        "final_input_manifest_sha256": EXPECTED_MANIFEST_SHA256,
        "payload_member_count": len(rows),
        "payload_bytes": sum(row["bytes"] for row in rows),
        "manifest_self_hash": f"Excluded to avoid an impossible self-referential hash; use {DETACHED_MANIFEST} for every archive member",
        "files": rows,
    }


def encode_archive(payload: dict[str, bytes]) -> bytes:
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        for path in sorted(payload):
            safe_relative(path)
            data = payload[path]
            member = tarfile.TarInfo(path)
            member.size = len(data)
            member.mode = 0o644
            member.uid = member.gid = 0
            member.uname = member.gname = ""
            member.mtime = 0
            archive.addfile(member, io.BytesIO(data))
    return lzma.compress(output.getvalue(), format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=9)


def verify_archive(data: bytes, expected: dict[str, bytes] | None = None) -> dict:
    members = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:xz") as archive:
        names = archive.getnames()
        if names != sorted(names) or len(names) != len(set(names)):
            raise ValueError("Archive member order or uniqueness violation")
        for member in archive.getmembers():
            safe_relative(member.name)
            if not member.isfile() or member.mode != 0o644 or member.uid or member.gid or member.mtime or member.uname or member.gname:
                raise ValueError(f"Unexpected tar metadata: {member.name}")
            stream = archive.extractfile(member)
            assert stream is not None
            members[member.name] = stream.read()
    manifest = json.loads(members["MANIFEST.json"])
    indexed = {row["path"]: row for row in manifest["files"]}
    if set(indexed) != set(members) - {"MANIFEST.json"}:
        raise ValueError("Internal manifest does not cover exactly every non-self member")
    for path, row in indexed.items():
        if sha256(members[path]) != row["sha256"] or len(members[path]) != row["bytes"]:
            raise ValueError(f"Archive member checksum mismatch: {path}")
    if expected is not None and members != expected:
        raise ValueError("Archive members differ from the exact assembly inputs")
    return {
        "archive_bytes": len(data),
        "archive_sha256": sha256(data),
        "member_count": len(members),
        "member_bytes": sum(map(len, members.values())),
        "every_member_verified": True,
    }


def main() -> None:
    global FINAL_INPUT, EXPECTED_MANIFEST_SHA256, REPORT, ARCHIVE, DETACHED_MANIFEST, PLAN
    global README_TEMPLATE, SPECIFICATIONS_RECORD, SPECIFICATIONS_ARCHIVE
    global ADDITIONAL_BASELINES, ADDITIONAL_VERIFICATION, ASSEMBLY_CONFIGURATION
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parents[1])
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--plan", action="store_true", help="List and optionally estimate the current selection; write no final archive")
    modes.add_argument("--freeze", action="store_true", help="Assemble after the coordinator confirms White, Graph and report completion")
    modes.add_argument("--verify-archive", type=Path)
    parser.add_argument("--estimate-size", action="store_true", help="Compress a planning preview in memory; never save that preview archive")
    parser.add_argument("--white-receipt")
    parser.add_argument("--graph-receipt")
    parser.add_argument("--report-sha256")
    parser.add_argument("--completion-file", type=Path)
    parser.add_argument("--version", default="1.4.35")
    parser.add_argument("--final-input", default=FINAL_INPUT)
    parser.add_argument("--final-manifest-sha256", default=EXPECTED_MANIFEST_SHA256)
    parser.add_argument("--report", default=REPORT)
    parser.add_argument("--readme-template", default=README_TEMPLATE, help="For a changed version, provide a reviewed README describing that version")
    parser.add_argument("--specifications-record")
    parser.add_argument("--include-snapshot", action="append", default=[], metavar="DIRECTORY=SHA256")
    parser.add_argument("--include-baseline", action="append", default=[], metavar="DIRECTORY")
    parser.add_argument("--include-verification", action="append", default=[], metavar="RELATIVE_PATH")
    args = parser.parse_args()
    if args.verify_archive:
        print(json.dumps(verify_archive(args.verify_archive.read_bytes()), indent=2))
        return
    if args.completion_file:
        stored_configuration = json.loads(args.completion_file.read_bytes()).get("assembly_configuration", {})
        for key, value in stored_configuration.items():
            setattr(args, key, value)
    FINAL_INPUT = safe_relative(args.final_input)
    EXPECTED_MANIFEST_SHA256 = args.final_manifest_sha256
    REPORT = safe_relative(args.report)
    README_TEMPLATE = safe_relative(args.readme_template)
    if args.version != "1.4.35" and README_TEMPLATE == "verification/assurance-archive-README.md":
        raise ValueError("A new archive version requires --readme-template for that version, preserving the historical v1.4.35 README")
    SPECIFICATIONS_RECORD = safe_relative(args.specifications_record or ("verification/final-artifact-inputs.json" if args.version == "1.4.35" else f"verification/final-artifact-inputs-v{args.version}.json"))
    SPECIFICATIONS_ARCHIVE = safe_relative(f"deliverables/Tesbo_Specifications_v{args.version}.zip")
    ARCHIVE = safe_relative(f"deliverables/Tesbo_Assurance_v{args.version}.tar.xz")
    DETACHED_MANIFEST = "verification/assurance-archive-inputs.json" if args.version == "1.4.35" else f"verification/assurance-archive-inputs-v{args.version}.json"
    PLAN = "verification/assurance-archive-plan.json" if args.version == "1.4.35" else f"verification/assurance-archive-plan-v{args.version}.json"
    for item in args.include_snapshot:
        directory, separator, digest = item.partition("=")
        if not separator or not directory.startswith(("input-", "baseline-")) or "/" in directory or len(digest) != 64:
            raise ValueError("Additional snapshot must be an input-* or baseline-* DIRECTORY=SHA256 binding")
        EXPECTED_SNAPSHOTS[safe_relative(directory)] = digest
    EXPECTED_SNAPSHOTS[FINAL_INPUT] = EXPECTED_MANIFEST_SHA256
    ADDITIONAL_BASELINES = args.include_baseline
    ADDITIONAL_VERIFICATION = args.include_verification
    ASSEMBLY_CONFIGURATION = {key: getattr(args, key) for key in (
        "version", "final_input", "final_manifest_sha256", "report", "readme_template", "specifications_record",
        "include_snapshot", "include_baseline", "include_verification",
    )}
    root = args.workspace.resolve()
    payload, origins, identities = collect_payload(root)
    completion = completion_record(args, payload)
    if completion is not None:
        payload["ASSEMBLY-COMPLETION.json"] = json_bytes(completion)
        origins["ASSEMBLY-COMPLETION.json"] = None
    internal_manifest = manifest_payload(payload, origins)
    payload["MANIFEST.json"] = json_bytes(internal_manifest)
    origins["MANIFEST.json"] = None
    all_members = [member_row(path, payload[path], origins[path]) for path in sorted(payload)]
    record = {
        "record_kind": "Final archive byte verification" if args.freeze else "Planning selection only; final evidence archive has not been written by this invocation",
        "final_input": FINAL_INPUT,
        "final_input_manifest_sha256": EXPECTED_MANIFEST_SHA256,
        "archive_path": ARCHIVE,
        "archive_written": args.freeze,
        "member_count": len(all_members),
        "uncompressed_member_bytes": sum(row["bytes"] for row in all_members),
        "snapshot_manifest_count": len(identities["frozen_snapshot_manifests"]),
        "all_member_manifest_includes_internal_manifest": True,
        "files": all_members,
    }
    if args.freeze or args.estimate_size:
        archive_bytes = encode_archive(payload)
        checked = verify_archive(archive_bytes, payload)
        if args.freeze:
            record["archive"] = checked
            atomic_write(root / ARCHIVE, archive_bytes)
            atomic_write(root / DETACHED_MANIFEST, json_bytes(record))
            print(json.dumps({key: value for key, value in record.items() if key != "files"}, indent=2))
            print(f"Detached all-member manifest: {DETACHED_MANIFEST}; SHA-256 {sha256(json_bytes(record))}")
            return
        record["planning_preview"] = {
            "compressed_bytes_for_current_selection": checked["archive_bytes"],
            "all_preview_members_verified": True,
            "preview_archive_persisted": False,
            "scope": "Size estimate for currently available report/receipts; completed final inputs may change this size",
        }
    atomic_write(root / PLAN, json_bytes(record))
    print(json.dumps({key: value for key, value in record.items() if key != "files"}, indent=2))


if __name__ == "__main__":
    main()
