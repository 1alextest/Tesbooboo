# Additional current frontend source binding

The original `source419-manifest.json` labels its intended selection as frontend/src, but the Tesbo repository uses `Tesbo-Frontend/`; the original 611-file cache contains no frontend files. Its individual hashes remain correct. Preserve the original manifest for review reproducibility.

A separate supplement now materializes all 261 blobs under `Tesbo-Frontend/` from remote tree `419c2efa08b04aff6c7c7d0d56425eb572bd6ec2` in `source419-frontend/`. `source419-frontend-manifest.json` records the exact path, bytes, Git blob and SHA-256 for every file; all were verified and the missing list is empty. This is source evidence from an open PR, not a running or deployed UI. Earlier source reads at base6897 retain their original scope.
