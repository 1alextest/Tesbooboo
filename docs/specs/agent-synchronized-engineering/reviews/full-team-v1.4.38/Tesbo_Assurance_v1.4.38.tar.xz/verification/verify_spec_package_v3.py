"""Tesbo document verification binding v3; no product/runtime or semantic-proof claim."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def headings(text):
    counts = Counter()
    anchors = set(re.findall(r'<a\s+(?:name|id)=["\']([^"\']+)', text))
    in_fence = False
    for line in text.splitlines():
        if line.lstrip().startswith(('```', '~~~')):
            in_fence = not in_fence
        if in_fence:
            continue
        match = re.match(r'^#{1,6}\s+(.+?)\s*#*$', line)
        if not match:
            continue
        title = re.sub(r'<[^>]+>', '', match.group(1))
        slug = ''.join(c for c in title.lower() if c.isalnum() or c in '_- ')
        slug = slug.replace(' ', '-')
        suffix = counts[slug]
        anchors.add(slug + (f'-{suffix}' if suffix else ''))
        counts[slug] += 1
    return anchors


parser = argparse.ArgumentParser()
parser.add_argument('--candidate', required=True, type=Path)
parser.add_argument('--baseline', required=True, type=Path)
parser.add_argument('--workspace', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
failures = []
checks = []
files = []


def require(condition, name, details=None):
    checks.append({'check': name, 'passed': bool(condition), 'details': details})
    if not condition:
        failures.append(name)


expected = [
    '00_README.md', '01_PRODUCT_REQUIREMENTS.md', '02_WORKFLOW_AND_UX_SPEC.md',
    '03_TECHNICAL_DESIGN.md', '04_MCP_API_CONTRACTS.md',
    '05_IMPLEMENTATION_BACKLOG_AND_TEST_PLAN.md', '06_IMPLEMENTATION_AGENT_BRIEF.md',
    '07_UI_DESIGN_TASKS.md',
]
expected_views = [
    'AGENT_RULE_TEMPLATE.md', 'README.md', 'design.md',
    'implementation-plan.md', 'requirements.md', 'skills-governance.md',
]
require(sorted(p.name for p in (args.candidate / 'canonical').glob('*.md')) == expected,
        'exactly eight canonical files')
require(sorted(p.name for p in (args.candidate / 'views').glob('*.md')) == expected_views,
        'exactly six subordinate root views')
id_pattern = re.compile(r'\b(?:[A-Z]{1,10}(?:-[A-Z]{1,10})*-\d{1,5}[A-Z]?|T\d{3,4})\b')
texts = {}
for folder, names in [('canonical', expected), ('views', expected_views)]:
    for name in names:
        path = args.candidate / folder / name
        raw = path.read_bytes()
        text = raw.decode('utf-8')
        texts[f'{folder}/{name}'] = text
        old = (args.baseline / folder / name).read_text()
        removed = sorted(set(id_pattern.findall(old)) - set(id_pattern.findall(text)))
        require(not removed, f'preserved identifiers: {folder}/{name}', removed)
        require('1.4.35' in '\n'.join(text.splitlines()[:7]), f'current revision header: {folder}/{name}')
        require('NOT FROZEN' in '\n'.join(text.splitlines()[:7]), f'unfrozen header: {folder}/{name}')
        files.append({'path': f'{folder}/{name}', 'bytes': len(raw), 'sha256': sha256(raw)})

test_plan = texts['canonical/05_IMPLEMENTATION_BACKLOG_AND_TEST_PLAN.md']
definitions = re.findall(r'^\| ((?:ASE-(?:E2E|FLOW|INT)|SK-E2E)-\d+) \|', test_plan, re.M)
counts = Counter(definitions)
duplicates = {key: value for key, value in counts.items() if value > 1}
families = {family: sum(key.startswith(family + '-') for key in counts)
            for family in ['ASE-E2E', 'ASE-FLOW', 'SK-E2E', 'ASE-INT']}
require(not duplicates, 'canonical scenario definitions unique', duplicates)
require(families == {'ASE-E2E': 15, 'ASE-FLOW': 54, 'SK-E2E': 40, 'ASE-INT': 16},
        '125 planned scoped ASER definitions', families)
canonical_aliases = re.findall(r'^\| `SK-E2E-4[1-4]` \|.*$', test_plan, re.M)
require(len(canonical_aliases) == 4, 'four historical proposal aliases retained')
for name in ['skills-governance.md', 'implementation-plan.md']:
    text = texts['views/' + name]
    require(all(row in text for row in canonical_aliases), f'alias allocations agree: {name}')
    require(not re.search(r'^\| SK-E2E-4[1-4] \|', text, re.M), f'aliases not duplicate definitions: {name}')

supplemental = re.findall(r'^\| GEX-AC-\d+ \|.*$', test_plan, re.M)
require(len(supplemental) == 8 and len(set(supplemental)) == 8,
        'eight retained supplemental GEX-AC proof obligations')
require(all(row in texts['views/implementation-plan.md'] for row in supplemental),
        'supplemental GEX-AC obligations mirrored')
semantic_aliases = re.findall(r'^\| `GEX-SEM-0[1-8]` \|.*$', test_plan, re.M)
require(len(semantic_aliases) == 8, 'eight semantic proposal aliases retained')
require(all(row in texts['views/implementation-plan.md'] for row in semantic_aliases),
        'semantic proposal aliases mirrored')
ga_rows = re.findall(r'^\| GA-AC-0[1-5] .*$', test_plan, re.M)
require(len(ga_rows) == 5 and len(set(ga_rows)) == 5,
        'five current Graph Analytics acceptance rows')
require(all(row in texts['views/implementation-plan.md'] for row in ga_rows),
        'current GA acceptance rows mirrored')
discovery_aliases = re.findall(r'^\| `GEX-DISC-0[1-5]` \|.*$', test_plan, re.M)
require(len(discovery_aliases) == 5, 'five discovery aliases allocated without new definitions')
require(all(row in texts['views/implementation-plan.md'] for row in discovery_aliases),
        'discovery alias allocations mirrored')
require('Use the same eight canonical files at revision 1.4.35' in texts['views/implementation-plan.md'],
        'operative implementation instruction names current revision')
require('For any governed Model Studio or Skill-assisted operation' not in texts['views/skills-governance.md']
        and 'approved inactive model revision' in texts['views/skills-governance.md'],
        'historical model exception is retained')
require('`record_execution_result` / `update_execution_result`' in texts['canonical/03_TECHNICAL_DESIGN.md'],
        'source result-tool locator uses inspected name')

view_link_issues = []
for name in expected_views:
    text = texts['views/' + name]
    for match in re.finditer(r'(?<!!)\[[^\]\n]*\]\(([^\s)]+)(?:\s+"[^"\n]*")?\)', text):
        link = match.group(1).strip('<>')
        parsed = urlsplit(link)
        if parsed.scheme or parsed.netloc:
            continue
        target_name = parsed.path.removeprefix('./') if parsed.path else name
        if target_name not in expected_views:
            continue  # Nonlocal repository/library links require their own source binding.
        if parsed.fragment and unquote(parsed.fragment) not in headings(texts['views/' + target_name]):
            view_link_issues.append({'file': name, 'link': link, 'reason': 'missing sibling anchor'})
require(not view_link_issues, 'subordinate sibling links and anchors resolve', view_link_issues)

canonical_method = texts['canonical/06_IMPLEMENTATION_AGENT_BRIEF.md'].split(
    '### Portable method for discovery and principle distillation\n', 1)[1].split(
    '\n### Independent application and review boundary', 1)[0].strip()
view_method = texts['views/skills-governance.md'].split(
    '### 13.4.1 Portable method for discovery and principle distillation\n', 1)[1].split(
    '\n### AI-powered graph analysis method and skill-composition proposal', 1)[0].strip()
require(canonical_method.replace('owned by this canonical brief', 'owned by canonical 06') == view_method,
        'portable method mirror matches canonical owner')

canonical_map = texts['canonical/03_TECHNICAL_DESIGN.md'].split(
    '#### 18.2.1 Native Model Studio convergence and source maturity\n', 1)[1].split(
    '\n#### 18.3 Invariants', 1)[0].strip()
require(canonical_map in texts['views/design.md'], 'current source convergence mirror matches canonical owner')

link_issues = []
for name in expected:
    path = args.candidate / 'canonical' / name
    text = texts['canonical/' + name]
    for match in re.finditer(r'(?<!!)\[[^\]\n]*\]\(([^\s)]+)(?:\s+"[^"\n]*")?\)', text):
        link = match.group(1).strip('<>')
        parsed = urlsplit(link)
        if parsed.scheme or parsed.netloc:
            continue
        target = path.parent / unquote(parsed.path) if parsed.path else path
        if not target.is_file():
            link_issues.append({'file': name, 'link': link, 'reason': 'missing file'})
        elif parsed.fragment and target.suffix == '.md' and unquote(parsed.fragment) not in headings(target.read_text()):
            link_issues.append({'file': name, 'link': link, 'reason': 'missing anchor'})
require(not link_issues, 'canonical relative links and anchors resolve', link_issues)

integrity_inputs = [
    ('frozen candidate-1', args.workspace / 'input-v31/manifest.json', args.workspace / 'input-v31'),
    ('current source cache', args.workspace / 'verification/source419-manifest.json', args.workspace / 'source419'),
    ('current frontend source supplement', args.workspace / 'verification/source419-frontend-manifest.json',
     args.workspace / 'source419-frontend'),
    ('recovered method pack', args.workspace / 'method-inputs/repository-d83549c8/manifest.json',
     args.workspace / 'method-inputs/repository-d83549c8'),
    ('original method artifacts', args.workspace / 'method-inputs/manifest.json', args.workspace / 'method-inputs'),
]
if (args.candidate / 'manifest.json').is_file() and args.candidate != args.workspace / 'input-v31':
    integrity_inputs.append(('current candidate snapshot', args.candidate / 'manifest.json', args.candidate))
for label, manifest_path, root in integrity_inputs:
    manifest = json.loads(manifest_path.read_text())
    mismatch = []
    for item in manifest['files']:
        path = root / item['path']
        if not path.is_file():
            mismatch.append({'path': item['path'], 'reason': 'missing'})
            continue
        raw = path.read_bytes()
        if sha256(raw) != item['sha256'] or len(raw) != item['bytes']:
            mismatch.append({'path': item['path'], 'reason': 'bytes/digest mismatch'})
        if item.get('git_blob') and git_blob(raw) != item['git_blob']:
            mismatch.append({'path': item['path'], 'reason': 'Git blob mismatch'})
    require(not mismatch, f'input integrity: {label}', {'checked_files': len(manifest['files']), 'mismatches': mismatch})

result = {
    'verifier': 'Tesbo specification document binding v3',
    'scope': 'Document structure, declared mirrors, identifier continuity and exact input bytes only',
    'limits': 'No semantic completeness, R-D-T sufficiency, source behavior, runtime, UI, approval, Skill efficacy or freeze verdict',
    'candidate': str(args.candidate), 'baseline': str(args.baseline),
    'passed': not failures, 'failed_checks': failures, 'checks': checks, 'candidate_files': files,
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': not failures, 'checks': len(checks), 'failed_checks': failures,
                  'scenario_counts': families, 'supplemental_GEX_AC': len(supplemental), 'current_GA_AC': len(ga_rows), 'discovery_aliases': len(discovery_aliases), 'output': str(args.output)}, indent=2))
sys.exit(0 if not failures else 1)
