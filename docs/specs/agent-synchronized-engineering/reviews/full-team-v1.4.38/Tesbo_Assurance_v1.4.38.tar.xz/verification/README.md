# Tesbo document verification binding

For this specification-only continuation, Green's target binding is `verify_spec_package.py`, executed against the explicitly named candidate and the v1.4.30 baseline. It checks the eight canonical and six subordinate files, revision/status headers, identifier continuity, 125 distinct scoped ASER definitions, proposal-alias reconciliation, declared method/source mirrors, canonical relative links, and exact source/input bytes. The script emits JSON evidence and exits nonzero on a failed assertion.

This declaration does not replace the original Green charter or its independent review requirement. Semantic completeness, R-D-T adequacy, missing implementation, all-writer enforcement, runtime/UI outcomes, authority, method efficacy and freeze status remain manual/source/runtime review obligations as applicable. The Nesberry-specific verifier is not run against Tesbo or relabeled as a Tesbo pass.

Candidate-1 execution: `python3 verify_spec_package.py --candidate ../input-v31 --baseline ../input-v30 --workspace .. --output candidate1-document-check.json`. It exited 0 with 58 bounded document/input checks. A changed candidate must be checked again and its result must identify its own digests. The result is not a count of product tests.

## Current revision 1.4.32 binding

The original v1 script and its recorded outputs remain unchanged. `verify_spec_package_v2.py` binds the current revision to `baseline-latest` (saved canonical v1.4.31 plus exact subordinate c12b8956 views). It additionally checks all five repaired sibling-view method anchors, the eight preserved GEX-AC supplemental obligations and semantic proposal-label allocation. A frozen candidate includes its own manifest, adding an exact input-byte check to the working-directory assertions. Failed intermediate outputs are not final passes.

Final continuation candidate 2 is `input-v32-candidate2`. Execute `python3 verification/verify_spec_package_v2.py --candidate input-v32-candidate2 --baseline baseline-latest --workspace . --output verification/candidate32-final-document-check.json` from the continuation root. This is a document/input consistency gate only. Green and the other original charters still own their actual semantic and cross-role obligations; no automatic Graph harness, formal human quorum, runtime acceptance or method effectiveness follows from these checks.

Earlier `input-v30/views` review copies each have one extra terminal LF relative to their corresponding remote264380 blobs. `early-view-copy-provenance-correction.json` records this byte-level correction; frozen originals and review manifests remain unchanged. The exact remote bytes are separately retained at `remote-264380/views`. The current reconciled parent uses exact c12b8956 blobs. The affected earlier copied inputs were substantively identical text, but must not be described as byte-identical remote blobs.

## Final concurrent-parent binding — revision1.4.35

The separately saved parent advanced to canonical34/version14 and ac49 views. `verify_spec_package_v3.py` binds `input-v35-candidate1` against `baseline-v34`; it retains v2 checks and adds current GA rows, discovery alias mirrors, operative revision, historical-mode and exact source-tool locator checks. The v32 receipts stay scoped to their original bytes. Final35 deltas are informed preservation/contract review, not rewritten cold outputs.
